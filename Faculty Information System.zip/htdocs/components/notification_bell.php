<?php
// includes/notification_bell.php
// Include this in your dashboard header/navbar
require_once '../config/Database.php';

$database = \Config\Database::getInstance();
$pdo = $database->getConnection();

// Fetch unread notifications count
$unread_count = 0;
if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
        $stmt->execute([$_SESSION['user_id']]);
        $result = $stmt->fetch();
        $unread_count = $result['count'];
    } catch (PDOException $e) {
        error_log("Notification Error: " . $e->getMessage());
    }
}
?>

<style>
.notification-bell-container {
    position: relative;
    display: inline-block;
}

.notification-bell {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    padding: 10px;
    z-index: 1001;
    user-select: none;
    background: transparent;
    border: none;
    min-width: 50px;
    min-height: 50px;
}

.notification-bell:active {
    transform: scale(0.95);
}

.bell-icon {
    font-size: 24px;
    color: #333;
    transition: color 0.3s;
    display: block;
    line-height: 1;
}

.notification-bell:hover .bell-icon {
    color: #990000;
}

.notification-badge {
    position: absolute;
    top: 8px;
    right: 8px;
    background: #f44336;
    color: white;
    border-radius: 50%;
    padding: 2px 6px;
    font-size: 11px;
    font-weight: bold;
    min-width: 18px;
    text-align: center;
    pointer-events: none;
    z-index: 2;
}

.notification-dropdown {
    display: none;
    position: absolute;
    top: calc(100% + 5px);
    right: 0;
    background: white;
    border-radius: 8px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    width: 350px;
    max-height: 500px;
    overflow-y: auto;
    z-index: 1000;
}

.notification-dropdown.show {
    display: block;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.notification-header {
    padding: 15px;
    border-bottom: 1px solid #e0e0e0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #f8f9fa;
    border-radius: 8px 8px 0 0;
}

.notification-header h3 {
    margin: 0;
    font-size: 16px;
    color: #333;
}

.mark-all-read {
    background: none;
    border: none;
    color: #990000;
    font-size: 13px;
    cursor: pointer;
    padding: 5px 10px;
}

.mark-all-read:hover {
    text-decoration: underline;
}

.notification-list {
    max-height: 400px;
    overflow-y: auto;
}

.notification-item {
    padding: 15px;
    border-bottom: 1px solid #f0f0f0;
    cursor: pointer;
    transition: background 0.2s;
    position: relative;
}

.notification-item:hover {
    background: #f8f9fa;
}

.notification-item.unread {
    background: #f0f4ff;
}

.notification-item.unread::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 4px;
    height: 70%;
    background: #990000;
    border-radius: 0 4px 4px 0;
}

.notification-title {
    font-weight: 600;
    color: #333;
    margin-bottom: 5px;
    font-size: 14px;
}

.notification-message {
    color: #666;
    font-size: 13px;
    margin-bottom: 5px;
    line-height: 1.4;
}

.notification-time {
    font-size: 11px;
    color: #999;
}

.notification-type {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 500;
    margin-bottom: 5px;
}

.notification-type.success {
    background: #d4edda;
    color: #155724;
}

.notification-type.info {
    background: #d1ecf1;
    color: #0c5460;
}

.notification-type.warning {
    background: #fff3cd;
    color: #856404;
}

.notification-type.error {
    background: #f8d7da;
    color: #721c24;
}

.no-notifications {
    padding: 40px 20px;
    text-align: center;
    color: #999;
}

.no-notifications-icon {
    font-size: 48px;
    margin-bottom: 10px;
    opacity: 0.5;
}

.view-all {
    padding: 12px;
    text-align: center;
    border-top: 1px solid #e0e0e0;
    background: #f8f9fa;
    border-radius: 0 0 8px 8px;
}

.view-all a {
    color: #990000;
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
}

.view-all a:hover {
    text-decoration: underline;
}

.loading-spinner {
    text-align: center;
    padding: 20px;
    color: #999;
}
</style>

<div class="notification-bell-container">
    <button type="button" class="notification-bell" id="notificationBell" aria-label="Notifications">
        <span class="bell-icon">🔔</span>
        <?php if ($unread_count > 0): ?>
            <span class="notification-badge" id="notificationBadge"><?php echo $unread_count; ?></span>
        <?php endif; ?>
    </button>
    
    <div class="notification-dropdown" id="notificationDropdown">
        <div class="notification-header">
            <h3>Notifications</h3>
            <?php if ($unread_count > 0): ?>
                <button type="button" class="mark-all-read" id="markAllReadBtn">Mark all as read</button>
            <?php endif; ?>
        </div>
        <div class="notification-list" id="notificationList">
            <div class="loading-spinner">Loading notifications...</div>
        </div>
        <div class="view-all">
            <a href="../notifications.php">View All Notifications</a>
        </div>
    </div>
</div>

<script>
// Notification Bell JavaScript - Enhanced Version
(function() {
    'use strict';
    
    console.log('🔔 Notification bell script starting...');
    
    function initNotificationBell() {
        console.log('🔔 Initializing notification bell...');
        
        const notificationBell = document.getElementById('notificationBell');
        const notificationDropdown = document.getElementById('notificationDropdown');
        const notificationList = document.getElementById('notificationList');
        const markAllReadBtn = document.getElementById('markAllReadBtn');

        // Debugging - Check if elements exist
        console.log('Bell element:', notificationBell);
        console.log('Dropdown element:', notificationDropdown);
        
        if (!notificationBell) {
            console.error('❌ Notification bell element not found!');
            return;
        }
        
        if (!notificationDropdown) {
            console.error('❌ Notification dropdown element not found!');
            return;
        }

        console.log('✅ All elements found successfully');
        
        // Add visual feedback on hover
        notificationBell.addEventListener('mouseenter', function() {
            console.log('🖱️ Mouse entered bell');
            this.style.opacity = '0.8';
        });
        
        notificationBell.addEventListener('mouseleave', function() {
            console.log('🖱️ Mouse left bell');
            this.style.opacity = '1';
        });

        // Toggle dropdown on bell click - MULTIPLE EVENT TYPES
        notificationBell.addEventListener('click', handleBellClick);
        notificationBell.addEventListener('touchstart', handleBellClick);
        
        function handleBellClick(e) {
            console.log('🎯 BELL CLICKED/TOUCHED!', e.type);
            e.preventDefault();
            e.stopPropagation();
            
            const isVisible = notificationDropdown.classList.contains('show');
            console.log('Dropdown currently visible:', isVisible);
            
            if (!isVisible) {
                console.log('📂 Opening dropdown...');
                notificationDropdown.classList.add('show');
                loadNotifications();
            } else {
                console.log('📁 Closing dropdown...');
                notificationDropdown.classList.remove('show');
            }
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!notificationBell.contains(e.target) && !notificationDropdown.contains(e.target)) {
                console.log('🚪 Closing dropdown (outside click)');
                notificationDropdown.classList.remove('show');
            }
        });

        // Prevent dropdown from closing when clicking inside it
        notificationDropdown.addEventListener('click', function(e) {
            console.log('📋 Clicked inside dropdown');
            e.stopPropagation();
        });

        // Mark all as read functionality
        if (markAllReadBtn) {
            markAllReadBtn.addEventListener('click', function() {
                console.log('📝 Mark all as read clicked');
                markAllAsRead();
            });
        }

        // Load notifications via AJAX
        function loadNotifications() {
            console.log('📡 Loading notifications...');
            notificationList.innerHTML = '<div class="loading-spinner">Loading notifications...</div>';
            
            fetch('../api/get_notifications.php')
                .then(response => {
                    console.log('📥 Response received:', response.status);
                    return response.json();
                })
                .then(data => {
                    console.log('📊 Notifications data:', data);
                    if (data.success) {
                        displayNotifications(data.notifications);
                    } else {
                        console.error('❌ Failed to load notifications:', data.message);
                        notificationList.innerHTML = '<div class="no-notifications"><div class="no-notifications-icon">🔔</div><p>Failed to load notifications</p></div>';
                    }
                })
                .catch(error => {
                    console.error('❌ Error loading notifications:', error);
                    notificationList.innerHTML = '<div class="no-notifications"><div class="no-notifications-icon">⚠️</div><p>Error loading notifications</p></div>';
                });
        }

        // Display notifications in the dropdown
        function displayNotifications(notifications) {
            console.log('🎨 Displaying', notifications.length, 'notifications');
            
            if (notifications.length === 0) {
                notificationList.innerHTML = '<div class="no-notifications"><div class="no-notifications-icon">🔔</div><p>No notifications yet</p></div>';
                return;
            }

            let html = '';
            notifications.forEach(notification => {
                const unreadClass = notification.is_read == 0 ? 'unread' : '';
                const typeClass = notification.type || 'info';
                
                html += `
                    <div class="notification-item ${unreadClass}" data-id="${notification.id}" onclick="markAsRead(${notification.id})">
                        <span class="notification-type ${typeClass}">${typeClass.toUpperCase()}</span>
                        <div class="notification-title">${escapeHtml(notification.title)}</div>
                        <div class="notification-message">${escapeHtml(notification.message)}</div>
                        <div class="notification-time">${formatTime(notification.created_at)}</div>
                    </div>
                `;
            });
            
            notificationList.innerHTML = html;
        }

        // Mark single notification as read
        window.markAsRead = function(notificationId) {
            console.log('✓ Marking notification', notificationId, 'as read');
            fetch('../api/mark_notification_read.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ notification_id: notificationId })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const notifItem = document.querySelector(`[data-id="${notificationId}"]`);
                    if (notifItem) {
                        notifItem.classList.remove('unread');
                    }
                    updateBadgeCount();
                }
            })
            .catch(error => console.error('Error marking notification as read:', error));
        };

        // Mark all notifications as read
        function markAllAsRead() {
            fetch('../api/mark_all_notifications_read.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.querySelectorAll('.notification-item.unread').forEach(item => {
                        item.classList.remove('unread');
                    });
                    
                    const badge = document.getElementById('notificationBadge');
                    if (badge) {
                        badge.remove();
                    }
                    
                    if (markAllReadBtn) {
                        markAllReadBtn.style.display = 'none';
                    }
                }
            })
            .catch(error => console.error('Error marking all as read:', error));
        }

        // Update badge count
        function updateBadgeCount() {
            fetch('../api/get_unread_count.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const currentBadge = document.getElementById('notificationBadge');
                        if (data.count > 0) {
                            if (currentBadge) {
                                currentBadge.textContent = data.count;
                            } else {
                                const badge = document.createElement('span');
                                badge.className = 'notification-badge';
                                badge.id = 'notificationBadge';
                                badge.textContent = data.count;
                                notificationBell.appendChild(badge);
                            }
                        } else {
                            if (currentBadge) {
                                currentBadge.remove();
                            }
                        }
                    }
                })
                .catch(error => console.error('Error updating badge count:', error));
        }

        // Helper function to escape HTML
        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Helper function to format time
        function formatTime(timestamp) {
            const date = new Date(timestamp);
            const now = new Date();
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMs / 3600000);
            const diffDays = Math.floor(diffMs / 86400000);

            if (diffMins < 1) return 'Just now';
            if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
            if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
            if (diffDays < 7) return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
            
            return date.toLocaleDateString();
        }

        // Auto-refresh notifications every 30 seconds
        setInterval(function() {
            if (notificationDropdown.classList.contains('show')) {
                loadNotifications();
            } else {
                updateBadgeCount();
            }
        }, 30000);
        
        console.log('✅ Notification bell initialized successfully!');
    }

    // Try multiple initialization methods
    if (document.readyState === 'loading') {
        console.log('⏳ Waiting for DOM to load...');
        document.addEventListener('DOMContentLoaded', initNotificationBell);
    } else {
        console.log('✅ DOM already loaded, initializing now...');
        initNotificationBell();
    }
    
    // Backup initialization after a short delay
    setTimeout(function() {
        if (!document.getElementById('notificationBell')?.onclick) {
            console.log('🔄 Backup initialization triggered');
            initNotificationBell();
        }
    }, 500);
})();
</script>