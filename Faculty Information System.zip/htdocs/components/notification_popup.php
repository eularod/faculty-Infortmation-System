<?php
/**
 * Notification Popup Component
 * Include at the bottom of your dashboard pages
 */
?>

<style>
.notification-popup-container {
    position: fixed;
    top: 80px;
    right: 20px;
    z-index: 9999;
    max-width: 400px;
    width: calc(100% - 40px);
    pointer-events: none;
}

.notification-popup {
    background: white;
    border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.15);
    margin-bottom: 15px;
    overflow: hidden;
    animation: slideInRight 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    cursor: pointer;
    transition: all 0.3s;
    border-left: 4px solid #667eea;
    pointer-events: auto;
}

.notification-popup:hover {
    transform: translateX(-5px);
    box-shadow: 0 12px 32px rgba(0,0,0,0.2);
}

.notification-popup.closing {
    animation: slideOutRight 0.3s ease-out forwards;
}

@keyframes slideInRight {
    from { transform: translateX(120%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
}

@keyframes slideOutRight {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(120%); opacity: 0; }
}

.notification-popup-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 16px;
    background: linear-gradient(135deg, #f8f9fa 0%, #fff 100%);
    border-bottom: 1px solid #e9ecef;
}

.notification-popup-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
    margin-right: 12px;
}

.notification-popup-icon.success {
    background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
    color: #155724;
}

.notification-popup-icon.warning {
    background: linear-gradient(135deg, #fff3cd 0%, #ffeeba 100%);
    color: #856404;
}

.notification-popup-icon.info {
    background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
    color: #0c5460;
}

.notification-popup-icon.danger {
    background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
    color: #721c24;
}

.notification-popup-content {
    flex: 1;
}

.notification-popup-title {
    font-size: 15px;
    font-weight: 600;
    color: #212529;
    margin: 0 0 4px 0;
}

.notification-popup-time {
    font-size: 12px;
    color: #6c757d;
}

.notification-popup-close {
    background: none;
    border: none;
    color: #6c757d;
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    transition: all 0.2s;
    font-size: 18px;
}

.notification-popup-close:hover {
    background: #e9ecef;
    color: #495057;
}

.notification-popup-body {
    padding: 12px 16px 16px 16px;
}

.notification-popup-message {
    font-size: 14px;
    color: #495057;
    line-height: 1.5;
    margin: 0;
}

.notification-popup-progress {
    height: 3px;
    background: #e9ecef;
}

.notification-popup-progress-bar {
    height: 100%;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    animation: progress 5s linear forwards;
}

@keyframes progress {
    from { width: 100%; }
    to { width: 0%; }
}

.notification-sound-toggle {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: white;
    border: 1px solid #dee2e6;
    border-radius: 50%;
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transition: all 0.3s;
    z-index: 9998;
}

.notification-sound-toggle:hover {
    transform: scale(1.1);
}

.notification-sound-toggle.muted i {
    color: #dc3545;
}

@media (max-width: 480px) {
    .notification-popup-container {
        top: 70px;
        right: 10px;
        width: calc(100% - 20px);
    }
}
</style>

<div class="notification-popup-container" id="notificationPopupContainer"></div>

<div class="notification-sound-toggle" id="soundToggle" title="Toggle sound">
    <span style="font-size: 20px;">🔔</span>
</div>

<audio id="notificationSound" preload="auto">
    <source src="data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIGmi78OScTgwOUKnj8bllHQY2kdfy0HotBSh+zPLaizsKGGS76+uoVRQKRp/g8r5sIQUrgc7y2Yk2CBpou/DknE4MDlCp4/G5ZR0GNpHX8tB6LQUofszy2os7ChhlvOvqp1UUCkef4fK+ayEGK4DO8tqJNggaaLzw45xODA5QquPxuWUdBjaS1/LQei0FKH7M8tqLOwkZZb3r6qdWFApHn+Hyvmwh" type="audio/wav">
</audio>

<script>
(function() {
    'use strict';
    
    const NotificationPopup = {
        container: null,
        soundEnabled: true,
        soundToggle: null,
        notificationSound: null,
        checkInterval: null,
        activePopups: new Set(),
        maxPopups: 3,
        
        init: function() {
            this.container = document.getElementById('notificationPopupContainer');
            this.soundToggle = document.getElementById('soundToggle');
            this.notificationSound = document.getElementById('notificationSound');
            
            // Load sound preference
            this.soundEnabled = localStorage.getItem('notificationSound') !== 'false';
            this.updateSoundIcon();
            
            // Setup sound toggle
            if (this.soundToggle) {
                this.soundToggle.addEventListener('click', function() {
                    NotificationPopup.toggleSound();
                });
            }
            
            // Check for new notifications
            this.checkForNewNotifications();
            this.checkInterval = setInterval(function() {
                NotificationPopup.checkForNewNotifications();
            }, 5000);
        },
        
        toggleSound: function() {
            this.soundEnabled = !this.soundEnabled;
            localStorage.setItem('notificationSound', this.soundEnabled);
            this.updateSoundIcon();
            
            if (this.soundEnabled) {
                this.playSound();
            }
        },
        
        updateSoundIcon: function() {
            if (!this.soundToggle) return;
            
            if (this.soundEnabled) {
                this.soundToggle.innerHTML = '<span style="font-size: 20px;">🔔</span>';
                this.soundToggle.classList.remove('muted');
            } else {
                this.soundToggle.innerHTML = '<span style="font-size: 20px;">🔕</span>';
                this.soundToggle.classList.add('muted');
            }
        },
        
        checkForNewNotifications: function() {
            fetch('api/get_latest_notifications.php')
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    if (data.success && data.has_new) {
                        data.notifications.forEach(function(notification) {
                            NotificationPopup.show(notification);
                        });
                    }
                })
                .catch(function(error) {
                    console.error('Error checking notifications:', error);
                });
        },
        
        show: function(notification) {
            // Limit popups
            if (this.activePopups.size >= this.maxPopups) {
                const firstPopup = this.activePopups.values().next().value;
                this.close(firstPopup);
            }
            
            const popup = document.createElement('div');
            popup.className = 'notification-popup';
            popup.dataset.id = notification.notification_id;
            
            const icon = this.getIcon(notification.type);
            const escapedTitle = this.escapeHtml(notification.title);
            const escapedMessage = this.escapeHtml(notification.message);
            
            popup.innerHTML = 
                '<div class="notification-popup-header">' +
                    '<div style="display: flex; align-items: flex-start; flex: 1;">' +
                        '<div class="notification-popup-icon ' + notification.type + '">' + icon + '</div>' +
                        '<div class="notification-popup-content">' +
                            '<h4 class="notification-popup-title">' + escapedTitle + '</h4>' +
                            '<div class="notification-popup-time">Just now</div>' +
                        '</div>' +
                    '</div>' +
                    '<button class="notification-popup-close" onclick="NotificationPopup.close(' + notification.notification_id + ')">×</button>' +
                '</div>' +
                '<div class="notification-popup-body">' +
                    '<p class="notification-popup-message">' + escapedMessage + '</p>' +
                '</div>' +
                '<div class="notification-popup-progress">' +
                    '<div class="notification-popup-progress-bar"></div>' +
                '</div>';
            
            // Click to navigate
            popup.addEventListener('click', function(e) {
                if (e.target.closest('.notification-popup-close')) return;
                
                NotificationPopup.markAsRead(notification.notification_id);
                
                if (notification.link && notification.link !== 'null' && notification.link !== '') {
                    window.location.href = notification.link;
                } else {
                    NotificationPopup.close(notification.notification_id);
                }
            });
            
            this.container.appendChild(popup);
            this.activePopups.add(notification.notification_id);
            
            // Play sound
            if (this.soundEnabled) {
                this.playSound();
            }
            
            // Auto-close after 5 seconds
            setTimeout(function() {
                NotificationPopup.close(notification.notification_id);
            }, 5000);
        },
        
        close: function(notificationId) {
            const popup = this.container.querySelector('[data-id="' + notificationId + '"]');
            if (popup) {
                popup.classList.add('closing');
                this.activePopups.delete(notificationId);
                setTimeout(function() {
                    popup.remove();
                }, 300);
            }
        },
        
        markAsRead: function(notificationId) {
            fetch('api/mark_notification_read.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ notification_id: notificationId })
            }).catch(function(error) {
                console.error('Mark read error:', error);
            });
        },
        
        playSound: function() {
            if (this.notificationSound) {
                this.notificationSound.currentTime = 0;
                this.notificationSound.play().catch(function() {});
            }
        },
        
        getIcon: function(type) {
            const icons = {
                'success': '✓',
                'warning': '⚠',
                'info': 'ℹ',
                'danger': '✕'
            };
            return icons[type] || icons['info'];
        },
        
        escapeHtml: function(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        },
        
        destroy: function() {
            if (this.checkInterval) {
                clearInterval(this.checkInterval);
            }
        }
    };
    
    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        NotificationPopup.init();
    });
    
    // Cleanup
    window.addEventListener('beforeunload', function() {
        NotificationPopup.destroy();
    });
    
    // Make available globally
    window.NotificationPopup = NotificationPopup;
})();
</script>