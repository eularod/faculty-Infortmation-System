<?php
/**
 * Email Verification Banner Component
 * Place at top of dashboard pages after session_start()
 */

// Ensure session is started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    return;
}

// Get user's email verification status
require_once __DIR__ . '/../config/Database.php';

try {
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
    
    $userId = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
    if ($userId === false) {
        return;
    }
    
    $stmt = $pdo->prepare("
        SELECT 
            email_verified, 
            email,
            verification_token_expiry,
            CASE 
                WHEN verification_token_expiry IS NULL THEN NULL
                WHEN verification_token_expiry > NOW() THEN TIMESTAMPDIFF(MINUTE, NOW(), verification_token_expiry)
                ELSE -1
            END as minutes_remaining
        FROM users 
        WHERE user_id = ?
    ");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Only show for faculty and if not verified
    if ($user && $user['email_verified'] == 0) {
        $userType = strtolower(trim($_SESSION['user_type'] ?? ''));
        if ($userType !== 'faculty') {
            return;
        }
    } else {
        return;
    }
    
} catch (Exception $e) {
    error_log("Email verification banner error: " . $e->getMessage());
    return;
}
?>

<style>
.verification-banner {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 15px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    animation: slideDown 0.5s ease-out;
    position: relative;
    z-index: 999;
}

@keyframes slideDown {
    from { transform: translateY(-100%); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

.verification-banner.hiding {
    animation: slideUp 0.5s ease-out forwards;
}

@keyframes slideUp {
    from { transform: translateY(0); opacity: 1; }
    to { transform: translateY(-100%); opacity: 0; }
}

.verification-banner.hidden {
    display: none;
}

.verification-banner-content {
    display: flex;
    align-items: center;
    gap: 15px;
    flex: 1;
}

.verification-banner-icon {
    font-size: 28px;
}

.verification-banner-text h4 {
    margin: 0 0 5px 0;
    font-size: 16px;
    font-weight: 600;
}

.verification-banner-text p {
    margin: 0;
    font-size: 14px;
    opacity: 0.95;
}

.verification-banner-email {
    font-weight: 600;
    text-decoration: underline;
}

.verification-banner-timer {
    font-size: 12px;
    opacity: 0.9;
    margin-top: 5px;
    display: flex;
    align-items: center;
    gap: 5px;
}

.verification-banner-timer.expired {
    color: #ffd700;
    font-weight: 600;
}

.verification-banner-actions {
    display: flex;
    gap: 10px;
    align-items: center;
}

.btn-verify-now {
    background: white;
    color: #667eea;
    border: none;
    padding: 12px 24px;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    transition: all 0.3s;
    font-size: 14px;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.btn-verify-now:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.btn-close-banner {
    background: rgba(255, 255, 255, 0.2);
    border: none;
    color: white;
    padding: 8px 12px;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s;
    font-size: 14px;
}

.btn-close-banner:hover {
    background: rgba(255, 255, 255, 0.3);
}

@media (max-width: 768px) {
    .verification-banner {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
    
    .verification-banner-content {
        flex-direction: column;
        text-align: center;
    }
    
    .verification-banner-actions {
        width: 100%;
        justify-content: center;
    }
    
    .btn-verify-now {
        width: 100%;
        justify-content: center;
    }
}
</style>

<div class="verification-banner" id="verificationBanner">
    <div class="verification-banner-content">
        <div class="verification-banner-icon">🔐</div>
        <div class="verification-banner-text">
            <h4>Email Verification Required</h4>
            <p>
                Verify your email address 
                <span class="verification-banner-email"><?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></span> 
                to unlock all features
            </p>
            
            <?php if ($user['minutes_remaining'] !== null): ?>
                <?php if ($user['minutes_remaining'] > 0): ?>
                    <div class="verification-banner-timer">
                        <span>Code expires in <strong><?php echo (int)$user['minutes_remaining']; ?> minutes</strong></span>
                    </div>
                <?php elseif ($user['minutes_remaining'] == -1): ?>
                    <div class="verification-banner-timer expired">
                        <span>Code expired. Request a new one.</span>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="verification-banner-actions">
        <button class="btn-verify-now" onclick="window.location.href='../verify_email_otp.php'">
            Enter Code Now
        </button>
        <button class="btn-close-banner" id="btnCloseBanner" title="Dismiss">
            ✕
        </button>
    </div>
</div>

<script>
(function() {
    'use strict';
    
    const banner = document.getElementById('verificationBanner');
    const btnClose = document.getElementById('btnCloseBanner');
    
    if (!banner || !btnClose) return;
    
    // Check if dismissed in session
    if (sessionStorage.getItem('verificationBannerDismissed') === 'true') {
        banner.classList.add('hidden');
        return;
    }
    
    // Check verification status every 10 seconds
    const checkInterval = setInterval(checkVerificationStatus, 10000);
    
    function checkVerificationStatus() {
        fetch('api/check_verification_status.php')
            .then(response => response.json())
            .then(data => {
                if (data.success && data.verified) {
                    clearInterval(checkInterval);
                    banner.classList.add('hiding');
                    setTimeout(function() {
                        banner.classList.add('hidden');
                    }, 500);
                }
            })
            .catch(error => console.error('Verification check error:', error));
    }
    
    // Close banner
    btnClose.addEventListener('click', function() {
        banner.classList.add('hiding');
        setTimeout(function() {
            banner.classList.add('hidden');
        }, 500);
        sessionStorage.setItem('verificationBannerDismissed', 'true');
        clearInterval(checkInterval);
    });
    
    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        clearInterval(checkInterval);
    });
})();
</script>