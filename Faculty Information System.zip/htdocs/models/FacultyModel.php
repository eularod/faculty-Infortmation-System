<?php
/**
 * Faculty Model
 * Handles all faculty-related database operations
 */

namespace Models;

use Config\Database;
use PDO;

class FacultyModel {
    private $db;
    private $table = 'faculty';
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all faculty members
     */
    public function getAll($filters = []) {
        $sql = "SELECT f.*, d.department_name 
                FROM {$this->table} f 
                LEFT JOIN departments d ON f.department_id = d.department_id";
        
        $conditions = [];
        $params = [];
        
        if (!empty($filters['department_id'])) {
            $departmentId = filter_var($filters['department_id'], FILTER_VALIDATE_INT);
            if ($departmentId !== false) {
                $conditions[] = "f.department_id = ?";
                $params[] = $departmentId;
            }
        }
        
        if (!empty($filters['search'])) {
            $conditions[] = "(f.first_name LIKE ? OR f.last_name LIKE ? OR f.email LIKE ?)";
            $searchTerm = '%' . filter_var($filters['search'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) . '%';
            $params[] = $searchTerm;
            $params[] = $searchTerm;
            $params[] = $searchTerm;
        }
        
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
        
        $sql .= " ORDER BY f.last_name, f.first_name";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get faculty by ID
     */
    public function getById($facultyId) {
        $facultyId = filter_var($facultyId, FILTER_VALIDATE_INT);
        if ($facultyId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("
            SELECT f.*, d.department_name, d.department_code
            FROM {$this->table} f
            LEFT JOIN departments d ON f.department_id = d.department_id
            WHERE f.faculty_id = ?
        ");
        $stmt->execute([$facultyId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create new faculty member
     */
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO {$this->table} 
            (user_id, department_id, first_name, last_name, email, phone, address, photo_url, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            isset($data['user_id']) ? filter_var($data['user_id'], FILTER_VALIDATE_INT) : null,
            isset($data['department_id']) ? filter_var($data['department_id'], FILTER_VALIDATE_INT) : null,
            filter_var($data['first_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['last_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['email'], FILTER_SANITIZE_EMAIL),
            isset($data['phone']) ? filter_var($data['phone'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            isset($data['address']) ? filter_var($data['address'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            isset($data['photo_url']) ? filter_var($data['photo_url'], FILTER_SANITIZE_URL) : null,
            isset($data['created_by']) ? filter_var($data['created_by'], FILTER_VALIDATE_INT) : null
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Update faculty member
     */
    public function update($facultyId, $data) {
        $facultyId = filter_var($facultyId, FILTER_VALIDATE_INT);
        if ($facultyId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("
            UPDATE {$this->table} 
            SET department_id = ?, first_name = ?, last_name = ?, email = ?, 
                phone = ?, address = ?, photo_url = ?, updated_by = ?
            WHERE faculty_id = ?
        ");
        
        return $stmt->execute([
            isset($data['department_id']) ? filter_var($data['department_id'], FILTER_VALIDATE_INT) : null,
            filter_var($data['first_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['last_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['email'], FILTER_SANITIZE_EMAIL),
            isset($data['phone']) ? filter_var($data['phone'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            isset($data['address']) ? filter_var($data['address'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            isset($data['photo_url']) ? filter_var($data['photo_url'], FILTER_SANITIZE_URL) : null,
            isset($data['updated_by']) ? filter_var($data['updated_by'], FILTER_VALIDATE_INT) : null,
            $facultyId
        ]);
    }
    
    /**
     * Delete faculty member
     */
    public function delete($facultyId) {
        $facultyId = filter_var($facultyId, FILTER_VALIDATE_INT);
        if ($facultyId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE faculty_id = ?");
        return $stmt->execute([$facultyId]);
    }
    
    /**
     * Check if email exists
     */
    public function emailExists($email, $excludeId = null) {
        $email = filter_var($email, FILTER_SANITIZE_EMAIL);
        $sql = "SELECT COUNT(*) FROM {$this->table} WHERE email = ?";
        $params = [$email];
        
        if ($excludeId) {
            $excludeId = filter_var($excludeId, FILTER_VALIDATE_INT);
            if ($excludeId !== false) {
                $sql .= " AND faculty_id != ?";
                $params[] = $excludeId;
            }
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * Get faculty by user ID
     */
    public function getByUserId($userId) {
        $userId = filter_var($userId, FILTER_VALIDATE_INT);
        if ($userId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE user_id = ? LIMIT 1");
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get faculty statistics
     */
    public function getStatistics() {
        $stats = [];
        
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM {$this->table}");
        $stats['total'] = $stmt->fetchColumn();
        
        $stmt = $this->db->query("
            SELECT d.department_name, COUNT(f.faculty_id) as count
            FROM departments d
            LEFT JOIN {$this->table} f ON d.department_id = f.department_id
            GROUP BY d.department_id, d.department_name
            ORDER BY count DESC
        ");
        $stats['by_department'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return $stats;
    }

    public function beginTransaction() {
        return $this->db->beginTransaction();
    }

    public function commit() {
        return $this->db->commit();
    }

    public function rollBack() {
        return $this->db->rollBack();
    }
}