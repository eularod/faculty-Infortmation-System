<?php
/**
 * Research Model
 * Handles all research-related database operations
 */

namespace Models;

use Config\Database;
use PDO;

class ResearchModel {
    private $db;
    private $table = 'research';
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all research records for a faculty member
     */
    public function getByFacultyId($facultyId) {
        $facultyId = filter_var($facultyId, FILTER_VALIDATE_INT);
        if ($facultyId === false) {
            return [];
        }
        
        $stmt = $this->db->prepare("
            SELECT r.*, rt.type_name AS research_type, rs.status_name AS status
            FROM {$this->table} r
            LEFT JOIN research_types rt ON r.research_type_id = rt.research_type_id
            LEFT JOIN research_statuses rs ON r.status_id = rs.status_id
            WHERE r.faculty_id = ?
            ORDER BY r.year DESC
        ");
        $stmt->execute([$facultyId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get research record by ID
     */
    public function getById($researchId) {
        $researchId = filter_var($researchId, FILTER_VALIDATE_INT);
        if ($researchId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("
            SELECT r.*, rt.type_name, rs.status_name
            FROM {$this->table} r
            LEFT JOIN research_types rt ON r.research_type_id = rt.research_type_id
            LEFT JOIN research_statuses rs ON r.status_id = rs.status_id
            WHERE r.research_id = ?
        ");
        $stmt->execute([$researchId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create new research record
     */
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO {$this->table} 
            (faculty_id, research_title, research_type_id, status_id, year, description)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            filter_var($data['faculty_id'], FILTER_VALIDATE_INT),
            filter_var($data['research_title'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['research_type_id'], FILTER_VALIDATE_INT),
            filter_var($data['status_id'], FILTER_VALIDATE_INT),
            filter_var($data['year'], FILTER_VALIDATE_INT),
            isset($data['description']) ? filter_var($data['description'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Update research record
     */
    public function update($researchId, $data) {
        $researchId = filter_var($researchId, FILTER_VALIDATE_INT);
        if ($researchId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("
            UPDATE {$this->table} 
            SET research_title = ?, research_type_id = ?, status_id = ?, 
                year = ?, description = ?
            WHERE research_id = ?
        ");
        
        return $stmt->execute([
            filter_var($data['research_title'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['research_type_id'], FILTER_VALIDATE_INT),
            filter_var($data['status_id'], FILTER_VALIDATE_INT),
            filter_var($data['year'], FILTER_VALIDATE_INT),
            isset($data['description']) ? filter_var($data['description'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            $researchId
        ]);
    }
    
    /**
     * Delete research record
     */
    public function delete($researchId) {
        $researchId = filter_var($researchId, FILTER_VALIDATE_INT);
        if ($researchId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE research_id = ?");
        return $stmt->execute([$researchId]);
    }
    
    /**
     * Get research types
     */
    public function getResearchTypes() {
        $stmt = $this->db->query("SELECT * FROM research_types ORDER BY type_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get research statuses
     */
    public function getResearchStatuses() {
        $stmt = $this->db->query("SELECT * FROM research_statuses ORDER BY status_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}