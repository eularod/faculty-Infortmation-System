<?php
/**
 * User Model
 * Handles all user-related database operations
 */

namespace Models;

use Config\Database;
use PDO;

class UserModel {
    private $db;
    private $table = 'users';
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all users
     */
    public function getAll() {
        $stmt = $this->db->query("
            SELECT u.*, ut.type_name as user_type, 
                f.faculty_id, f.first_name, f.last_name
            FROM {$this->table} u
            INNER JOIN user_types ut ON u.user_type_id = ut.user_type_id
            LEFT JOIN faculty f ON u.user_id = f.user_id
            ORDER BY u.username
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get user by ID
     */
    public function getById($userId) {
        $userId = filter_var($userId, FILTER_VALIDATE_INT);
        if ($userId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("
            SELECT u.*, ut.type_name as user_type, f.faculty_id
            FROM {$this->table} u
            INNER JOIN user_types ut ON u.user_type_id = ut.user_type_id
            LEFT JOIN faculty f ON u.user_id = f.user_id
            WHERE u.user_id = ?
        ");
        $stmt->execute([$userId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get user by username
     */
    public function getByUsername($username) {
        $username = filter_var($username, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        
        $stmt = $this->db->prepare("
            SELECT u.*, ut.type_name as user_type
            FROM {$this->table} u
            INNER JOIN user_types ut ON u.user_type_id = ut.user_type_id
            WHERE u.username = ?
        ");
        $stmt->execute([$username]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create new user
     */
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO {$this->table} 
            (username, password, email, user_type_id, created_by)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            filter_var($data['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            password_hash($data['password'], PASSWORD_BCRYPT),
            isset($data['email']) ? filter_var($data['email'], FILTER_SANITIZE_EMAIL) : null,
            filter_var($data['user_type_id'], FILTER_VALIDATE_INT),
            isset($data['created_by']) ? filter_var($data['created_by'], FILTER_VALIDATE_INT) : null
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Update user
     */
    public function update($userId, $data) {
        $userId = filter_var($userId, FILTER_VALIDATE_INT);
        if ($userId === false) {
            return false;
        }
        
        if (isset($data['password']) && !empty($data['password'])) {
            $stmt = $this->db->prepare("
                UPDATE {$this->table} 
                SET username = ?, password = ?, user_type_id = ?
                WHERE user_id = ?
            ");
            
            return $stmt->execute([
                filter_var($data['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
                password_hash($data['password'], PASSWORD_BCRYPT),
                filter_var($data['user_type_id'], FILTER_VALIDATE_INT),
                $userId
            ]);
        }
        
        $stmt = $this->db->prepare("
            UPDATE {$this->table} 
            SET username = ?, user_type_id = ?
            WHERE user_id = ?
        ");
        
        return $stmt->execute([
            filter_var($data['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['user_type_id'], FILTER_VALIDATE_INT),
            $userId
        ]);
    }
    
    /**
     * Delete user
     */
    public function delete($userId) {
        $userId = filter_var($userId, FILTER_VALIDATE_INT);
        if ($userId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE user_id = ?");
        return $stmt->execute([$userId]);
    }
    
    /**
     * Check if username exists
     */
    public function usernameExists($username, $excludeId = null) {
        $username = filter_var($username, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        $sql = "SELECT COUNT(*) FROM {$this->table} WHERE username = ?";
        $params = [$username];
        
        if ($excludeId) {
            $excludeId = filter_var($excludeId, FILTER_VALIDATE_INT);
            if ($excludeId !== false) {
                $sql .= " AND user_id != ?";
                $params[] = $excludeId;
            }
        }
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchColumn() > 0;
    }
    
    /**
     * Get user types
     */
    public function getUserTypes() {
        $stmt = $this->db->query("SELECT * FROM user_types ORDER BY type_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Verify password
     */
    public function verifyPassword($userId, $password) {
        $userId = filter_var($userId, FILTER_VALIDATE_INT);
        if ($userId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("SELECT password FROM {$this->table} WHERE user_id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $user ? password_verify($password, $user['password']) : false;
    }

    /**
     * Get unlinked faculty
     */
    public function getUnlinkedFaculty() {
        $stmt = $this->db->query("
            SELECT f.faculty_id, f.first_name, f.last_name
            FROM faculty f
            WHERE f.user_id IS NULL
            ORDER BY f.last_name, f.first_name
        ");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}