<?php
/**
 * Award Model
 * Handles all award-related database operations
 */

namespace Models;

use Config\Database;
use PDO;

class AwardModel {
    private $db;
    private $awards_table = 'awards_achievements';
    private $columns_cache = null;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get column mappings for awards_achievements table
     */
    private function getColumnMappings() {
        if ($this->columns_cache !== null) {
            return $this->columns_cache;
        }
        
        $stmt = $this->db->query("DESCRIBE {$this->awards_table}");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Helper function to find column name
        $findColumn = function($options) use ($columns) {
            foreach ($options as $option) {
                if (in_array($option, $columns)) {
                    return $option;
                }
            }
            return null; // Return null if none found
        };
        
        // Map common column name variations
        $mappings = [
            'award_id' => 'award_id',
            'award_type_id' => $findColumn(['award_type_id', 'type_id']),
            'award_name' => $findColumn(['award_name', 'name', 'title']),
            'awarding_organization' => $findColumn(['awarding_organization', 'organization', 'org']),
            'year_awarded' => $findColumn(['year_awarded', 'year', 'award_year']),
            'description' => $findColumn(['description', 'desc']),
            'prize_amount' => $findColumn(['prize_amount', 'amount', 'prize']),
            'is_national' => $findColumn(['is_national', 'national']),
            'is_international' => $findColumn(['is_international', 'international'])
        ];
        
        $this->columns_cache = $mappings;
        return $mappings;
    }
    
    /**
     * Build SELECT fields dynamically based on available columns
     */
    private function buildSelectFields($includeJoins = true) {
        $cols = $this->getColumnMappings();
        
        $fields = ['aa.award_id'];
        
        if ($cols['award_type_id']) {
            $fields[] = "aa.{$cols['award_type_id']} as award_type_id";
        }
        if ($cols['award_name']) {
            $fields[] = "aa.{$cols['award_name']} as award_name";
        }
        if ($cols['awarding_organization']) {
            $fields[] = "aa.{$cols['awarding_organization']} as awarding_organization";
        }
        if ($cols['year_awarded']) {
            $fields[] = "aa.{$cols['year_awarded']} as year_awarded";
        }
        if ($cols['description']) {
            $fields[] = "aa.{$cols['description']} as description";
        }
        if ($cols['prize_amount']) {
            $fields[] = "aa.{$cols['prize_amount']} as prize_amount";
        }
        if ($cols['is_national']) {
            $fields[] = "aa.{$cols['is_national']} as is_national";
        }
        if ($cols['is_international']) {
            $fields[] = "aa.{$cols['is_international']} as is_international";
        }
        
        if ($includeJoins) {
            $fields[] = 'fa.faculty_id';
            $fields[] = 'at.type_name';
        }
        
        return implode(",\n            ", $fields);
    }
    
    /**
     * Get all awards for a faculty member
     */
    public function getByFacultyId($facultyId) {
        $facultyId = filter_var($facultyId, FILTER_VALIDATE_INT);
        if ($facultyId === false) {
            return [];
        }

        $cols = $this->getColumnMappings();

        $fields = ['aa.award_id'];

        if ($cols['award_type_id']) {
            $fields[] = "aa.{$cols['award_type_id']} as award_type_id";
        }
        if ($cols['award_name']) {
            $fields[] = "aa.{$cols['award_name']} as award_name";
        }
        if ($cols['awarding_organization']) {
            $fields[] = "aa.{$cols['awarding_organization']} as awarding_organization";
        }
        if ($cols['year_awarded']) {
            $fields[] = "aa.{$cols['year_awarded']} as year_awarded";
        }
        if ($cols['description']) {
            $fields[] = "aa.{$cols['description']} as description";
        }
        if ($cols['prize_amount']) {
            $fields[] = "aa.{$cols['prize_amount']} as prize_amount";
        }
        if ($cols['is_national']) {
            $fields[] = "aa.{$cols['is_national']} as is_national";
        }
        if ($cols['is_international']) {
            $fields[] = "aa.{$cols['is_international']} as is_international";
        }

        $fields[] = 'aa.faculty_id';
        $fields[] = 'at.type_name';

        $select_fields = implode(",\n            ", $fields);

        // Build ORDER BY clause
        $orderBy = $cols['year_awarded']
            ? "aa.{$cols['year_awarded']} DESC, aa.award_id DESC"
            : "aa.award_id DESC";

        $joinClause = $cols['award_type_id']
            ? "LEFT JOIN award_types at ON aa.{$cols['award_type_id']} = at.award_type_id"
            : "LEFT JOIN award_types at ON 1=0"; // Dummy join if column doesn't exist

        $stmt = $this->db->prepare("
            SELECT {$select_fields}
            FROM {$this->awards_table} aa
            {$joinClause}
            WHERE aa.faculty_id = ?
            ORDER BY {$orderBy}
        ");

        $stmt->execute([$facultyId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get award by ID (from awards_achievements table)
     */
    public function getById($awardId) {
        $awardId = filter_var($awardId, FILTER_VALIDATE_INT);
        if ($awardId === false) {
            return false;
        }

        $cols = $this->getColumnMappings();

        $fields = ['aa.award_id'];

        if ($cols['award_type_id']) {
            $fields[] = "aa.{$cols['award_type_id']} as award_type_id";
        }
        if ($cols['award_name']) {
            $fields[] = "aa.{$cols['award_name']} as award_name";
        }
        if ($cols['awarding_organization']) {
            $fields[] = "aa.{$cols['awarding_organization']} as awarding_organization";
        }
        if ($cols['year_awarded']) {
            $fields[] = "aa.{$cols['year_awarded']} as year_awarded";
        }
        if ($cols['description']) {
            $fields[] = "aa.{$cols['description']} as description";
        }
        if ($cols['prize_amount']) {
            $fields[] = "aa.{$cols['prize_amount']} as prize_amount";
        }
        if ($cols['is_national']) {
            $fields[] = "aa.{$cols['is_national']} as is_national";
        }
        if ($cols['is_international']) {
            $fields[] = "aa.{$cols['is_international']} as is_international";
        }

        $fields[] = 'aa.faculty_id';
        $fields[] = 'at.type_name';
        $fields[] = 'f.first_name';
        $fields[] = 'f.last_name';

        $select_fields = implode(",\n            ", $fields);

        $joinClause = $cols['award_type_id']
            ? "LEFT JOIN award_types at ON aa.{$cols['award_type_id']} = at.award_type_id"
            : "LEFT JOIN award_types at ON 1=0";

        $stmt = $this->db->prepare("
            SELECT {$select_fields}
            FROM {$this->awards_table} aa
            LEFT JOIN faculty f ON aa.faculty_id = f.faculty_id
            {$joinClause}
            WHERE aa.award_id = ?
        ");

        $stmt->execute([$awardId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create new award
     */
    public function create($data) {
        $cols = $this->getColumnMappings();

        // Build INSERT query dynamically based on available columns
        $fields = [];
        $placeholders = [];
        $values = [];

        if ($cols['faculty_id']) {
            $fields[] = $cols['faculty_id'];
            $placeholders[] = '?';
            $values[] = filter_var($data['faculty_id'], FILTER_VALIDATE_INT);
        }

        if ($cols['award_type_id']) {
            $fields[] = $cols['award_type_id'];
            $placeholders[] = '?';
            $values[] = isset($data['award_type_id']) ? filter_var($data['award_type_id'], FILTER_VALIDATE_INT) : null;
        }

        if ($cols['award_name']) {
            $fields[] = $cols['award_name'];
            $placeholders[] = '?';
            $values[] = filter_var($data['award_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        }

        if ($cols['awarding_organization']) {
            $fields[] = $cols['awarding_organization'];
            $placeholders[] = '?';
            $values[] = filter_var($data['awarding_organization'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        }

        if ($cols['year_awarded']) {
            $fields[] = $cols['year_awarded'];
            $placeholders[] = '?';
            $values[] = filter_var($data['year_awarded'], FILTER_VALIDATE_INT);
        }

        if ($cols['description']) {
            $fields[] = $cols['description'];
            $placeholders[] = '?';
            $values[] = isset($data['description']) ? filter_var($data['description'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null;
        }

        if ($cols['prize_amount']) {
            $fields[] = $cols['prize_amount'];
            $placeholders[] = '?';
            $values[] = isset($data['prize_amount']) ? filter_var($data['prize_amount'], FILTER_VALIDATE_FLOAT) : 0;
        }

        if ($cols['is_national']) {
            $fields[] = $cols['is_national'];
            $placeholders[] = '?';
            $values[] = isset($data['is_national']) ? filter_var($data['is_national'], FILTER_VALIDATE_INT) : 0;
        }

        if ($cols['is_international']) {
            $fields[] = $cols['is_international'];
            $placeholders[] = '?';
            $values[] = isset($data['is_international']) ? filter_var($data['is_international'], FILTER_VALIDATE_INT) : 0;
        }

        if (empty($fields)) {
            throw new \Exception("No valid columns found in awards_achievements table");
        }

        $stmt = $this->db->prepare("
            INSERT INTO {$this->awards_table}
            (" . implode(', ', $fields) . ")
            VALUES (" . implode(', ', $placeholders) . ")
        ");

        $stmt->execute($values);
        return $this->db->lastInsertId();
    }
    
    /**
     * Update award
     */
    public function update($awardId, $data) {
        $awardId = filter_var($awardId, FILTER_VALIDATE_INT);
        if ($awardId === false) {
            return false;
        }
        
        $cols = $this->getColumnMappings();
        
        // Build SET clause dynamically
        $setClauses = [];
        $values = [];
        
        if ($cols['award_type_id']) {
            $setClauses[] = "{$cols['award_type_id']} = ?";
            $values[] = isset($data['award_type_id']) ? filter_var($data['award_type_id'], FILTER_VALIDATE_INT) : null;
        }
        
        if ($cols['award_name']) {
            $setClauses[] = "{$cols['award_name']} = ?";
            $values[] = filter_var($data['award_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        }
        
        if ($cols['awarding_organization']) {
            $setClauses[] = "{$cols['awarding_organization']} = ?";
            $values[] = filter_var($data['awarding_organization'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        }
        
        if ($cols['year_awarded']) {
            $setClauses[] = "{$cols['year_awarded']} = ?";
            $values[] = filter_var($data['year_awarded'], FILTER_VALIDATE_INT);
        }
        
        if ($cols['description']) {
            $setClauses[] = "{$cols['description']} = ?";
            $values[] = isset($data['description']) ? filter_var($data['description'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null;
        }
        
        if ($cols['prize_amount']) {
            $setClauses[] = "{$cols['prize_amount']} = ?";
            $values[] = isset($data['prize_amount']) ? filter_var($data['prize_amount'], FILTER_VALIDATE_FLOAT) : 0;
        }
        
        if ($cols['is_national']) {
            $setClauses[] = "{$cols['is_national']} = ?";
            $values[] = isset($data['is_national']) ? filter_var($data['is_national'], FILTER_VALIDATE_INT) : 0;
        }
        
        if ($cols['is_international']) {
            $setClauses[] = "{$cols['is_international']} = ?";
            $values[] = isset($data['is_international']) ? filter_var($data['is_international'], FILTER_VALIDATE_INT) : 0;
        }
        
        if (empty($setClauses)) {
            return false;
        }
        
        $values[] = $awardId;
        
        $stmt = $this->db->prepare("
            UPDATE {$this->awards_table} 
            SET " . implode(', ', $setClauses) . "
            WHERE award_id = ?
        ");
        
        return $stmt->execute($values);
    }
    
    /**
     * Delete award
     */
    public function delete($awardId) {
        $awardId = filter_var($awardId, FILTER_VALIDATE_INT);
        if ($awardId === false) {
            return false;
        }

        $stmt = $this->db->prepare("DELETE FROM {$this->awards_table} WHERE award_id = ?");
        return $stmt->execute([$awardId]);
    }
    
    /**
     * Get award types
     */
    public function getAwardTypes() {
        $stmt = $this->db->query("SELECT * FROM award_types ORDER BY type_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get faculty ID by award ID
     */
    public function getFacultyIdByAwardId($awardId) {
        $awardId = filter_var($awardId, FILTER_VALIDATE_INT);
        if ($awardId === false) {
            return false;
        }

        $stmt = $this->db->prepare("
            SELECT faculty_id
            FROM {$this->awards_table}
            WHERE award_id = ?
        ");
        $stmt->execute([$awardId]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ? $result['faculty_id'] : false;
    }
}