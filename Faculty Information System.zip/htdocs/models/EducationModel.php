<?php
/**
 * Education Model
 * Handles all education-related database operations
 */

namespace Models;

use Config\Database;
use PDO;

class EducationModel {
    private $db;
    private $table = 'education';
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all education records for a faculty member
     */
    public function getByFacultyId($facultyId) {
        $facultyId = filter_var($facultyId, FILTER_VALIDATE_INT);
        if ($facultyId === false) {
            return [];
        }
        
        $stmt = $this->db->prepare("
            SELECT * FROM {$this->table} 
            WHERE faculty_id = ? 
            ORDER BY year_graduated DESC
        ");
        $stmt->execute([$facultyId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get education record by ID
     */
    public function getById($educationId) {
        $educationId = filter_var($educationId, FILTER_VALIDATE_INT);
        if ($educationId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE education_id = ?");
        $stmt->execute([$educationId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create new education record
     */
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO {$this->table} 
            (faculty_id, school_name, degree_title, field_of_study, year_graduated)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            filter_var($data['faculty_id'], FILTER_VALIDATE_INT),
            filter_var($data['school_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['degree_title'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            isset($data['field_of_study']) ? filter_var($data['field_of_study'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            filter_var($data['year_graduated'], FILTER_VALIDATE_INT)
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Update education record
     */
    public function update($educationId, $data) {
        $educationId = filter_var($educationId, FILTER_VALIDATE_INT);
        if ($educationId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("
            UPDATE {$this->table} 
            SET school_name = ?, degree_title = ?, field_of_study = ?, year_graduated = ?
            WHERE education_id = ?
        ");
        
        return $stmt->execute([
            filter_var($data['school_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            filter_var($data['degree_title'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            isset($data['field_of_study']) ? filter_var($data['field_of_study'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            filter_var($data['year_graduated'], FILTER_VALIDATE_INT),
            $educationId
        ]);
    }
    
    /**
     * Delete education record
     */
    public function delete($educationId) {
        $educationId = filter_var($educationId, FILTER_VALIDATE_INT);
        if ($educationId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE education_id = ?");
        return $stmt->execute([$educationId]);
    }
}