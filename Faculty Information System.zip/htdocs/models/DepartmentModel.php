<?php
/**
 * Department Model
 * Handles all department-related database operations
 */

namespace Models;

use Config\Database;
use PDO;

class DepartmentModel {
    private $db;
    private $table = 'departments';
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }
    
    /**
     * Get all departments
     */
    public function getAll() {
        $stmt = $this->db->query("SELECT * FROM {$this->table} ORDER BY department_name");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    /**
     * Get department by ID
     */
    public function getById($departmentId) {
        $departmentId = filter_var($departmentId, FILTER_VALIDATE_INT);
        if ($departmentId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("SELECT * FROM {$this->table} WHERE department_id = ?");
        $stmt->execute([$departmentId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    /**
     * Create new department
     */
    public function create($data) {
        $stmt = $this->db->prepare("
            INSERT INTO {$this->table} (department_name, department_code)
            VALUES (?, ?)
        ");
        
        $stmt->execute([
            filter_var($data['department_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            isset($data['department_code']) ? filter_var($data['department_code'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null
        ]);
        
        return $this->db->lastInsertId();
    }
    
    /**
     * Update department
     */
    public function update($departmentId, $data) {
        $departmentId = filter_var($departmentId, FILTER_VALIDATE_INT);
        if ($departmentId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("
            UPDATE {$this->table} 
            SET department_name = ?, department_code = ?
            WHERE department_id = ?
        ");
        
        return $stmt->execute([
            filter_var($data['department_name'], FILTER_SANITIZE_FULL_SPECIAL_CHARS),
            isset($data['department_code']) ? filter_var($data['department_code'], FILTER_SANITIZE_FULL_SPECIAL_CHARS) : null,
            $departmentId
        ]);
    }
    
    /**
     * Delete department
     */
    public function delete($departmentId) {
        $departmentId = filter_var($departmentId, FILTER_VALIDATE_INT);
        if ($departmentId === false) {
            return false;
        }
        
        $stmt = $this->db->prepare("DELETE FROM {$this->table} WHERE department_id = ?");
        return $stmt->execute([$departmentId]);
    }
}