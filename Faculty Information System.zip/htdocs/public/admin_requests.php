<?php
/**
 * Admin Requests - User Account Management
 */

// Load initialization first to define all constants
require_once dirname(__DIR__) . '/init.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$config_path = dirname(__DIR__) . '/config/mail_config.php';
if (!file_exists($config_path)) {
    die("Error: mail_config.php not found at: " . $config_path);
}

require_once $config_path;
require_once dirname(__DIR__) . '/config/Database.php';
require_once dirname(__DIR__) . '/vendor/autoload.php';

use Config\Database;
use Config\MailConfig;
use Config\BaseUrl;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

try {
    $database = Database::getInstance();
    $pdo = $database->getConnection();

    // Define base URL for email links
    if (!defined('BASE_URL')) {
        // Auto-detect or use configured base URL
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $host = $_SERVER['HTTP_HOST'];
        $script_dir = dirname($_SERVER['SCRIPT_NAME']);
        
        // Remove 'public' or 'admin' from path if present
        $script_dir = str_replace('/public', '', $script_dir);
        $script_dir = str_replace('/admin', '', $script_dir);
        $script_dir = rtrim($script_dir, '/\\');
        
        define('BASE_URL', $protocol . "://" . $host . $script_dir);
    }
    
    if (!$pdo) {
        die("Error: Failed to establish database connection.");
    }
} catch (Exception $e) {
    die("Database connection error: " . $e->getMessage());
}

function createNotification($pdo, $user_id, $title, $message, $type = 'info', $link = null) {
    try {
        $stmt = $pdo->prepare("
            INSERT INTO notifications (user_id, title, message, type, link, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        return $stmt->execute([$user_id, $title, $message, $type, $link]);
    } catch (PDOException $e) {
        error_log("Error creating notification: " . $e->getMessage());
        return false;
    }
}

function sendVerificationEmailSafely($email, $username, $token) {
    try {
        // Check if email credentials are configured
        if (!defined('EMAIL_USERNAME') || !defined('EMAIL_PASSWORD') || empty(EMAIL_USERNAME) || empty(EMAIL_PASSWORD)) {
            $username_val = defined('EMAIL_USERNAME') ? EMAIL_USERNAME : 'NOT_DEFINED';
            $password_status = (defined('EMAIL_PASSWORD') && !empty(EMAIL_PASSWORD)) ? "set" : "empty";
            error_log("Email credentials not configured. EMAIL_USERNAME: " . $username_val . ", EMAIL_PASSWORD: " . $password_status);
            // For development, log the message so admin can see what's happening
            if (defined('DEBUG_MODE') && DEBUG_MODE) {
                error_log("Would send email to: $email, Subject: Verify Your Email Address");
            }
            return false;
        }
        
        // Use sendVerificationLink instead of MailConfig
        return sendVerificationLink($email, $username, $token);
        
    } catch (Exception $e) {
        error_log("Error sending verification email: " . $e->getMessage());
        return false;
    }
}

if (isset($_POST['approve_faculty'])) {
    $user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $username = filter_var($_POST['username'], FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    
    if (!$user_id || !$email || !$username) {
        $_SESSION['error'] = "Invalid input data.";
        header("Location: admin_requests.php");
        exit();
    }
    
    $token = bin2hex(random_bytes(32));
    $expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
    
    try {
        $stmt = $pdo->prepare("
            UPDATE users 
            SET is_active = 1,
                email_verified = 0,
                verification_token = ?,
                verification_token_expiry = ?,
                updated_at = NOW(),
                updated_by = ?
            WHERE user_id = ?
        ");
        
        if ($stmt->execute([$token, $expiry, $_SESSION['user_id'], $user_id])) {
            if (sendVerificationEmailSafely($email, $username, $token)) {
                createNotification(
                    $pdo,
                    $user_id,
                    '🎉 Account Activated',
                    'Congratulations! Your account has been activated by the administrator. A verification email has been sent to ' . htmlspecialchars($email) . '. Please verify your email address within 24 hours to complete the activation process.',
                    'success',
                    'verify_email.php'
                );
                
                createNotification(
                    $pdo,
                    $_SESSION['user_id'],
                    'Faculty Account Approved',
                    "You have approved the account for {$username} ({$email}). Verification email sent successfully.",
                    'info',
                    'admin_requests.php'
                );
                
                $_SESSION['success'] = "✓ Account approved! Verification email sent to {$email}. User has 24 hours to verify.";
            } else {
                $_SESSION['warning'] = "Account approved but email failed to send. Please use 'Resend Verification' to send the email.";
            }
        } else {
            $_SESSION['error'] = "Failed to approve account. Please try again.";
        }
        
    } catch (PDOException $e) {
        error_log("Approve faculty error: " . $e->getMessage());
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    
    header("Location: admin_requests.php");
    exit();
}

// Delete user (delete whole row)
if (isset($_POST['delete_email'])) {
    $user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);

    if (!$user_id) {
        $_SESSION['error'] = "Invalid user ID.";
        header("Location: admin_requests.php");
        exit();
    }

    try {
        $pdo->beginTransaction();

        // Delete related notifications
        $stmt = $pdo->prepare("DELETE FROM notifications WHERE user_id = ?");
        $stmt->execute([$user_id]);

        // Try to delete from other tables that might exist - suppress errors if tables don't exist
        try {
            $stmt = $pdo->prepare("DELETE FROM sessions WHERE user_id = ?");
            $stmt->execute([$user_id]);
        } catch (PDOException $e) {
            // Table doesn't exist, continue
        }
        
        try {
            $stmt = $pdo->prepare("DELETE FROM password_resets WHERE user_id = ?");
            $stmt->execute([$user_id]);
        } catch (PDOException $e) {
            // Table doesn't exist, continue
        }
        
        try {
            $stmt = $pdo->prepare("DELETE FROM user_activity WHERE user_id = ?");
            $stmt->execute([$user_id]);
        } catch (PDOException $e) {
            // Table doesn't exist, continue
        }

        // Delete user
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
        $result = $stmt->execute([$user_id]);

        if ($result && $stmt->rowCount() > 0) {
            $pdo->commit();
            $_SESSION['success'] = "User deleted successfully.";
        } else {
            $pdo->rollBack();
            $_SESSION['error'] = "User not found or already deleted.";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Error deleting user: " . $e->getMessage();
        error_log("Delete user error: " . $e->getMessage());
    }

    header("Location: admin_requests.php");
    exit();
}

if (isset($_POST['resend_verification'])) {
    $user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);
    
    if (!$user_id) {
        $_SESSION['error'] = "Invalid user ID.";
        header("Location: admin_requests.php");
        exit();
    }

    // Delete email (remove user email)
    if (isset($_POST['delete_email'])) {
        $user_id = $_POST['user_id'];

        try {
            $stmt = $pdo->prepare("
                UPDATE users 
                SET email = NULL,
                    updated_at = NOW(),
                    updated_by = ?
                WHERE user_id = ?
            ");
            $stmt->execute([$_SESSION['user_id'], $user_id]);
        } catch (PDOException $e) {
            die("Error deleting email: " . $e->getMessage());
        }

        header("Location: admin_requests.php");
        exit();
    }
    
    try {
        // Get user details
        $stmt = $pdo->prepare("
            SELECT user_id, email, username, email_verified, is_active 
            FROM users 
            WHERE user_id = ?
        ");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            $_SESSION['error'] = "User not found.";
            header("Location: admin_requests.php");
            exit();
        }
        
        // Check if already verified
        if ($user['email_verified'] == 1) {
            $_SESSION['warning'] = "User's email is already verified.";
            header("Location: admin_requests.php");
            exit();
        }
        
        // Check if account is active
        if ($user['is_active'] == 0) {
            $_SESSION['warning'] = "User account is not yet approved. Please approve it first.";
            header("Location: admin_requests.php");
            exit();
        }
        
        // Generate new verification token
        $token = bin2hex(random_bytes(32));
        $expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        // Update verification token
        $update_stmt = $pdo->prepare("
            UPDATE users 
            SET verification_token = ?,
                verification_token_expiry = ?,
                updated_at = NOW()
            WHERE user_id = ?
        ");
        
        if ($update_stmt->execute([$token, $expiry, $user_id])) {
            // Send verification link email
            if (sendVerificationLink($user['email'], $user['username'], $token)) {
                createNotification(
                    $pdo,
                    $user_id,
                    '📧 Verification Link Sent',
                    'A verification link has been sent to ' . htmlspecialchars($user['email']) . '. Please check your inbox and click the link to verify your account within 24 hours.',
                    'info',
                    null
                );
                
                createNotification(
                    $pdo,
                    $_SESSION['user_id'],
                    'Verification Link Sent',
                    "Sent verification link to {$user['username']} ({$user['email']}).",
                    'info',
                    'admin_requests.php'
                );
                
                $_SESSION['success'] = "✅ Verification link sent successfully to {$user['email']}. User has 24 hours to verify.";
            } else {
                $_SESSION['error'] = "Failed to send verification email. Please check email configuration and try again.";
            }
        } else {
            $_SESSION['error'] = "Failed to update verification token.";
        }
    } catch (PDOException $e) {
        error_log("Resend verification error: " . $e->getMessage());
        $_SESSION['error'] = "Database error: " . $e->getMessage();
    }
    
    header("Location: admin_requests.php");
    exit();
}

// Function to send verification link email
function sendVerificationLink($email, $username, $token) {
    $mail = new PHPMailer(true);
    
    try {
        // Check if email credentials are configured
        if (!defined('EMAIL_USERNAME') || !defined('EMAIL_PASSWORD') || empty(EMAIL_USERNAME) || empty(EMAIL_PASSWORD)) {
            error_log("Email credentials not configured");
            return false;
        }
        
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'muchachasxd1@gmail.com';
        $mail->Password   = 'ceqazkeqqzgmelkv';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        $mail->setFrom('muchachasxd1@gmail.com', 'Faculty Information System');
        $mail->addAddress($email, $username);
        
        $mail->isHTML(true);
        $mail->Subject = 'Verify Your Email Address';
        
        // Generate verification URL
        if (defined('BASE_URL')) {
        $verification_url = BASE_URL . "/verify_email.php?token=" . $token;
    } else {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $host = $_SERVER['HTTP_HOST'];
        $base_path = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
        $verification_url = $protocol . "://" . $host . $base_path . "/verify_email.php?token=" . $token;
    }

    // Log the URL for debugging
    error_log("📧 Generated verification URL: " . $verification_url);
        
        $mail->Body = "
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #990000 0%, #7a0000 100%); 
                             color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .verify-button { 
                        display: inline-block;
                        background: #990000;
                        color: white;
                        padding: 15px 30px;
                        text-decoration: none;
                        border-radius: 5px;
                        margin: 20px 0;
                        font-weight: bold;
                    }
                    .link-box {
                        background: white;
                        padding: 15px;
                        border-radius: 5px;
                        word-break: break-all;
                        font-size: 12px;
                        color: #666;
                        margin-top: 20px;
                    }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h1>🔐 Email Verification</h1>
                    </div>
                    <div class='content'>
                        <p>Hello <strong>{$username}</strong>,</p>
                        <p>Welcome to the Faculty Information System! Please verify your email address by clicking the button below:</p>
                        <div style='text-align: center;'>
                            <a href='{$verification_url}' class='verify-button'>Verify Email Address</a>
                        </div>
                        <p>Or copy and paste this link into your browser:</p>
                        <div class='link-box'>{$verification_url}</div>
                        <p><strong>This link will expire in 24 hours.</strong></p>
                        <p>If you didn't create an account, please ignore this email.</p>
                    </div>
                </div>
            </body>
            </html>
        ";
        
        $mail->send();
        error_log("✅ Verification link sent to: " . $email);
        return true;
    } catch (Exception $e) {
        error_log("❌ Mail Error: " . $mail->ErrorInfo);
        return false;
    }
}

if (isset($_POST['reject_account'])) {
    $user_id = filter_var($_POST['user_id'], FILTER_VALIDATE_INT);
    $reason = filter_var($_POST['reason'] ?? 'No reason provided', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    
    if (!$user_id) {
        $_SESSION['error'] = "Invalid user ID.";
        header("Location: admin_requests.php");
        exit();
    }
    
    try {
        $stmt = $pdo->prepare("SELECT username, email FROM users WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            createNotification(
                $pdo,
                $user_id,
                '❌ Account Request Rejected',
                "We're sorry, but your account request has been rejected. Reason: {$reason}. Please contact the administrator for more information.",
                'danger',
                null
            );
            
            $stmt = $pdo->prepare("
                UPDATE users 
                SET is_active = 0,
                    updated_at = NOW(),
                    updated_by = ?
                WHERE user_id = ?
            ");
            $stmt->execute([$_SESSION['user_id'], $user_id]);
            
            createNotification(
                $pdo,
                $_SESSION['user_id'],
                'Account Request Rejected',
                "You have rejected the account for {$user['username']} ({$user['email']}).",
                'warning',
                'admin_requests.php'
            );
            
            $_SESSION['success'] = "Account request rejected for {$user['username']}";
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    
    header("Location: admin_requests.php");
    exit();
}

try {
    $stmt = $pdo->query("DESCRIBE users");
    $user_columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $stmt = $pdo->query("SHOW TABLES LIKE 'user_types'");
    $user_types_exists = $stmt->rowCount() > 0;
    
    if ($user_types_exists) {
        $stmt = $pdo->query("DESCRIBE user_types");
        $type_columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (in_array('user_type_name', $type_columns)) {
            $type_column = 'ut.user_type_name';
        } elseif (in_array('type_name', $type_columns)) {
            $type_column = 'ut.type_name';
        } elseif (in_array('name', $type_columns)) {
            $type_column = 'ut.name';
        } else {
            $type_column = "'N/A'";
        }
        
        $query = "
            SELECT 
                u.user_id, 
                u.username, 
                u.email, 
                u.email_verified, 
                u.is_active, 
                u.created_at,
                {$type_column} as user_type_name
            FROM users u
            LEFT JOIN user_types ut ON u.user_type_id = ut.user_type_id
            ORDER BY u.created_at DESC
        ";
    } else {
        if (in_array('user_type', $user_columns)) {
            $user_type_select = 'u.user_type as user_type_name';
        } elseif (in_array('user_type_id', $user_columns)) {
            $user_type_select = 'u.user_type_id as user_type_name';
        } else {
            $user_type_select = "'N/A' as user_type_name";
        }
        
        $query = "
            SELECT 
                u.user_id, 
                u.username, 
                u.email, 
                u.email_verified, 
                u.is_active, 
                u.created_at,
                {$user_type_select}
            FROM users u
            ORDER BY u.created_at DESC
        ";
    }
    
    $stmt = $pdo->query($query);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $_SESSION['error'] = "Error fetching users: " . $e->getMessage();
    $users = [];
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Requests</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        h1 {
            color: #333;
            margin-top: 0;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        .bg-success { background: #28a745; color: white; }
        .bg-warning { background: #ffc107; color: black; }
        .bg-danger { background: #dc3545; color: white; }
        .bg-info { background: #17a2b8; color: white; }
        
        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            margin: 2px;
            transition: all 0.3s;
        }
        .btn-success { background: #28a745; color: white; }
        .btn-success:hover { background: #218838; }
        .btn-warning { background: #ffc107; color: black; }
        .btn-warning:hover { background: #e0a800; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-danger:hover { background: #c82333; }
        .btn:hover { opacity: 0.9; }
        .btn-info { background: #17a2b8; color: white; }
        .btn-info:hover { background: #138496; }
        
        .alert {
            padding: 12px 20px;
            margin: 10px 0;
            border-radius: 4px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-danger { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert-warning { background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }
        
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 20px;
            font-size: 14px;
        }
        th, td { 
            padding: 12px; 
            text-align: left; 
            border-bottom: 1px solid #dee2e6; 
        }
        th { 
            background: #f8f9fa; 
            font-weight: 600;
            color: #495057;
        }
        tr:hover {
            background: #f9f9f9;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
            flex-wrap: wrap;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        
        .empty-state i {
            font-size: 48px;
            margin-bottom: 10px;
        }
        
        .header-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-controls">
            <h1>
                <i class="fas fa-user-check"></i>
                User Management & Requests
            </h1>
            <a href="dashboard.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['warning'])): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                <?php echo htmlspecialchars($_SESSION['warning']); unset($_SESSION['warning']); ?>
            </div>
        <?php endif; ?>
        
        <?php if ((defined('EMAIL_USERNAME') && !empty(EMAIL_USERNAME)) === false || (defined('EMAIL_PASSWORD') && !empty(EMAIL_PASSWORD)) === false): ?>
            <div class="alert" style="background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; margin-bottom: 20px;">
                <i class="fas fa-envelope" style="font-size: 18px;"></i>
                <div>
                    <strong>⚠️ Email Not Configured</strong><br>
                    <small style="display: block; margin-top: 4px;">
                        Email verification will not work until Gmail SMTP credentials are configured. 
                        <a href="email_diagnostic.php" style="color: #856404; font-weight: bold; text-decoration: underline;">
                            Click here to setup email →
                        </a>
                    </small>
                </div>
            </div>
        <?php endif; ?>
        
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Email Verified</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="8" style="border: none;">
                            <div class="empty-state">
                                <i class="fas fa-inbox"></i>
                                <p><strong>No users found</strong></p>
                            </div>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['user_id']); ?></td>
                        <td><strong><?php echo htmlspecialchars($row['username']); ?></strong></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['user_type_name'] ?? 'N/A'); ?></td>
                        <td>
                            <?php if ($row['is_active']): ?>
                                <span class="badge bg-success"><i class="fas fa-check"></i> Active</span>
                            <?php else: ?>
                                <span class="badge bg-warning"><i class="fas fa-clock"></i> Pending</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($row['email_verified']): ?>
                                <span class="badge bg-success"><i class="fas fa-check-circle"></i> Verified</span>
                            <?php elseif ($row['is_active']): ?>
                                <span class="badge bg-warning"><i class="fas fa-clock"></i> Pending Verification</span>
                            <?php else: ?>
                                <span class="badge bg-danger"><i class="fas fa-times-circle"></i> Not Verified</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo date('M j, Y', strtotime($row['created_at'])); ?></td>
                        <td>
                            <td>
                            <div class="action-buttons">
                                <?php if (!$row['is_active']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                        <input type="hidden" name="email" value="<?php echo $row['email']; ?>">
                                        <input type="hidden" name="username" value="<?php echo $row['username']; ?>">
                                        <button type="submit" name="approve_faculty" class="btn btn-success" title="Approve & Send Verification">
                                            <i class="fas fa-check"></i> Approve
                                        </button>
                                    </form>
                                    
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                        <input type="hidden" name="reason" value="Account request denied by administrator">
                                        <button type="submit" name="reject_account" class="btn btn-danger" 
                                                onclick="return confirm('Are you sure you want to reject this account?')" 
                                                title="Reject Account">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </form>
                                <?php endif; ?>

                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                    <button type="submit" name="delete_email"
                                            class="btn btn-secondary"
                                            onclick="return confirm('Are you sure you want to delete this email?')"
                                            title="Delete Email">
                                        <i class="fas fa-trash"></i> Delete Email
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>