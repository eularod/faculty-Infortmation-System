<?php
require_once '../init.php';

use Models\FacultyModel;
use Models\EducationModel;
use Models\ResearchModel;
use Models\AwardModel;

requireLogin();

// Validate faculty ID
$faculty_id = (int)($_GET['id'] ?? 0);
if ($faculty_id <= 0) {
    redirect('view_faculty.php');
}

// Initialize models
$facultyModel = new FacultyModel();
$educationModel = new EducationModel();
$researchModel = new ResearchModel();
$awardModel = new AwardModel();

// Fetch all data
$faculty = $facultyModel->getById($faculty_id);
if (!$faculty) {
    redirect('view_faculty.php');
}

$education = $educationModel->getByFacultyId($faculty_id);
$research = $researchModel->getByFacultyId($faculty_id);
$awards = $awardModel->getByFacultyId($faculty_id);

// Check if email is verified (fetch from users table)
$email_verified = false;
if (!empty($faculty['user_id'])) {
    $db = \Config\Database::getInstance()->getConnection();
    $stmt = $db->prepare("SELECT email_verified FROM users WHERE user_id = ?");
    $stmt->execute([$faculty['user_id']]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
    $email_verified = ($user_data && $user_data['email_verified'] == 1);
}

// Check permissions
$canEdit = canEditFaculty($faculty_id);
$canDelete = canDeleteFaculty($faculty_id);

// Helper functions
function getStatusBadgeClass($status) {
    if (empty($status)) {
        return 'badge-info';
    }
    
    $status_lower = strtolower($status);
    $badges = [
        'published' => 'badge-success',
        'ongoing' => 'badge-warning',
        'in progress' => 'badge-warning',
        'completed' => 'badge-info',
        'pending' => 'badge-secondary'
    ];
    return $badges[$status_lower] ?? 'badge-info';
}

function displayPhoto($faculty) {
    $photo_path = $faculty['photo_url'] ?? $faculty['photo'] ?? null;
    $initials = strtoupper(substr($faculty['first_name'], 0, 1) . substr($faculty['last_name'], 0, 1));
    
    if (!empty($photo_path) && file_exists($photo_path)) {
        return '
            <img src="' . htmlspecialchars($photo_path) . '" 
                 alt="' . htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']) . '" 
                 class="photo-thumb"
                 onerror="this.style.display=\'none\'; this.nextElementSibling.style.display=\'flex\';">
            <div class="profile-photo" style="display:none;">' . $initials . '</div>';
    }
    return '<div class="profile-photo">' . $initials . '</div>';
}

function renderEmptyState($message, $addLink = null, $canEdit = false) {
    echo '<div class="empty-state"><p>' . htmlspecialchars($message) . '</p>';
    if ($canEdit && $addLink) {
        echo '<a href="' . htmlspecialchars($addLink) . '" class="btn btn-success">Add Record</a>';
    }
    echo '</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Profile - <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?></title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        .verified-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #27ae60;
            color: white;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
            vertical-align: middle;
            transition: all 0.3s ease;
        }
        
        .verified-badge i {
            font-size: 14px;
        }
        
        .unverified-badge {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: #e74c3c;
            color: white;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-left: 8px;
            vertical-align: middle;
            transition: all 0.3s ease;
        }
        
        .unverified-badge i {
            font-size: 14px;
        }

        /* Animation for badge updates */
        @keyframes badgeUpdate {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .badge-updating {
            animation: badgeUpdate 0.5s ease;
        }
    </style>
 
    <script>
        function confirmDelete(type, name) {
            return confirm('Are you sure you want to delete this ' + type + '?\n\n' + name + '\n\nThis action cannot be undone.');
        }

        // Auto-refresh verification status every 5 seconds
        let currentVerificationStatus = <?php echo $email_verified ? 'true' : 'false'; ?>;
        
        function checkVerificationStatus() {
            fetch('check_verification_status.php?user_id=<?php echo $faculty['user_id'] ?? 0; ?>')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.verified !== currentVerificationStatus) {
                        // Status changed, refresh the page with animation
                        const badge = document.querySelector('.verified-badge, .unverified-badge');
                        if (badge) {
                            badge.classList.add('badge-updating');
                        }
                        
                        setTimeout(() => {
                            location.reload();
                        }, 500);
                    }
                })
                .catch(error => {
                    console.log('Verification check:', error);
                });
        }

        // Check every 5 seconds if not verified
        <?php if (!$email_verified): ?>
        setInterval(checkVerificationStatus, 5000);
        <?php endif; ?>
    </script>
</head>
<body>

    <?php include '../components/email_verification_banner.php'; ?>

    <div class="navbar">
        <h1>Faculty Profile</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="view_faculty.php">Back to List</a>

            <?php include '../components/notification_bell.php'; ?>

            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>

        <div class="profile-header">
            <div><?php echo displayPhoto($faculty); ?></div>
            
            <div class="profile-info">
                <h2><?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?></h2>
                
                <div class="info-row">
                    <span class="info-label">Email:</span>
                    <span class="info-value">
                        <a href="mailto:<?php echo htmlspecialchars($faculty['email']); ?>">
                            <?php echo htmlspecialchars($faculty['email'] ?? 'N/A'); ?>
                        </a>
                        <?php if ($email_verified): ?>
                            <span class="verified-badge" title="Email Verified">
                                <i class="fas fa-check-circle"></i>
                                Verified
                            </span>
                        <?php else: ?>
                            <span class="unverified-badge" title="Email Not Verified">
                                <i class="fas fa-exclamation-circle"></i>
                                Not Verified
                            </span>
                        <?php endif; ?>
                    </span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Phone:</span>
                    <span class="info-value"><?php echo htmlspecialchars($faculty['phone'] ?? 'N/A'); ?></span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Department:</span>
                    <span class="info-value"><?php echo htmlspecialchars($faculty['department_name'] ?? 'N/A'); ?></span>
                </div>
                
                <div class="info-row">
                    <span class="info-label">Address:</span>
                    <span class="info-value"><?php echo htmlspecialchars($faculty['address'] ?? 'N/A'); ?></span>
                </div>
                
                <div class="action-buttons" style="margin-top: 20px;">
                    <?php if ($canEdit): ?>
                        <a href="edit_faculty.php?id=<?php echo $faculty_id; ?>" class="btn btn-warning">Edit Profile</a>
                        <a href="add_education.php?faculty_id=<?php echo $faculty_id; ?>" class="btn btn-primary btn-small">Add Education</a>
                        <a href="add_research.php?faculty_id=<?php echo $faculty_id; ?>" class="btn btn-primary btn-small">Add Research</a>
                        <a href="add_award.php?faculty_id=<?php echo $faculty_id; ?>" class="btn btn-primary btn-small">Add Award</a>
                    <?php endif; ?>
                    <?php if ($canDelete): ?>
                        <a href="delete_faculty.php?id=<?php echo $faculty_id; ?>" class="btn btn-danger" 
                           onclick="return confirmDelete('faculty member', '<?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?>')">Delete</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Educational Background -->
        <div class="section">
            <h3>Educational Background</h3>
            <?php if (count($education) > 0): ?>
                <?php foreach ($education as $edu): ?>
                    <div class="record-card">
                        <h4><?php echo htmlspecialchars($edu['degree_title'] ?? 'N/A'); ?></h4>
                        <div class="record-meta">
                            <strong><?php echo htmlspecialchars($edu['school_name'] ?? 'N/A'); ?></strong>
                            <?php if (!empty($edu['field_of_study'])): ?>
                                | <?php echo htmlspecialchars($edu['field_of_study']); ?>
                            <?php endif; ?>
                            | Graduated: <?php echo htmlspecialchars($edu['year_graduated'] ?? 'N/A'); ?>
                            
                            <?php if ($canEdit): ?>
                                <a href="edit_education.php?id=<?php echo $edu['education_id']; ?>" class="action-btn-small btn-edit">Edit</a>
                                <a href="delete_education.php?id=<?php echo $edu['education_id']; ?>" 
                                   class="action-btn-small btn-delete" 
                                   onclick="return confirmDelete('education record', '<?php echo htmlspecialchars($edu['degree_title'] ?? 'this record'); ?>')">Delete</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else:
                renderEmptyState('No education records found', $canEdit);
            endif; ?>
        </div>
        
        <!-- Research & Publications -->
        <div class="section">
            <h3>Research & Publications</h3>
            <?php if (count($research) > 0): ?>
                <?php foreach ($research as $res): ?>
                    <div class="record-card">
                        <h4>
                            <?php echo htmlspecialchars($res['research_title'] ?? 'N/A'); ?>
                            <span class="badge <?php echo getStatusBadgeClass($res['status'] ?? ''); ?>">
                                <?php echo htmlspecialchars($res['status'] ?? 'N/A'); ?>
                            </span>
                        </h4>
                        <div class="record-meta">
                            <strong>Type:</strong> <?php echo htmlspecialchars($res['research_type'] ?? 'N/A'); ?> | 
                            <strong>Year:</strong> <?php echo htmlspecialchars($res['year'] ?? 'N/A'); ?>
                            
                            <?php if ($canEdit): ?>
                                <a href="edit_research.php?id=<?php echo $res['research_id']; ?>" class="action-btn-small btn-edit">Edit</a>
                                <a href="delete_research.php?id=<?php echo $res['research_id']; ?>" 
                                   class="action-btn-small btn-delete" 
                                   onclick="return confirmDelete('research record', '<?php echo htmlspecialchars($res['research_title'] ?? 'this record'); ?>')">Delete</a>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($res['description'])): ?>
                            <p style="margin-top: 10px; color: #666; font-size: 14px;"><?php echo nl2br(htmlspecialchars($res['description'])); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: 
                renderEmptyState('No research records found', $canEdit);
            endif; ?>
        </div>

        <!-- Awards & Achievements -->
        <div class="section">
            <h3>Awards & Achievements</h3>
            <?php if (count($awards) > 0): ?>
                <?php foreach ($awards as $award): ?>
                    <div class="record-card">
                        <h4>
                            <?php echo htmlspecialchars($award['award_name'] ?? 'N/A'); ?>
                            <?php if ($award['is_international']): ?>
                                <span class="badge" style="background: #2196F3;">International</span>
                            <?php elseif ($award['is_national']): ?>
                                <span class="badge" style="background: #4CAF50;">National</span>
                            <?php endif; ?>
                        </h4>
                        <div class="record-meta">
                            <?php if (!empty($award['awarding_organization'])): ?>
                                <strong>Awarded by:</strong> <?php echo htmlspecialchars($award['awarding_organization']); ?> | 
                            <?php endif; ?>
                            <strong>Year:</strong> <?php echo htmlspecialchars($award['year_awarded'] ?? 'N/A'); ?>
                            <?php if ($award['prize_amount'] > 0): ?>
                                | <strong>Prize:</strong> ₱<?php echo number_format($award['prize_amount'], 2); ?>
                            <?php endif; ?>
                            
                            <?php if ($canEdit): ?>
                                <a href="edit_award.php?id=<?php echo $award['award_id']; ?>" class="action-btn-small btn-edit">Edit</a>
                                <a href="delete_award.php?id=<?php echo $award['award_id']; ?>" 
                                   class="action-btn-small btn-delete" 
                                   onclick="return confirmDelete('award', '<?php echo htmlspecialchars($award['award_name'] ?? 'this award'); ?>')">Delete</a>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($award['description'])): ?>
                            <p style="margin-top: 10px; color: #666; font-size: 14px;"><?php echo nl2br(htmlspecialchars($award['description'])); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: 
                renderEmptyState('No awards or achievements found', $canEdit);
            endif; ?>
        </div>
    </div>

    <script src="../assets/js/notifications.js"></script>

    <script>
        // Initialize notifications when page loads
        document.addEventListener('DOMContentLoaded', function() {
            NotificationManager.init();
            console.log('Notification system initialized!');
        });
        
        // Test function to create a notification (remove in production)
        async function createTestNotification() {
            try {
                const response = await fetch('../helpers/create_test_notification.php', {
                    method: 'POST'
                });
                const data = await response.json();
                
                if (data.success) {
                    alert('Test notification created! Check your notification bell.');
                    // Refresh notifications
                    NotificationManager.updateUnreadCount();
                    if (NotificationManager.isOpen) {
                        NotificationManager.loadNotifications();
                    }
                } else {
                    alert('Failed to create notification: ' + data.message);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Error creating test notification');
            }
        }
    </script>
    <?php include '../components/notification_popup.php'; ?>
</body>
</html>