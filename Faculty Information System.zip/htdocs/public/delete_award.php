<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

requireLogin();

$db = Database::getInstance()->getConnection();

$award_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);
$return_to = filter_var($_GET['return'] ?? 'detail', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

if (!$award_id) {
    session()->setFlash('error', 'Invalid award ID.');
    redirect('view_faculty.php');
}

$stmt = $db->prepare("
    SELECT a.*, f.faculty_id, f.first_name, f.last_name
    FROM faculty_awards a 
    INNER JOIN faculty f ON a.faculty_id = f.faculty_id
    WHERE a.award_id = ?
");
$stmt->execute([$award_id]);
$award = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$award) {
    session()->setFlash('error', 'Award record not found.');
    redirect('view_faculty.php');
}

$faculty_id = $award['faculty_id'];

if (!canEditFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to delete this award.");
    redirect('view_faculty_detail.php?id=' . $faculty_id);
}

$redirect_url = $return_to === 'view_awards' 
    ? 'view_awards.php' 
    : 'view_faculty_detail.php?id=' . $faculty_id;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        session()->setFlash('error', 'Invalid security token. Please try again.');
        redirect($redirect_url);
    }
    
    try {
        $stmt = $db->prepare("DELETE FROM faculty_awards WHERE award_id = ?");
        $stmt->execute([$award_id]);
        
        session()->setFlash('success', 'Award deleted successfully.');
        redirect($redirect_url);
        
    } catch (PDOException $e) {
        error_log("Error deleting award: " . $e->getMessage());
        session()->setFlash('error', 'An error occurred while deleting the award. Please try again.');
        redirect($redirect_url);
    }
}

$csrf_token = generateCSRFToken();

function getScopeDisplay($award) {
    if ($award['is_international']) {
        return 'International';
    } elseif ($award['is_national']) {
        return 'National';
    }
    return 'Local';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Award</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    <style>
        .warning-box {
            background: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .record-info-box {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Delete Award</h1>
        <div>
            <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>">Back to Profile</a>
            <a href="view_awards.php">Awards List</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>
        
        <div class="warning-box">
            <h3>⚠️ Confirm Deletion</h3>
            <p>Are you sure you want to delete this award? This action cannot be undone.</p>
        </div>
        
        <div class="record-info-box">
            <h4>Award Details:</h4>
            <p><strong>Faculty:</strong> <?php echo htmlspecialchars($award['first_name'] . ' ' . $award['last_name']); ?></p>
            <p><strong>Award Name:</strong> <?php echo htmlspecialchars($award['award_name']); ?></p>
            <p><strong>Organization:</strong> <?php echo htmlspecialchars($award['awarding_organization']); ?></p>
            <p><strong>Year Awarded:</strong> <?php echo htmlspecialchars($award['year_awarded']); ?></p>
            <p><strong>Scope:</strong> <?php echo htmlspecialchars(getScopeDisplay($award)); ?></p>
            <?php if ($award['prize_amount'] > 0): ?>
                <p><strong>Prize Amount:</strong> ₱<?php echo number_format($award['prize_amount'], 2); ?></p>
            <?php endif; ?>
            <?php if (!empty($award['description'])): ?>
                <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars(substr($award['description'], 0, 200))); ?>
                <?php echo strlen($award['description']) > 200 ? '...' : ''; ?></p>
            <?php endif; ?>
        </div>
        
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            
            <div class="btn-group">
                <button type="submit" class="btn btn-danger">Delete Award</button>
                <a href="<?php echo htmlspecialchars($redirect_url); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>