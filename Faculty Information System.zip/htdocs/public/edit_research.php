<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

$db = Database::getInstance()->getConnection();

requireLogin();

$errors = [];
$success = '';

// Get research_id from URL
$research_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($research_id <= 0) {
    session()->setFlash('error', 'Invalid research ID.');
    redirect('view_faculty.php');
}

// Fetch research record
$stmt = $db->prepare("SELECT * FROM research WHERE research_id = ?");
$stmt->execute([$research_id]);
$research = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$research) {
    session()->setFlash('error', 'Research record not found.');
    redirect('view_faculty.php');
}

$faculty_id = $research['faculty_id'];

// Check if user has permission to edit
if (!canEditFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to edit this research record.");
    redirect('view_faculty_detail.php?id=' . $faculty_id);
}

// Fetch research types and statuses
$researchTypes = getResearchTypes($db);
$researchStatuses = getResearchStatuses($db);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid security token. Please try again.";
    }
    
    if (empty($errors)) {
        $research_title = trim($_POST['research_title'] ?? '');
        $research_type_id = intval($_POST['research_type_id'] ?? 0);
        $status_id = intval($_POST['status_id'] ?? 0);
        $year = trim($_POST['year'] ?? '');
        $description = trim($_POST['description'] ?? '');

        // Validation
        if ($error = validateRequired($research_title, 'Research title')) {
            $errors[] = $error;
        }
        if ($research_type_id <= 0) {
            $errors[] = 'Please select a research type';
        }
        if ($status_id <= 0) {
            $errors[] = 'Please select a status';
        }
        if ($error = validateRequired($year, 'Year')) {
            $errors[] = $error;
        }
        
        // Year validation
        if (empty($errors) && ($error = validateYear($year))) {
            $errors[] = $error;
        }
        
        // Length validation
        if ($error = validateLength($research_title, 1, 255, 'Research title')) {
            $errors[] = $error;
        }
        
        // Validate that research_type_id and status_id exist in database
        if (empty($errors)) {
            $stmt = $db->prepare("SELECT COUNT(*) FROM research_types WHERE research_type_id = ?");
            $stmt->execute([$research_type_id]);
            if ($stmt->fetchColumn() == 0) {
                $errors[] = "Invalid research type selected.";
            }
            
            $stmt = $db->prepare("SELECT COUNT(*) FROM research_statuses WHERE status_id = ?");
            $stmt->execute([$status_id]);
            if ($stmt->fetchColumn() == 0) {
                $errors[] = "Invalid status selected.";
            }
        }

        if (empty($errors)) {
            try {
                $stmt = $db->prepare(
                    "UPDATE research 
                    SET research_title = ?, research_type_id = ?, status_id = ?, year = ?, description = ? 
                    WHERE research_id = ?"
                );
                
                $stmt->execute([
                    sanitize($research_title),
                    $research_type_id,
                    $status_id,
                    intval($year),
                    !empty($description) ? sanitize($description) : null,
                    $research_id
                ]);

                // ✅ SEND NOTIFICATION AFTER SUCCESSFUL UPDATE
                $stmt = $db->prepare("SELECT f.user_id FROM faculty f 
                                    INNER JOIN research r ON f.faculty_id = r.faculty_id 
                                    WHERE r.research_id = ?");
                $stmt->execute([$research_id]);
                $faculty_user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!empty($faculty_user['user_id'])) {
                    require_once __DIR__ . '/../classes/FacultyNotification.php';
                    $notifier = new FacultyNotification();
                    
                    // Get research type name for better notification message
                    $stmt = $db->prepare("SELECT type_name FROM research_types WHERE research_type_id = ?");
                    $stmt->execute([$research_type_id]);
                    $research_type_name = $stmt->fetchColumn();
                    
                    // Send appropriate notification based on type
                    if (strtolower($research_type_name) === 'publication') {
                        $notifier->notifyPublicationUpdated(
                            $faculty_user['user_id'], 
                            $research_title
                        );
                    } else {
                        $notifier->notifyResearchAdded(
                            $faculty_user['user_id'], 
                            $research_title
                        );
                    }
                }

                $success = 'Research record updated successfully!';
                
                // Refresh the data
                $stmt = $db->prepare("SELECT * FROM research WHERE research_id = ?");
                $stmt->execute([$research_id]);
                $research = $stmt->fetch(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                error_log("Error updating research: " . $e->getMessage());
                $errors[] = "An error occurred while updating the research record. Please try again.";
            }
        }
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Research Record</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    
</head>
<body>
    <div class="navbar">
        <h1>Edit Research Record</h1>
        <div>
            <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>">Back to Profile</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="form-card">
            <h2>Edit Research Record</h2>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <strong>Please fix the following errors:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                
                <div class="form-group">
                    <label for="research_title">Research Title *</label>
                    <input type="text" id="research_title" name="research_title" 
                           value="<?php echo htmlspecialchars($research['research_title'] ?? ''); ?>"
                           placeholder="Enter research or publication title"
                           maxlength="255" required>
                </div>

                <div class="form-group">
                    <label for="research_type_id">Research Type *</label>
                    <select id="research_type_id" name="research_type_id" required>
                        <option value="">Select Type</option>
                        <?php foreach ($researchTypes as $type): ?>
                            <option value="<?php echo $type['research_type_id']; ?>" 
                                    <?php echo ($research['research_type_id'] == $type['research_type_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars(ucfirst($type['type_name'])); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="status_id">Status *</label>
                    <select id="status_id" name="status_id" required>
                        <option value="">Select Status</option>
                        <?php foreach ($researchStatuses as $status): ?>
                            <option value="<?php echo $status['status_id']; ?>" 
                                    <?php echo ($research['status_id'] == $status['status_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars(ucfirst($status['status_name'])); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="year">Year *</label>
                    <input type="number" id="year" name="year" 
                           value="<?php echo htmlspecialchars($research['year'] ?? ''); ?>" 
                           min="1950" max="<?php echo date('Y') + 10; ?>" 
                           placeholder="<?php echo date('Y'); ?>"
                           required>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"
                              placeholder="Brief description of the research or publication..."><?php echo htmlspecialchars($research['description'] ?? ''); ?></textarea>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update Research</button>
                    <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>