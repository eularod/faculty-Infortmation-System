<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
requireLogin();

use Config\Database;

$db = Database::getInstance()->getConnection();

$success = '';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid security token. Please try again.";
    }
    
    if (empty($errors)) {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password)) {
            $errors[] = "Current password is required.";
        }
        if (empty($new_password)) {
            $errors[] = "New password is required.";
        }
        if (empty($confirm_password)) {
            $errors[] = "Please confirm your new password.";
        }
        
        if (!empty($new_password) && strlen($new_password) < 6) {
            $errors[] = "New password must be at least 6 characters long.";
        }
        
        if ($new_password !== $confirm_password) {
            $errors[] = "New password and confirmation do not match.";
        }
        
        if (empty($errors)) {
            $stmt = $db->prepare("SELECT password FROM users WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !password_verify($current_password, $user['password'])) {
                $errors[] = "Current password is incorrect.";
            }
        }
        
        if (empty($errors)) {
            try {
                $new_password_hash = password_hash($new_password, PASSWORD_BCRYPT);
                
                $stmt = $db->prepare("UPDATE users SET password = ? WHERE user_id = ?");
                $stmt->execute([$new_password_hash, $_SESSION['user_id']]);
                
                $success = "Password changed successfully!";
                
                if (isset($_SESSION['using_default_password'])) {
                    unset($_SESSION['using_default_password']);
                }
            } catch (PDOException $e) {
                error_log("Error changing password: " . $e->getMessage());
                $errors[] = "An error occurred while changing your password. Please try again.";
            }
        }
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="navbar">
        <h1>Change Password</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="form-container">
            <h2>Change Your Password</h2>
            <p>For security reasons, please use a strong password that you haven't used before.</p>
            
            <?php if ($success): ?>
                <div class="alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <?php if (!empty($errors)): ?>
                <div class="alert-error">
                    <strong>Please fix the following errors:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                
                <div class="form-group">
                    <label for="current_password">Current Password <span style="color: red;">*</span></label>
                    <div class="password-input">
                        <input type="password" id="current_password" name="current_password" required autocomplete="current-password">
                        <span class="toggle-password" onclick="togglePasswordVisibility('current_password')">👁️</span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="new_password">New Password <span style="color: red;">*</span></label>
                    <div class="password-input">
                        <input type="password" id="new_password" name="new_password" required minlength="6" autocomplete="new-password">
                        <span class="toggle-password" onclick="togglePasswordVisibility('new_password')">👁️</span>
                    </div>
                    <small>Minimum 6 characters</small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password <span style="color: red;">*</span></label>
                    <div class="password-input">
                        <input type="password" id="confirm_password" name="confirm_password" required minlength="6" autocomplete="new-password">
                        <span class="toggle-password" onclick="togglePasswordVisibility('confirm_password')">👁️</span>
                    </div>
                </div>
                
                <div class="password-requirements">
                    <h4>Password Requirements:</h4>
                    <ul>
                        <li>At least 6 characters long</li>
                        <li>Should not be the same as your current password</li>
                        <li>Recommended: Mix of letters, numbers, and special characters</li>
                    </ul>
                </div>
                
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">Change Password</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function togglePasswordVisibility(fieldId) {
            const field = document.getElementById(fieldId);
            const button = field.nextElementSibling;
            
            if (field.type === 'password') {
                field.type = 'text';
                button.textContent = '🙈';
            } else {
                field.type = 'password';
                button.textContent = '👁️';
            }
        }
    </script>
</body>
</html>