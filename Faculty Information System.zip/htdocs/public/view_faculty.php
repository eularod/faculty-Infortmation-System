<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}

use Models\FacultyModel;
use Models\DepartmentModel;

requireLogin();

// Initialize models
$facultyModel = new FacultyModel();
$departmentModel = new DepartmentModel();

// Get filters
$filters = [
    'search' => $_GET['search'] ?? '',
    'department_id' => $_GET['department'] ?? ''
];

// Fetch data
$faculty_list = $facultyModel->getAll($filters);
$departments = $departmentModel->getAll();
$currentUserFacultyId = getCurrentFacultyId();

// Helper function for photo display
function displayPhoto($row) {
    $photo_path = $row['photo_url'] ?? $row['photo'] ?? null;
    
    if (!empty($photo_path) && file_exists($photo_path)) {
        return '<img src="' . htmlspecialchars($photo_path) . '" alt="Photo" class="photo-thumb">';
    }
    
    $initials = strtoupper(substr($row['first_name'], 0, 1) . substr($row['last_name'], 0, 1));
    return '<div class="photo-placeholder">' . $initials . '</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Faculty - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

</head>
<body>

    <?php include __DIR__ . '/../components/email_verification_banner.php'; ?>

    <div class="navbar">
        <h1>Faculty List</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>

            <?php include __DIR__ . '/../components/notification_bell.php'; ?>

            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="controls">
            <form method="GET" class="search-form">
                <input type="text" name="search" placeholder="Search by name or email..." 
                       value="<?php echo htmlspecialchars($filters['search']); ?>">
                
                <select name="department">
                    <option value="">All Departments</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo $dept['department_id']; ?>" 
                                <?php echo $filters['department_id'] == $dept['department_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['department_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <button type="submit" class="btn btn-primary">Search</button>
                <a href="view_faculty.php" class="btn btn-warning">Clear</a>
                
                <?php if (isAdmin()): ?>
                <a href="add_faculty.php" class="btn btn-success">Add New Faculty</a>
                <?php endif; ?>
            </form>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Department</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($faculty_list) > 0): ?>
                        <?php foreach ($faculty_list as $row): ?>
                        <?php
                            $isOwnProfile = !isAdmin() && $currentUserFacultyId == $row['faculty_id'];
                            $canEdit = isAdmin() || $isOwnProfile;
                            $canDelete = isAdmin();
                        ?>
                        <tr>
                            <td><?php echo displayPhoto($row); ?></td>
                            <td>
                                <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?>
                                <?php if ($isOwnProfile): ?>
                                    <span class="badge">You</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['phone'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['department_name'] ?? 'N/A'); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="view_faculty_detail.php?id=<?php echo $row['faculty_id']; ?>" 
                                       class="btn btn-primary">View</a>
                                    
                                    <?php if ($canEdit): ?>
                                    <a href="edit_faculty.php?id=<?php echo $row['faculty_id']; ?>" 
                                       class="btn btn-warning">Edit</a>
                                    <?php endif; ?>
                                    
                                    <?php if ($canDelete): ?>
                                    <a href="delete_faculty.php?id=<?php echo $row['faculty_id']; ?>" 
                                       class="btn btn-danger" 
                                       onclick="return confirm('Are you sure you want to delete this faculty member?')">Delete</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 30px; color: #999;">
                                <?php echo ($filters['search'] || $filters['department_id']) 
                                    ? 'No faculty members found matching your search criteria.' 
                                    : 'No faculty members found.'; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="<?php echo asset('assets/js/notifications.js'); ?>"></script>
    
    <script>
        // Initialize notifications when page loads
        document.addEventListener('DOMContentLoaded', function() {
            NotificationManager.init();
            console.log('Notification system initialized!');
        });
    </script>
    <?php include __DIR__ . '/../components/notification_popup.php'; ?>
</body>
</html>