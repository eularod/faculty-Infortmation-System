<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}

use Controllers\ReportController;
use Models\DepartmentModel;
use Models\ResearchModel;
use Config\Database;

$db = Database::getInstance()->getConnection();

requireAdmin();

$reportController = new ReportController();
$departmentModel = new DepartmentModel();
$researchModel = new ResearchModel();

$report_data = null;
$report_type = null;
$filters = [];

// Handle report generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_type = $_POST['report_type'] ?? '';
    
    $filters = [
        'department_id' => $_POST['department_id'] ?? '',
        'year_from' => $_POST['year_from'] ?? '',
        'year_to' => $_POST['year_to'] ?? '',
        'research_status' => $_POST['research_status'] ?? '',
        'research_type' => $_POST['research_type'] ?? ''
    ];
    
    switch ($report_type) {
        case 'faculty_list':
            $report_data = $reportController->generateFacultyListReport($filters);
            break;
        case 'research_summary':
            $report_data = $reportController->generateResearchSummaryReport($filters);
            break;
        case 'department_summary':
            $report_data = $reportController->generateDepartmentSummaryReport($filters);
            break;
        case 'faculty_research':
            $report_data = $reportController->generateFacultyResearchReport($filters);
            break;
        case 'awards_achievements':
            $report_data = $reportController->generateAwardsReport($filters);
            break;
        case 'education_summary':
            $report_data = $reportController->generateEducationSummaryReport($filters);
            break;
    }
}

// Get data for filters
$departments = $departmentModel->getAll();
$research_statuses = $researchModel->getResearchStatuses();
$research_types = $researchModel->getResearchTypes();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="navbar no-print">
        <h1>Faculty Information System - Reports</h1>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></span>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="reports-container">
        <?php displayFlashMessage(); ?>
        
        <!-- Report Selection Form -->
        <div class="report-selector no-print">
            <h2>Generate Reports</h2>
            <form method="POST" action="">
                <div class="report-options">
                    <div class="report-option">
                        <input type="radio" id="faculty_list" name="report_type" value="faculty_list" 
                               <?php echo ($report_type === 'faculty_list') ? 'checked' : ''; ?> required>
                        <label for="faculty_list">
                            <strong>Faculty List</strong>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;">Complete faculty directory</p>
                        </label>
                    </div>
                    
                    <div class="report-option">
                        <input type="radio" id="research_summary" name="report_type" value="research_summary" 
                               <?php echo ($report_type === 'research_summary') ? 'checked' : ''; ?>>
                        <label for="research_summary">
                            <strong>Research Summary</strong>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;">All research activities</p>
                        </label>
                    </div>
                    
                    <div class="report-option">
                        <input type="radio" id="department_summary" name="report_type" value="department_summary" 
                               <?php echo ($report_type === 'department_summary') ? 'checked' : ''; ?>>
                        <label for="department_summary">
                            <strong>Department Summary</strong>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;">Statistics by department</p>
                        </label>
                    </div>
                    
                    <div class="report-option">
                        <input type="radio" id="faculty_research" name="report_type" value="faculty_research" 
                               <?php echo ($report_type === 'faculty_research') ? 'checked' : ''; ?>>
                        <label for="faculty_research">
                            <strong>Faculty Research</strong>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;">Research by faculty member</p>
                        </label>
                    </div>
                    
                    <div class="report-option">
                        <input type="radio" id="awards_achievements" name="report_type" value="awards_achievements" 
                               <?php echo ($report_type === 'awards_achievements') ? 'checked' : ''; ?>>
                        <label for="awards_achievements">
                            <strong>Awards & Achievements</strong>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;">Recognition and honors</p>
                        </label>
                    </div>
                    
                    <div class="report-option">
                        <input type="radio" id="education_summary" name="report_type" value="education_summary" 
                               <?php echo ($report_type === 'education_summary') ? 'checked' : ''; ?>>
                        <label for="education_summary">
                            <strong>Education Summary</strong>
                            <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;">Degrees and qualifications</p>
                        </label>
                    </div>
                </div>
                
                <div class="filters-section">
                    <h3 style="margin-top: 0;">Filters (Optional)</h3>
                    <div class="filters-grid">
                        <div class="filter-group">
                            <label for="department_id">Department</label>
                            <select name="department_id" id="department_id">
                                <option value="">All Departments</option>
                                <?php foreach ($departments as $dept): ?>
                                <option value="<?php echo $dept['department_id']; ?>" 
                                    <?php echo (isset($filters['department_id']) && $filters['department_id'] == $dept['department_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['department_name']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label for="year_from">Year From</label>
                            <input type="number" name="year_from" id="year_from" 
                                   min="1950" max="<?php echo date('Y') + 10; ?>" 
                                   value="<?php echo htmlspecialchars($filters['year_from'] ?? ''); ?>">
                        </div>
                        
                        <div class="filter-group">
                            <label for="year_to">Year To</label>
                            <input type="number" name="year_to" id="year_to" 
                                   min="1950" max="<?php echo date('Y') + 10; ?>" 
                                   value="<?php echo htmlspecialchars($filters['year_to'] ?? ''); ?>">
                        </div>
                        
                        <div class="filter-group">
                            <label for="research_status">Research Status</label>
                            <select name="research_status" id="research_status">
                                <option value="">All Statuses</option>
                                <?php foreach ($research_statuses as $status): ?>
                                <option value="<?php echo $status['status_id']; ?>" 
                                    <?php echo (isset($filters['research_status']) && $filters['research_status'] == $status['status_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars(ucfirst($status['status_name'])); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label for="research_type">Research Type</label>
                            <select name="research_type" id="research_type">
                                <option value="">All Types</option>
                                <?php foreach ($research_types as $type): ?>
                                <option value="<?php echo $type['research_type_id']; ?>" 
                                    <?php echo (isset($filters['research_type']) && $filters['research_type'] == $type['research_type_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars(ucfirst($type['type_name'])); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="action-buttons">
                    <button type="submit" class="btn btn-primary">📄 Generate Report</button>
                    <a href="dashboard.php" class="btn btn-back">← Back to Dashboard</a>
                </div>
            </form>
        </div>
        
        <!-- Report Results -->
        <?php if ($report_data !== null): ?>
        <div class="report-results" id="reportContent">
            <div class="report-header">
                <div>
                    <h3><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $report_type))); ?></h3>
                    <p style="margin: 5px 0 0 0; color: #666;">Generated on <?php echo date('F d, Y h:i A'); ?></p>
                </div>
                <button onclick="window.print()" class="print-btn no-print">🖨️ Print Report</button>
            </div>
            
            <?php if (empty($report_data)): ?>
                <div class="no-data">
                    No data found for the selected criteria. Try adjusting your filters.
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <?php if (!empty($report_data)): ?>
                                <?php foreach (array_keys($report_data[0]) as $key): ?>
                                    <th><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $key))); ?></th>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($report_data as $row): ?>
                        <tr>
                            <?php foreach ($row as $value): ?>
                                <td><?php echo htmlspecialchars($value ?? 'N/A'); ?></td>
                            <?php endforeach; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>