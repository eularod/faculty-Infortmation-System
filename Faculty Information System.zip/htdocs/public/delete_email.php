<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if (!empty($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    try {
        $pdo->beginTransaction();

        // CRITICAL: Disable foreign key checks temporarily
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

        // Delete from all related tables
        $tables = [
            'faculty',
            'admin_requests',
            'email_logs',
            'notifications',
            'notification_settings',
            'requests',
            'system_logs'
        ];

        foreach ($tables as $table) {
            try {
                $stmt = $pdo->prepare("DELETE FROM `{$table}` WHERE user_id = ?");
                $result = $stmt->execute([$user_id]);
                $deleted = $stmt->rowCount();
                error_log("Deleted {$deleted} rows from {$table} for user_id {$user_id}");
            } catch (PDOException $e) {
                error_log("Error deleting from {$table}: " . $e->getMessage());
                // Continue with other tables even if one fails
            }
        }

        // Finally, delete the user
        $stmt = $pdo->prepare("DELETE FROM users WHERE user_id = ?");
        $result = $stmt->execute([$user_id]);
        $deleted_users = $stmt->rowCount();

        // Re-enable foreign key checks
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

        if ($deleted_users > 0) {
            $pdo->commit();
            $_SESSION['success'] = "User and all associated data deleted successfully.";
            error_log("✓ Successfully deleted user_id {$user_id}");
        } else {
            $pdo->rollBack();
            $_SESSION['error'] = "User not found or already deleted.";
            error_log("✗ User {$user_id} not found");
        }
    } catch (PDOException $e) {
        // Make sure to re-enable foreign keys even on error
        try {
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        } catch (PDOException $fk_error) {
            error_log("Error re-enabling foreign keys: " . $fk_error->getMessage());
        }
        
        $pdo->rollBack();
        $_SESSION['error'] = "Error deleting user: " . $e->getMessage();
        error_log("✗ Delete user error: " . $e->getMessage());
    }
} else {
    $_SESSION['error'] = "No user ID provided.";
}

header("Location: admin_requests.php");
exit();