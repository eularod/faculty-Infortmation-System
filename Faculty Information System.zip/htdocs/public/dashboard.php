<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

requireLogin();

$db = Database::getInstance()->getConnection();

$stats = [
    'faculty' => $db->query("SELECT COUNT(*) FROM faculty")->fetchColumn(),
    'research' => $db->query("SELECT COUNT(*) FROM research")->fetchColumn(),
    'awards' => $db->query("SELECT COUNT(*) FROM awards_achievements")->fetchColumn(),
    'departments' => $db->query("SELECT COUNT(*) FROM departments")->fetchColumn(),
    'users' => $db->query("SELECT COUNT(*) FROM users WHERE is_active = 1")->fetchColumn()
];

$stmt = $db->query(
    "SELECT f.*, d.department_name 
     FROM faculty f 
     LEFT JOIN departments d ON f.department_id = d.department_id 
     ORDER BY f.created_at DESC 
     LIMIT 10"
);
$recent_faculty = $stmt->fetchAll(PDO::FETCH_ASSOC);

$user_profile = null;
if (isset($_SESSION['user_id'])) {
    $stmt = $db->prepare(
        "SELECT f.*, d.department_name,
         (SELECT COUNT(*) FROM research WHERE faculty_id = f.faculty_id) as research_count,
         (SELECT COUNT(*) FROM awards_achievements WHERE faculty_id = f.faculty_id) as awards_count
         FROM faculty f
         LEFT JOIN departments d ON f.department_id = d.department_id
         WHERE f.user_id = ?"
    );
    $stmt->execute([$_SESSION['user_id']]);
    $user_profile = $stmt->fetch(PDO::FETCH_ASSOC);
}

$using_default = false;
if (isset($_SESSION['username']) && strtolower($_SESSION['username']) === 'admin') {
    $stmt = $db->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->execute([$_SESSION['username']]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user_data && password_verify('admin123', $user_data['password'])) {
        $using_default = true;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    
    <?php include __DIR__ . '/../components/email_verification_banner.php'; ?>
    
    <div class="navbar">
        <h1>Faculty Information System</h1>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?> (<?php echo ucfirst($_SESSION['user_type']); ?>)</span>
            
            <?php include '../components/notification_bell.php'; ?>
            
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <?php if ($using_default): ?>
        <div class="security-warning">
            <h3>Security Warning</h3>
            <p>You are currently using the default admin password. For security reasons, please <a href="change_pass.php">change your password</a> immediately.</p>
        </div>
        <?php endif; ?>

        <?php displayFlashMessage(); ?>
        
        <?php if ($user_profile): ?>
        <div class="profile-section">
            <a href="view_faculty_detail.php?id=<?php echo $user_profile['faculty_id']; ?>" class="profile-card">
                <div class="profile-avatar">
                    <?php echo strtoupper(substr($user_profile['first_name'], 0, 1) . substr($user_profile['last_name'], 0, 1)); ?>
                </div>
                <div class="profile-info">
                    <div class="profile-name"><?php echo htmlspecialchars($user_profile['first_name'] . ' ' . $user_profile['last_name']); ?></div>
                    <div class="profile-details">
                        <span class="profile-detail"><?php echo htmlspecialchars($user_profile['department_name'] ?? 'N/A'); ?></span>
                        <span class="profile-detail"><?php echo htmlspecialchars($user_profile['position'] ?? 'Faculty'); ?></span>
                    </div>
                </div>
            </a>
        </div>
        <?php endif; ?>
        
        <div class="stats">
            <div class="stat-card">
                <h3><?php echo $stats['faculty']; ?></h3>
                <p>Total Faculty</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['research']; ?></h3>
                <p>Total Research</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['awards']; ?></h3>
                <p>Total Awards</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['departments']; ?></h3>
                <p>Departments</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['users']; ?></h3>
                <p>Active Users</p>
            </div>
        </div>
        
        <div class="menu">
            <div class="menu-item">
                <a href="view_faculty.php">
                    <h3>View Faculty</h3>
                    <p>Browse and search faculty members</p>
                </a>
            </div>
            <?php if (isAdmin()): ?>
            <div class="menu-item">
                <a href="add_faculty.php">
                    <h3>Add Faculty</h3>
                    <p>Register new faculty member</p>
                </a>
            </div>
            <?php endif; ?>
            <div class="menu-item">
                <a href="view_research.php">
                    <h3>View Research</h3>
                    <p>Browse research and publications</p>
                </a>
            </div>
            <div class="menu-item">
                <a href="view_awards.php">
                    <h3>View Awards</h3>
                    <p>Browse awards and achievements</p>
                </a>
            </div>
            <?php if (isAdmin()): ?>
            <div class="menu-item">
                <a href="manage_users.php">
                    <h3>Manage Users</h3>
                    <p>User accounts and permissions</p>
                </a>
            </div>
            <div class="menu-item">
                <a href="admin_requests.php">
                    <h3>Admin Requests</h3>
                    <p>Approve or reject user account requests</p>
                </a>
            </div>
            <div class="menu-item">
                <a href="kpi_dashboard.php">
                    <h3>KPI Dashboard</h3>
                    <p>Analytics and key performance indicators</p>
                </a>
            </div>
            <div class="menu-item">
                <a href="reports.php">
                    <h3>Reports</h3>
                    <p>Generate and print reports</p>
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="recent-section">
            <h2>Recent Faculty Members</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Department</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_faculty as $row): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['department_name'] ?? 'N/A'); ?></td>
                        <td><a href="view_faculty_detail.php?id=<?php echo $row['faculty_id']; ?>" class="btn">View</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="<?php echo asset('assets/js/notifications.js'); ?>"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            NotificationManager.init();
            console.log('Notification system initialized!');
        });
    </script>
</body>
</html>