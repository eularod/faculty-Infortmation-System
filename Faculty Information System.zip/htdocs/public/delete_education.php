<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

requireLogin();

$db = Database::getInstance()->getConnection();

$education_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);

if (!$education_id) {
    session()->setFlash('error', 'Invalid education ID.');
    redirect('view_faculty.php');
}

$stmt = $db->prepare("
    SELECT e.*, f.faculty_id, f.first_name, f.last_name 
    FROM education e 
    INNER JOIN faculty f ON e.faculty_id = f.faculty_id 
    WHERE e.education_id = ?
");
$stmt->execute([$education_id]);
$education = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$education) {
    session()->setFlash('error', 'Education record not found.');
    redirect('view_faculty.php');
}

$faculty_id = $education['faculty_id'];

if (!canEditFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to delete this education record.");
    redirect('view_faculty_detail.php?id=' . $faculty_id);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        session()->setFlash('error', 'Invalid security token. Please try again.');
        redirect('view_faculty_detail.php?id=' . $faculty_id);
    }
    
    try {
        $stmt = $db->prepare("DELETE FROM education WHERE education_id = ?");
        $stmt->execute([$education_id]);
        
        session()->setFlash('success', 'Education record deleted successfully.');
        redirect('view_faculty_detail.php?id=' . $faculty_id);
        
    } catch (PDOException $e) {
        error_log("Error deleting education: " . $e->getMessage());
        session()->setFlash('error', 'An error occurred while deleting the education record. Please try again.');
        redirect('view_faculty_detail.php?id=' . $faculty_id);
    }
}

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Education Record</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    <style>
        .warning-box {
            background: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .record-info-box {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Delete Education Record</h1>
        <div>
            <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>">Back to Profile</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>
        
        <div class="warning-box">
            <h3>⚠️ Confirm Deletion</h3>
            <p>Are you sure you want to delete this education record? This action cannot be undone.</p>
        </div>
        
        <div class="record-info-box">
            <h4>Education Record Details:</h4>
            <p><strong>Faculty:</strong> <?php echo htmlspecialchars($education['first_name'] . ' ' . $education['last_name']); ?></p>
            <p><strong>Degree:</strong> <?php echo htmlspecialchars($education['degree_title']); ?></p>
            <p><strong>School:</strong> <?php echo htmlspecialchars($education['school_name']); ?></p>
            <?php if (!empty($education['field_of_study'])): ?>
                <p><strong>Field of Study:</strong> <?php echo htmlspecialchars($education['field_of_study']); ?></p>
            <?php endif; ?>
            <p><strong>Year Graduated:</strong> <?php echo htmlspecialchars($education['year_graduated']); ?></p>
        </div>
        
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            
            <div class="btn-group">
                <button type="submit" class="btn btn-danger">Delete Education Record</button>
                <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>