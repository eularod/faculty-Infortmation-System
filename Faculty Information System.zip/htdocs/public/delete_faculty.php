<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

requireLogin();

$db = Database::getInstance()->getConnection();

$faculty_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);

if (!$faculty_id) {
    session()->setFlash('error', 'Invalid faculty ID.');
    redirect('view_faculty.php');
}

if (!canDeleteFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to delete this faculty member.");
    redirect('view_faculty_detail.php?id=' . $faculty_id);
}

$stmt = $db->prepare("SELECT f.*, u.user_id FROM faculty f LEFT JOIN users u ON f.user_id = u.user_id WHERE f.faculty_id = ?");
$stmt->execute([$faculty_id]);
$faculty = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$faculty) {
    session()->setFlash('error', 'Faculty member not found.');
    redirect('view_faculty.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        session()->setFlash('error', 'Invalid security token. Please try again.');
        redirect('view_faculty_detail.php?id=' . $faculty_id);
    }
    
    try {
        $db->beginTransaction();
        
        $db->prepare("DELETE FROM education WHERE faculty_id = ?")->execute([$faculty_id]);
        $db->prepare("DELETE FROM research WHERE faculty_id = ?")->execute([$faculty_id]);
        $db->prepare("DELETE FROM faculty_awards WHERE faculty_id = ?")->execute([$faculty_id]);
        
        $photo_path = $faculty['photo_url'] ?? $faculty['photo'] ?? null;
        if (!empty($photo_path) && file_exists($photo_path)) {
            @unlink($photo_path);
        }
        
        $db->prepare("DELETE FROM faculty WHERE faculty_id = ?")->execute([$faculty_id]);
        
        if (!empty($faculty['user_id'])) {
            $db->prepare("DELETE FROM users WHERE user_id = ?")->execute([$faculty['user_id']]);
        }
        
        $db->commit();
        
        session()->setFlash('success', 'Faculty member deleted successfully.');
        redirect('view_faculty.php');
        
    } catch (PDOException $e) {
        $db->rollBack();
        error_log("Error deleting faculty: " . $e->getMessage());
        session()->setFlash('error', 'An error occurred while deleting the faculty member. Please try again.');
        redirect('view_faculty_detail.php?id=' . $faculty_id);
    }
}

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Faculty - Confirm</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    <style>
        .warning-box {
            background: #fff3cd;
            border: 2px solid #ffc107;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .warning-box h3 {
            color: #856404;
            margin-top: 0;
        }
        .warning-box ul {
            margin: 10px 0;
            padding-left: 20px;
        }
        .faculty-info-box {
            background: white;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }
        .faculty-info-box h4 {
            margin-top: 0;
            color: #333;
        }
        .danger-text {
            color: #d32f2f;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1>Delete Faculty Member</h1>
        <div>
            <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>">Back to Profile</a>
            <a href="view_faculty.php">Faculty List</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>
        
        <div class="warning-box">
            <h3>⚠️ Warning: Permanent Deletion</h3>
            <p class="danger-text">This action cannot be undone!</p>
            <p>Deleting this faculty member will also permanently delete:</p>
            <ul>
                <li>All education records</li>
                <li>All research and publications</li>
                <li>All awards and achievements</li>
                <li>Profile photo</li>
                <li>Associated user account (if exists)</li>
            </ul>
        </div>
        
        <div class="faculty-info-box">
            <h4>Faculty Member to Delete:</h4>
            <p><strong>Name:</strong> <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?></p>
            <p><strong>Email:</strong> <?php echo htmlspecialchars($faculty['email']); ?></p>
            <?php if (!empty($faculty['department_name'])): ?>
                <p><strong>Department:</strong> <?php echo htmlspecialchars($faculty['department_name']); ?></p>
            <?php endif; ?>
        </div>
        
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            
            <div class="btn-group">
                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you absolutely sure you want to delete this faculty member? This action CANNOT be undone!');">
                    🗑️ Yes, Delete Permanently
                </button>
                <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>" class="btn btn-secondary">
                    Cancel
                </a>
            </div>
        </form>
    </div>
</body>
</html>