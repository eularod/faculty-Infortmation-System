<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}

use Models\FacultyModel;
use Config\Database;

requireLogin();

$db = Database::getInstance()->getConnection();
$facultyModel = new FacultyModel();

// Get filters from request
$filters = [
    'search' => trim($_GET['search'] ?? ''),
    'faculty' => (int)($_GET['faculty'] ?? 0),
    'year_from' => (int)($_GET['year_from'] ?? 0),
    'year_to' => (int)($_GET['year_to'] ?? 0),
    'scope' => $_GET['scope'] ?? ''
];

// Build query
$query = "
    SELECT 
        aa.award_id,
        aa.award_name,
        aa.awarding_organization,
        aa.year_received AS year_awarded,
        aa.description,
        aa.prize_amount,
        aa.is_national,
        aa.is_international,
        f.first_name,
        f.last_name,
        f.faculty_id,
        d.department_name
    FROM faculty_awards fa
    INNER JOIN awards_achievements aa ON fa.award_id = aa.award_id
    INNER JOIN faculty f ON fa.faculty_id = f.faculty_id
    LEFT JOIN departments d ON f.department_id = d.department_id
    WHERE 1=1
";

$params = [];

// Apply filters
if (!empty($filters['search'])) {
    $query .= " AND (aa.award_name LIKE ? OR aa.awarding_organization LIKE ? OR f.first_name LIKE ? OR f.last_name LIKE ?)";
    $search_param = "%{$filters['search']}%";
    $params = array_fill(0, 4, $search_param);
}

if ($filters['faculty'] > 0) {
    $query .= " AND f.faculty_id = ?";
    $params[] = $filters['faculty'];
}

if ($filters['year_from'] > 0) {
    $query .= " AND aa.year_received >= ?";
    $params[] = $filters['year_from'];
}

if ($filters['year_to'] > 0) {
    $query .= " AND aa.year_received <= ?";
    $params[] = $filters['year_to'];
}

// Scope filter
switch ($filters['scope']) {
    case 'national':
        $query .= " AND aa.is_national = 1";
        break;
    case 'international':
        $query .= " AND aa.is_international = 1";
        break;
    case 'local':
        $query .= " AND aa.is_national = 0 AND aa.is_international = 0";
        break;
}

$query .= " ORDER BY aa.year_received DESC, aa.award_name ASC";

// Execute query
$stmt = $db->prepare($query);
$stmt->execute($params);
$awards_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get faculty list for filter
$faculty_list = $facultyModel->getAll();

// Calculate statistics
$stats = [
    'total' => count($awards_list),
    'national' => count(array_filter($awards_list, fn($a) => $a['is_national'] == 1)),
    'international' => count(array_filter($awards_list, fn($a) => $a['is_international'] == 1)),
    'prize_total' => array_sum(array_column($awards_list, 'prize_amount'))
];

$has_filters = !empty($filters['search']) || $filters['faculty'] || $filters['year_from'] || $filters['year_to'] || $filters['scope'];

// Helper function for scope badge
function getScopeBadge($award) {
    if ($award['is_international']) {
        return '<span class="scope-badge scope-international">International</span>';
    } elseif ($award['is_national']) {
        return '<span class="scope-badge scope-national">National</span>';
    }
    return '<span class="scope-badge scope-local">Local</span>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Awards & Achievements - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="navbar">
        <h1>Awards & Achievements</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="view_faculty.php">Faculty</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>
        
        <!-- Statistics -->
        <div class="stats">
            <div class="stat-card">
                <h3><?php echo $stats['total']; ?></h3>
                <p><?php echo $has_filters ? 'Filtered' : 'Total'; ?> Awards</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['national']; ?></h3>
                <p>National Awards</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $stats['international']; ?></h3>
                <p>International Awards</p>
            </div>
            <div class="stat-card">
                <h3>₱<?php echo number_format($stats['prize_total'], 2); ?></h3>
                <p>Total Prize Amount</p>
            </div>
        </div>

        <!-- Filters -->
        <div class="controls">
            <form method="GET">
                <div class="filter-row">
                    <input type="text" name="search" placeholder="Search by award, organization, or faculty..." value="<?php echo htmlspecialchars($filters['search']); ?>">
                    
                    <select name="faculty">
                        <option value="">All Faculty</option>
                        <?php foreach ($faculty_list as $fac): ?>
                            <option value="<?php echo $fac['faculty_id']; ?>" <?php echo $filters['faculty'] == $fac['faculty_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($fac['first_name'] . ' ' . $fac['last_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <select name="scope">
                        <option value="">All Scopes</option>
                        <option value="national" <?php echo $filters['scope'] === 'national' ? 'selected' : ''; ?>>National</option>
                        <option value="international" <?php echo $filters['scope'] === 'international' ? 'selected' : ''; ?>>International</option>
                        <option value="local" <?php echo $filters['scope'] === 'local' ? 'selected' : ''; ?>>Local</option>
                    </select>

                    <input type="number" name="year_from" placeholder="From Year" min="1950" max="<?php echo date('Y') + 1; ?>" value="<?php echo $filters['year_from'] ?: ''; ?>">
                    <input type="number" name="year_to" placeholder="To Year" min="1950" max="<?php echo date('Y') + 1; ?>" value="<?php echo $filters['year_to'] ?: ''; ?>">
                    
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="view_awards.php" class="btn btn-warning">Clear</a>
                </div>
            </form>
        </div>

        <!-- Awards Grid -->
        <?php if (count($awards_list) > 0): ?>
            <div class="research-grid">
                <?php foreach ($awards_list as $award): ?>
                    <div class="research-card">
                        <div class="research-faculty">
                            👤 <?php echo htmlspecialchars($award['first_name'] . ' ' . $award['last_name']); ?>
                            <?php if (!empty($award['department_name'])): ?>
                                <span style="color: #999;"> | <?php echo htmlspecialchars($award['department_name']); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <h3>
                            🏆 <?php echo htmlspecialchars($award['award_name']); ?>
                            <?php echo getScopeBadge($award); ?>
                        </h3>
                        
                        <div class="research-meta">
                            <strong>Organization:</strong> <?php echo htmlspecialchars($award['awarding_organization']); ?><br>
                            <strong>Year Awarded:</strong> <?php echo htmlspecialchars($award['year_awarded']); ?><br>
                            <?php if ($award['prize_amount'] > 0): ?>
                                <strong>Prize Amount:</strong> ₱<?php echo number_format($award['prize_amount'], 2); ?><br>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (!empty($award['description'])): ?>
                            <div class="research-description">
                                <?php 
                                $desc = htmlspecialchars($award['description']);
                                echo strlen($desc) > 200 ? substr($desc, 0, 200) . '...' : $desc;
                                ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="research-actions">
                            <a href="view_faculty_detail.php?id=<?php echo $award['faculty_id']; ?>" class="btn btn-primary">View Profile</a>
                            <?php if (canEditFaculty($award['faculty_id'])): ?>
                                <a href="edit_award.php?id=<?php echo $award['award_id']; ?>" class="btn btn-warning">Edit</a>
                                <a href="delete_award.php?id=<?php echo $award['award_id']; ?>&return=view_awards" class="btn btn-danger" onclick="return confirm('Delete this award?')">Delete</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <h2>No Awards Found</h2>
                <p style="color: #999; margin-top: 10px;">
                    <?php echo $has_filters ? 'No awards match your current filters. Try adjusting your search criteria.' : 'No awards have been added yet.'; ?>
                </p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>