<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}

use Controllers\ReportController;
use Config\Database;

$db = Database::getInstance()->getConnection();

requireLogin();

$reportController = new ReportController();

// Get all KPI statistics in one call
$stats = $reportController->getKPIStatistics();

// Extract data for use in view with fallback defaults
$faculty_count = $stats['faculty_count'] ?? 0;
$faculty_by_dept = $stats['faculty_by_dept'] ?? [];
$research_by_year = $stats['research_by_year'] ?? [];
$research_by_status = $stats['research_by_status'] ?? [];
$research_by_type = $stats['research_by_type'] ?? [];
$top_researchers = $stats['top_researchers'] ?? [];
$avg_research = $stats['avg_research'] ?? 0;
$education_levels = $stats['education_levels'] ?? [];

// Prepare data for JavaScript charts with null checks
$dept_labels = json_encode(!empty($faculty_by_dept) ? array_column($faculty_by_dept, 'department_name') : []);
$dept_data = json_encode(!empty($faculty_by_dept) ? array_column($faculty_by_dept, 'count') : []);

$year_labels = json_encode(!empty($research_by_year) ? array_column($research_by_year, 'year') : []);
$year_data = json_encode(!empty($research_by_year) ? array_column($research_by_year, 'count') : []);

$status_labels = json_encode(!empty($research_by_status) ? array_column($research_by_status, 'status_name') : []);
$status_data = json_encode(!empty($research_by_status) ? array_column($research_by_status, 'count') : []);

$type_labels = json_encode(!empty($research_by_type) ? array_column($research_by_type, 'type_name') : []);
$type_data = json_encode(!empty($research_by_type) ? array_column($research_by_type, 'count') : []);

$edu_labels = json_encode(!empty($education_levels) ? array_column($education_levels, 'education_level') : []);
$edu_data = json_encode(!empty($education_levels) ? array_column($education_levels, 'count') : []);

// Calculate total research count safely
$total_research = !empty($research_by_year) ? array_sum(array_column($research_by_year, 'count')) : 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KPI Dashboard - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
    <div class="navbar">
        <h1>📊 KPI Dashboard</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="header-section">
            <h2>Faculty Information System - Key Performance Indicators</h2>
            <p>Generated on: <?php echo date('F d, Y h:i A'); ?></p>
            <div class="actions">
                <button onclick="window.print()" class="btn btn-primary">🖨️ Print Dashboard</button>
                <a href="reports.php" class="btn btn-success">📄 View Reports</a>
                <a href="export_data.php" class="btn btn-info">📥 Export Data</a>
            </div>
        </div>
        
        <!-- KPI Cards -->
        <div class="kpi-grid">
            <div class="kpi-card">
                <div class="icon">👥</div>
                <h3><?php echo number_format($faculty_count); ?></h3>
                <p>Total Faculty Members</p>
            </div>
            
            <div class="kpi-card">
                <div class="icon">📚</div>
                <h3><?php echo number_format($total_research); ?></h3>
                <p>Total Research (Last 5 Years)</p>
            </div>
            
            <div class="kpi-card">
                <div class="icon">🏢</div>
                <h3><?php echo number_format(count($faculty_by_dept)); ?></h3>
                <p>Active Departments</p>
            </div>
            
            <div class="kpi-card">
                <div class="icon">📊</div>
                <h3><?php echo number_format($avg_research, 2); ?></h3>
                <p>Avg Research per Faculty</p>
            </div>
        </div>
        
        <!-- Charts -->
        <div class="chart-grid">
            <div class="chart-container">
                <h3>Faculty Distribution by Department</h3>
                <canvas id="deptChart"></canvas>
            </div>
            
            <div class="chart-container">
                <h3>Research Publications by Year</h3>
                <canvas id="yearChart"></canvas>
            </div>
            
            <div class="chart-container">
                <h3>Research by Status</h3>
                <canvas id="statusChart"></canvas>
            </div>
            
            <div class="chart-container">
                <h3>Research by Type</h3>
                <canvas id="typeChart"></canvas>
            </div>
            
            <?php if (!empty($education_levels)): ?>
            <div class="chart-container">
                <h3>Faculty Education Levels</h3>
                <canvas id="eduChart"></canvas>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Top Researchers Table -->
        <div class="table-container">
            <h3>Top 10 Researchers</h3>
            <table>
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Faculty Name</th>
                        <th>Research Count</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $rank = 1;
                    foreach ($top_researchers as $researcher): 
                    ?>
                    <tr>
                        <td><?php echo $rank++; ?></td>
                        <td><?php echo htmlspecialchars($researcher['first_name'] . ' ' . $researcher['last_name']); ?></td>
                        <td><?php echo number_format($researcher['research_count']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($top_researchers)): ?>
                    <tr>
                        <td colspan="3" style="text-align: center;">No research data available</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
        // Chart.js Configuration
        const chartColors = {
            purple: 'rgba(102, 126, 234, 0.8)',
            blue: 'rgba(66, 153, 225, 0.8)',
            green: 'rgba(72, 187, 120, 0.8)',
            orange: 'rgba(237, 137, 54, 0.8)',
            red: 'rgba(245, 101, 101, 0.8)',
            teal: 'rgba(56, 178, 172, 0.8)'
        };
        
        const colorPalette = [
            'rgba(102, 126, 234, 0.8)',
            'rgba(66, 153, 225, 0.8)',
            'rgba(72, 187, 120, 0.8)',
            'rgba(237, 137, 54, 0.8)',
            'rgba(245, 101, 101, 0.8)',
            'rgba(56, 178, 172, 0.8)',
            'rgba(159, 122, 234, 0.8)',
            'rgba(251, 146, 60, 0.8)'
        ];
        
        // Faculty by Department - Bar Chart
        <?php if (!empty($faculty_by_dept)): ?>
        new Chart(document.getElementById('deptChart'), {
            type: 'bar',
            data: {
                labels: <?php echo $dept_labels; ?>,
                datasets: [{
                    label: 'Number of Faculty',
                    data: <?php echo $dept_data; ?>,
                    backgroundColor: chartColors.purple,
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });
        <?php endif; ?>
        
        // Research by Year - Line Chart
        <?php if (!empty($research_by_year)): ?>
        new Chart(document.getElementById('yearChart'), {
            type: 'line',
            data: {
                labels: <?php echo $year_labels; ?>,
                datasets: [{
                    label: 'Publications',
                    data: <?php echo $year_data; ?>,
                    backgroundColor: 'rgba(66, 153, 225, 0.2)',
                    borderColor: 'rgba(66, 153, 225, 1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: true }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });
        <?php endif; ?>
        
        // Research by Status - Doughnut Chart
        <?php if (!empty($research_by_status)): ?>
        new Chart(document.getElementById('statusChart'), {
            type: 'doughnut',
            data: {
                labels: <?php echo $status_labels; ?>,
                datasets: [{
                    data: <?php echo $status_data; ?>,
                    backgroundColor: colorPalette,
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'right'
                    }
                }
            }
        });
        <?php endif; ?>
        
        // Research by Type - Pie Chart
        <?php if (!empty($research_by_type)): ?>
        new Chart(document.getElementById('typeChart'), {
            type: 'pie',
            data: {
                labels: <?php echo $type_labels; ?>,
                datasets: [{
                    data: <?php echo $type_data; ?>,
                    backgroundColor: colorPalette,
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        <?php endif; ?>
        
        // Education Levels - Horizontal Bar Chart
        <?php if (!empty($education_levels)): ?>
        new Chart(document.getElementById('eduChart'), {
            type: 'bar',
            data: {
                labels: <?php echo $edu_labels; ?>,
                datasets: [{
                    label: 'Number of Faculty',
                    data: <?php echo $edu_data; ?>,
                    backgroundColor: chartColors.green,
                    borderColor: 'rgba(72, 187, 120, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });
        <?php endif; ?>
    </script>
</body>
</html>