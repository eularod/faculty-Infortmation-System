<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Controllers\FacultyController;
use Config\Database;

requireLogin();

$db = Database::getInstance()->getConnection();
$errors = [];

$faculty_id = filter_var($_GET['faculty_id'] ?? 0, FILTER_VALIDATE_INT);

if (!$faculty_id) {
    session()->setFlash('error', 'Invalid faculty ID.');
    redirect('view_faculty.php');
}

if (!canEditFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to add awards for this faculty member.");
    redirect('view_faculty_detail.php?id=' . $faculty_id);
}

$stmt = $db->prepare("SELECT first_name, last_name FROM faculty WHERE faculty_id = ?");
$stmt->execute([$faculty_id]);
$faculty = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$faculty) {
    session()->setFlash('error', 'Faculty member not found.');
    redirect('view_faculty.php');
}

$stmt = $db->query("SELECT award_type_id, type_name FROM award_types ORDER BY type_name");
$awardTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid security token. Please try again.";
    }
    
    if (empty($errors)) {
        $award_type_id = filter_var($_POST['award_type_id'] ?? 0, FILTER_VALIDATE_INT);
        $award_name = trim($_POST['award_name'] ?? '');
        $awarding_organization = trim($_POST['awarding_organization'] ?? '');
        $year_awarded = filter_var($_POST['year_awarded'] ?? 0, FILTER_VALIDATE_INT);
        $description = trim($_POST['description'] ?? '');
        $prize_amount = filter_var($_POST['prize_amount'] ?? 0, FILTER_VALIDATE_FLOAT);
        $is_national = isset($_POST['is_national']) ? 1 : 0;
        $is_international = isset($_POST['is_international']) ? 1 : 0;

        if (!$award_type_id) {
            $errors[] = "Please select a valid award type.";
        }
        if ($error = validateRequired($award_name, 'Award name')) {
            $errors[] = $error;
        }
        if ($error = validateRequired($awarding_organization, 'Awarding organization')) {
            $errors[] = $error;
        }
        if (!$year_awarded || $year_awarded < 1900 || $year_awarded > date('Y') + 1) {
            $errors[] = "Please enter a valid year.";
        }
        if ($prize_amount < 0) {
            $errors[] = "Prize amount cannot be negative.";
        }

        if (empty($errors)) {
            try {
                // Start transaction
                $db->beginTransaction();
                
                // Step 1: Insert into awards_achievements table first
                $checkAwardsColumns = $db->query("DESCRIBE awards_achievements");
                $awardsColumns = $checkAwardsColumns->fetchAll(PDO::FETCH_COLUMN);
                
                $awardsFields = [];
                $awardsValues = [];
                $awardsParams = [];
                
                if (in_array('award_type_id', $awardsColumns)) {
                    $awardsFields[] = 'award_type_id';
                    $awardsValues[] = '?';
                    $awardsParams[] = $award_type_id;
                }
                
                if (in_array('award_name', $awardsColumns)) {
                    $awardsFields[] = 'award_name';
                    $awardsValues[] = '?';
                    $awardsParams[] = sanitize($award_name);
                } elseif (in_array('name', $awardsColumns)) {
                    $awardsFields[] = 'name';
                    $awardsValues[] = '?';
                    $awardsParams[] = sanitize($award_name);
                }
                
                if (in_array('awarding_organization', $awardsColumns)) {
                    $awardsFields[] = 'awarding_organization';
                    $awardsValues[] = '?';
                    $awardsParams[] = sanitize($awarding_organization);
                } elseif (in_array('organization', $awardsColumns)) {
                    $awardsFields[] = 'organization';
                    $awardsValues[] = '?';
                    $awardsParams[] = sanitize($awarding_organization);
                }
                
                if (in_array('year_awarded', $awardsColumns)) {
                    $awardsFields[] = 'year_awarded';
                    $awardsValues[] = '?';
                    $awardsParams[] = $year_awarded;
                } elseif (in_array('year', $awardsColumns)) {
                    $awardsFields[] = 'year';
                    $awardsValues[] = '?';
                    $awardsParams[] = $year_awarded;
                }
                
                if (in_array('description', $awardsColumns)) {
                    $awardsFields[] = 'description';
                    $awardsValues[] = '?';
                    $awardsParams[] = sanitize($description);
                }
                
                if (in_array('prize_amount', $awardsColumns)) {
                    $awardsFields[] = 'prize_amount';
                    $awardsValues[] = '?';
                    $awardsParams[] = $prize_amount;
                }
                
                if (in_array('is_national', $awardsColumns)) {
                    $awardsFields[] = 'is_national';
                    $awardsValues[] = '?';
                    $awardsParams[] = $is_national;
                }
                
                if (in_array('is_international', $awardsColumns)) {
                    $awardsFields[] = 'is_international';
                    $awardsValues[] = '?';
                    $awardsParams[] = $is_international;
                }
                
                // Insert into awards_achievements
                $sql = "INSERT INTO awards_achievements (" . implode(', ', $awardsFields) . ") 
                        VALUES (" . implode(', ', $awardsValues) . ")";
                
                $stmt = $db->prepare($sql);
                $stmt->execute($awardsParams);
                
                // Get the inserted award_id
                $award_id = $db->lastInsertId();
                
                // Step 2: Insert into faculty_awards table with the award_id
                $checkFacultyAwardsColumns = $db->query("DESCRIBE faculty_awards");
                $facultyAwardsColumns = $checkFacultyAwardsColumns->fetchAll(PDO::FETCH_COLUMN);
                
                $facultyAwardsFields = [];
                $facultyAwardsValues = [];
                $facultyAwardsParams = [];
                
                if (in_array('faculty_id', $facultyAwardsColumns)) {
                    $facultyAwardsFields[] = 'faculty_id';
                    $facultyAwardsValues[] = '?';
                    $facultyAwardsParams[] = $faculty_id;
                }
                
                if (in_array('award_id', $facultyAwardsColumns)) {
                    $facultyAwardsFields[] = 'award_id';
                    $facultyAwardsValues[] = '?';
                    $facultyAwardsParams[] = $award_id;
                }
                
                // Insert into faculty_awards
                $sql = "INSERT INTO faculty_awards (" . implode(', ', $facultyAwardsFields) . ") 
                        VALUES (" . implode(', ', $facultyAwardsValues) . ")";
                
                $stmt = $db->prepare($sql);
                $stmt->execute($facultyAwardsParams);
                
                // Commit transaction
                $db->commit();

                // Send notification
                $stmt = $db->prepare("SELECT user_id FROM faculty WHERE faculty_id = ?");
                $stmt->execute([$faculty_id]);
                $faculty_user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!empty($faculty_user['user_id'])) {
                    require_once __DIR__ . '/../classes/FacultyNotification.php';
                    $notifier = new FacultyNotification();
                    $notifier->notifyAwardAdded(
                        $faculty_user['user_id'], 
                        $award_name,
                        $awarding_organization
                    );
                }

                session()->setFlash('success', 'Award added successfully!');
                redirect('view_faculty_detail.php?id=' . $faculty_id);
                
            } catch (PDOException $e) {
                // Rollback transaction on error
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
                $errors[] = "Database error: " . $e->getMessage();
                error_log("Database error in add_award.php: " . $e->getMessage());
            }
        }
    }
}

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Award - <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?></title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="navbar">
        <h1>Add Award / Achievement</h1>
        <div>
            <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>">Back to Profile</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>
        
        <div class="form-container">
            <h2>Add Award / Achievement</h2>

            <div class="faculty-info">
                <strong>Faculty:</strong> <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?>
            </div>

            <?php if (!empty($errors)): ?>
            <div class="alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                
                <div class="form-group">
                    <label for="award_type_id">Award Type: <span style="color: red;">*</span></label>
                    <select id="award_type_id" name="award_type_id" required>
                        <option value="">Select Award Type</option>
                        <?php foreach ($awardTypes as $type): ?>
                            <option value="<?php echo $type['award_type_id']; ?>" 
                                    <?php echo (isset($_POST['award_type_id']) && $_POST['award_type_id'] == $type['award_type_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($type['type_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="award_name">Award Name: <span style="color: red;">*</span></label>
                    <input type="text" id="award_name" name="award_name" required 
                           value="<?php echo htmlspecialchars($_POST['award_name'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="awarding_organization">Awarding Organization: <span style="color: red;">*</span></label>
                    <input type="text" id="awarding_organization" name="awarding_organization" required 
                           value="<?php echo htmlspecialchars($_POST['awarding_organization'] ?? ''); ?>">
                </div>

                <div class="form-group">
                    <label for="year_awarded">Year Awarded: <span style="color: red;">*</span></label>
                    <input type="number" id="year_awarded" name="year_awarded" required 
                           min="1900" max="<?php echo date('Y') + 1; ?>" 
                           value="<?php echo htmlspecialchars($_POST['year_awarded'] ?? date('Y')); ?>">
                </div>

                <div class="form-group">
                    <label for="prize_amount">Prize Amount (₱):</label>
                    <input type="number" id="prize_amount" name="prize_amount" 
                           min="0" step="0.01" 
                           value="<?php echo htmlspecialchars($_POST['prize_amount'] ?? '0'); ?>">
                </div>

                <div class="form-group">
                    <label>Scope:</label>
                    <div style="display: flex; gap: 20px; margin-top: 5px;">
                        <label style="display: flex; align-items: center; gap: 5px; font-weight: normal;">
                            <input type="checkbox" name="is_national" value="1" 
                                   <?php echo isset($_POST['is_national']) ? 'checked' : ''; ?>>
                            National
                        </label>
                        <label style="display: flex; align-items: center; gap: 5px; font-weight: normal;">
                            <input type="checkbox" name="is_international" value="1" 
                                   <?php echo isset($_POST['is_international']) ? 'checked' : ''; ?>>
                            International
                        </label>
                    </div>
                    <small style="color: #666; margin-top: 5px; display: block;">Leave both unchecked for local awards</small>
                </div>

                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                </div>

                <div class="btn-group">
                    <button type="submit" class="btn btn-success">Add Award</button>
                    <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>