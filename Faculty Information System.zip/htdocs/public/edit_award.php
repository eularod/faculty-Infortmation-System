<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

$db = Database::getInstance()->getConnection();

requireLogin();

$errors = [];

$award_id = filter_var($_GET['id'] ?? 0, FILTER_VALIDATE_INT);

if (!$award_id) {
    session()->setFlash('error', 'Invalid award ID.');
    redirect('view_faculty.php');
}

$stmt = $db->prepare(
    "SELECT a.*, f.first_name, f.last_name
     FROM awards_achievements a
     LEFT JOIN faculty f ON a.faculty_id = f.faculty_id
     WHERE a.award_id = ?"
);
$stmt->execute([$award_id]);
$award = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$award) {
    session()->setFlash('error', 'Award not found.');
    redirect('view_faculty.php');
}

$faculty_id = $award['faculty_id'];

if (!canEditFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to edit this award.");
    redirect('view_faculty_detail.php?id=' . $faculty_id);
}

$stmt = $db->query("SELECT award_type_id, type_name FROM award_types ORDER BY type_name");
$awardTypes = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid security token. Please try again.";
    }
    
    if (empty($errors)) {
        $award_type_id = filter_var($_POST['award_type_id'] ?? 0, FILTER_VALIDATE_INT);
        $award_name = trim($_POST['award_name'] ?? '');
        $awarding_organization = trim($_POST['awarding_organization'] ?? '');
        $year_awarded = filter_var($_POST['year_awarded'] ?? 0, FILTER_VALIDATE_INT);
        $description = trim($_POST['description'] ?? '');
        $prize_amount = filter_var($_POST['prize_amount'] ?? 0, FILTER_VALIDATE_FLOAT);
        $is_national = isset($_POST['is_national']) ? 1 : 0;
        $is_international = isset($_POST['is_international']) ? 1 : 0;

        if (!$award_type_id) {
            $errors[] = "Please select a valid award type.";
        }
        if ($error = validateRequired($award_name, 'Award name')) {
            $errors[] = $error;
        }
        if ($error = validateRequired($awarding_organization, 'Awarding organization')) {
            $errors[] = $error;
        }
        if (!$year_awarded || $year_awarded < 1900 || $year_awarded > date('Y') + 1) {
            $errors[] = "Please enter a valid year.";
        }
        if ($prize_amount < 0) {
            $errors[] = "Prize amount cannot be negative.";
        }

        if (empty($errors)) {
            try {
                $stmt = $db->prepare(
                    "UPDATE faculty_awards 
                    SET award_type_id = ?, award_name = ?, awarding_organization = ?, 
                        year_awarded = ?, description = ?, prize_amount = ?, 
                        is_national = ?, is_international = ? 
                    WHERE award_id = ?"
                );
                $stmt->execute([
                    $award_type_id,
                    sanitize($award_name),
                    sanitize($awarding_organization),
                    $year_awarded,
                    sanitize($description),
                    $prize_amount,
                    $is_national,
                    $is_international,
                    $award_id
                ]);

                $stmt = $db->prepare("SELECT f.user_id FROM faculty f
                                    LEFT JOIN awards_achievements aa ON f.faculty_id = aa.faculty_id
                                    WHERE aa.award_id = ?");
                $stmt->execute([$award_id]);
                $faculty_user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!empty($faculty_user['user_id'])) {
                    require_once __DIR__ . '/../classes/FacultyNotification.php';
                    $notifier = new FacultyNotification();
                    $notifier->notifyAwardAdded(
                        $faculty_user['user_id'], 
                        $award_name,
                        $awarding_organization
                    );
                }

                session()->setFlash('success', 'Award updated successfully!');
                redirect('view_faculty_detail.php?id=' . $faculty_id);
            } catch (PDOException $e) {
                error_log("Database error in edit_award.php: " . $e->getMessage());
                $errors[] = "An error occurred while updating the award. Please try again.";
            }
        }
    }
}

$csrf_token = generateCSRFToken();

// Determine if we're showing POST data (after validation error) or database data
$isPostBack = $_SERVER['REQUEST_METHOD'] === 'POST';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Award - <?php echo htmlspecialchars($award['first_name'] . ' ' . $award['last_name']); ?></title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="navbar">
        <h1>Edit Award / Achievement</h1>
        <div>
            <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>">Back to Profile</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="form-header">
            <h2>Edit Award for <?php echo htmlspecialchars($award['first_name'] . ' ' . $award['last_name']); ?></h2>
        </div>

        <?php if (!empty($errors)): ?>
        <div class="alert-error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
            
            <div class="form-group">
                <label for="award_type_id">Award Type: *</label>
                <select id="award_type_id" name="award_type_id" required>
                    <option value="">Select Award Type</option>
                    <?php foreach ($awardTypes as $type): 
                        $selectedValue = $isPostBack ? ($_POST['award_type_id'] ?? '') : $award['award_type_id'];
                    ?>
                        <option value="<?php echo $type['award_type_id']; ?>" 
                                <?php echo $selectedValue == $type['award_type_id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($type['type_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="award_name">Award Name: *</label>
                <input type="text" id="award_name" name="award_name" required 
                       value="<?php echo htmlspecialchars($isPostBack ? ($_POST['award_name'] ?? '') : ($award['award_name'] ?? '')); ?>">
            </div>

            <div class="form-group">
                <label for="awarding_organization">Awarding Organization: *</label>
                <input type="text" id="awarding_organization" name="awarding_organization" required 
                       value="<?php echo htmlspecialchars($isPostBack ? ($_POST['awarding_organization'] ?? '') : ($award['awarding_organization'] ?? '')); ?>">
            </div>

            <div class="form-group">
                <label for="year_awarded">Year Awarded: *</label>
                <input type="number" id="year_awarded" name="year_awarded" required 
                       min="1900" max="<?php echo date('Y') + 1; ?>" 
                       value="<?php echo htmlspecialchars($isPostBack ? ($_POST['year_awarded'] ?? '') : ($award['year_awarded'] ?? '')); ?>">
            </div>

            <div class="form-group">
                <label for="prize_amount">Prize Amount (₱):</label>
                <input type="number" id="prize_amount" name="prize_amount" 
                       min="0" step="0.01" 
                       value="<?php echo htmlspecialchars($isPostBack ? ($_POST['prize_amount'] ?? '') : ($award['prize_amount'] ?? '')); ?>">
            </div>

            <div class="form-group">
                <label>Scope:</label>
                <div style="display: flex; gap: 20px; margin-top: 5px;">
                    <label style="display: flex; align-items: center; gap: 5px; font-weight: normal;">
                        <input type="checkbox" name="is_national" value="1" 
                               <?php echo ($isPostBack ? isset($_POST['is_national']) : ($award['is_national'] ?? false)) ? 'checked' : ''; ?>>
                        National
                    </label>
                    <label style="display: flex; align-items: center; gap: 5px; font-weight: normal;">
                        <input type="checkbox" name="is_international" value="1" 
                               <?php echo ($isPostBack ? isset($_POST['is_international']) : ($award['is_international'] ?? false)) ? 'checked' : ''; ?>>
                        International
                    </label>
                </div>
                <small style="color: #666; margin-top: 5px; display: block;">Leave both unchecked for local awards</small>
            </div>

            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($isPostBack ? ($_POST['description'] ?? '') : ($award['description'] ?? '')); ?></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-success">Update Award</button>
                <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>