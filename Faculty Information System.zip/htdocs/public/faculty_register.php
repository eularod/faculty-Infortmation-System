<?php
require_once '../init.php';

use Config\Database;

$db = Database::getInstance()->getConnection();
$errors = [];
$success = '';

/*
|--------------------------------------------------------------------------
| ADDED: Fetch departments for dropdown
|--------------------------------------------------------------------------
*/
$departments = [];
try {
    $stmt = $db->query("SELECT department_id, department_name FROM departments ORDER BY department_name");
    $departments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Error fetching departments: " . $e->getMessage());
}

/*
|--------------------------------------------------------------------------
| ADDED: Resolve faculty user_type_id safely (NO logic change)
|--------------------------------------------------------------------------
*/
$faculty_user_type_id = null;

try {
    $stmt = $db->query("SHOW TABLES LIKE 'user_types'");
    if ($stmt->rowCount() > 0) {
        // user_types table exists
        $stmt = $db->query("DESCRIBE user_types");
        $cols = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if (in_array('user_type_name', $cols)) {
            $stmt = $db->prepare("SELECT user_type_id FROM user_types WHERE user_type_name = 'faculty' LIMIT 1");
        } elseif (in_array('type_name', $cols)) {
            $stmt = $db->prepare("SELECT user_type_id FROM user_types WHERE type_name = 'faculty' LIMIT 1");
        } elseif (in_array('name', $cols)) {
            $stmt = $db->prepare("SELECT user_type_id FROM user_types WHERE name = 'faculty' LIMIT 1");
        } else {
            $stmt = null;
        }

        if ($stmt) {
            $stmt->execute();
            $faculty_user_type_id = $stmt->fetchColumn();
        }
    }
} catch (Exception $e) {
    // silently ignore – keeps existing logic intact
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $password   = $_POST['password'] ?? '';
    $department_id = filter_var($_POST['department_id'] ?? 0, FILTER_VALIDATE_INT); // ADDED

    if (!$first_name || !$last_name || !$email || !$password) {
        $errors[] = "All fields are required.";
    }

    // ADDED: Validate department selection
    if (!$department_id || $department_id <= 0) {
        $errors[] = "Please select a department.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email address.";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    if (empty($errors)) {
        $stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = "Email already registered.";
        }
    }

    if (empty($errors)) {
        $username = explode('@', $email)[0];
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $verification_token = bin2hex(random_bytes(32));
        $verification_token_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));

        // FIXED: Generate verification URL without BaseUrl class
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
        $host = $_SERVER['HTTP_HOST'];
        $base_path = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
        $verification_url = $protocol . "://" . $host . $base_path . "/public/verify_email.php?token=" . $verification_token;
        error_log("Generated verification URL: " . $verification_url);

        try {
            $db->beginTransaction();

            /*
            |--------------------------------------------------------------------------
            | ADDED: Insert using user_type_id IF available, otherwise fallback
            |--------------------------------------------------------------------------
            */
            if ($faculty_user_type_id !== null) {
                $stmt = $db->prepare("
                    INSERT INTO users (
                        username,
                        password,
                        email,
                        user_type_id,
                        is_active,
                        email_verified,
                        verification_token,
                        verification_token_expiry,
                        created_at
                    ) VALUES (?, ?, ?, ?, 0, 0, ?, ?, NOW())
                ");

                $stmt->execute([
                    $username,
                    $password_hash,
                    $email,
                    $faculty_user_type_id,
                    $verification_token,
                    $verification_token_expiry
                ]);
            } else {
                // fallback if schema uses no user_types table
                $stmt = $db->prepare("
                    INSERT INTO users (
                        username,
                        password,
                        email,
                        is_active,
                        email_verified,
                        verification_token,
                        verification_token_expiry,
                        created_at
                    ) VALUES (?, ?, ?, 0, 0, ?, ?, NOW())
                ");

                $stmt->execute([
                    $username,
                    $password_hash,
                    $email,
                    $verification_token,
                    $verification_token_expiry
                ]);
            }

            $user_id = $db->lastInsertId();

            /*
            |--------------------------------------------------------------------------
            | ADDED: Insert faculty record with department and name information
            |--------------------------------------------------------------------------
            */
            $stmt = $db->prepare("
                INSERT INTO faculty (
                    user_id,
                    first_name,
                    last_name,
                    email,
                    department_id,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $user_id,
                $first_name,
                $last_name,
                $email,
                $department_id
            ]);

            $db->commit();

            $success = "Registration successful! Your account is pending admin approval. Once approved, you'll receive a verification email.";
            
            error_log("✅ Faculty registration successful - User ID: {$user_id}, Email: {$email}");
            
        } catch (Exception $e) {
            $db->rollBack();
            error_log("❌ Faculty registration error: " . $e->getMessage());
            $errors[] = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Faculty Registration</title>
    <link rel="stylesheet" href="<?php echo asset('css/faculty_register.css'); ?>">
    <style>
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        .required {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="register-container">
    <div class="register-header">
        <h2>Faculty Registration</h2>
        <p>Please fill in the required details</p>
    </div>

    <?php if ($errors): ?>
        <div class="error">
            <?php foreach ($errors as $e) echo "<p>" . htmlspecialchars($e) . "</p>"; ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
        <a href="login.php">Back to Login</a>
        <?php exit; ?>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>First Name <span class="required">*</span></label>
            <input type="text" name="first_name" placeholder="First Name" 
                   value="<?= htmlspecialchars($_POST['first_name'] ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label>Last Name <span class="required">*</span></label>
            <input type="text" name="last_name" placeholder="Last Name" 
                   value="<?= htmlspecialchars($_POST['last_name'] ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label>Email <span class="required">*</span></label>
            <input type="email" name="email" placeholder="Email" 
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </div>

        <div class="form-group">
            <label>Department <span class="required">*</span></label>
            <select name="department_id" required>
                <option value="">-- Select Department --</option>
                <?php foreach ($departments as $dept): ?>
                    <option value="<?= $dept['department_id'] ?>" 
                            <?= (isset($_POST['department_id']) && $_POST['department_id'] == $dept['department_id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($dept['department_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Password <span class="required">*</span></label>
            <input type="password" name="password" placeholder="Password (min. 6 characters)" required>
        </div>

        <button type="submit">Register</button>
    </form>

    <div style="text-align: center; margin-top: 15px;">
        <a href="login.php">Already have an account? Login</a>
    </div>
</div>
</body>
</html>