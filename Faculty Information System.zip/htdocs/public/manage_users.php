<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}

use Controllers\UserController;
use Models\UserModel;
use Config\Database;

$db = Database::getInstance()->getConnection();

requireAdmin();

$controller = new UserController();
$userModel = new UserModel();

$errors = [];
$success = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create') {
        $result = $controller->create($_POST);
    } elseif ($_POST['action'] === 'update') {
        $userId = intval($_POST['user_id']);
        $result = $controller->update($userId, $_POST);
    } elseif ($_POST['action'] === 'delete') {
        $userId = intval($_POST['user_id']);
        $result = $controller->delete($userId);
    } elseif ($_POST['action'] === 'link_faculty') {
        // Handle faculty linking
        $userId = intval($_POST['user_id']);
        $facultyId = intval($_POST['faculty_id']);
        
        if ($facultyId > 0) {
            try {
                // Link faculty to user
                $stmt = $db->prepare("UPDATE faculty SET user_id = ? WHERE faculty_id = ?");
                if ($stmt->execute([$userId, $facultyId])) {
                    $success = "Faculty linked successfully!";
                } else {
                    $errors[] = "Failed to link faculty.";
                }
            } catch (Exception $e) {
                $errors[] = "Error linking faculty: " . $e->getMessage();
            }
        }
    } elseif ($_POST['action'] === 'unlink_faculty') {
        // Handle faculty unlinking
        $facultyId = intval($_POST['faculty_id']);
        
        try {
            $stmt = $db->prepare("UPDATE faculty SET user_id = NULL WHERE faculty_id = ?");
            if ($stmt->execute([$facultyId])) {
                $success = "Faculty unlinked successfully!";
            } else {
                $errors[] = "Failed to unlink faculty.";
            }
        } catch (Exception $e) {
            $errors[] = "Error unlinking faculty: " . $e->getMessage();
        }
    }

    if (isset($result)) {
        if ($result['success']) {
            $success = $result['message'];
            // Redirect to clear form and prevent resubmission
            if ($_POST['action'] === 'update') {
                header("Location: manage_users.php?updated=1");
                exit;
            }
        } else {
            $errors = $result['errors'] ?? [$result['message']];
        }
    }
}

// Check for success parameter
if (isset($_GET['updated'])) {
    $success = "User updated successfully!";
}

// Fetch all users
$users = $userModel->getAll();

// Fetch user types
$userTypes = $userModel->getUserTypes();

// Fetch faculty without login
$unlinked_faculty = $userModel->getUnlinkedFaculty();

// Fetch all faculty for the create form dropdown
try {
    $stmt = $db->prepare("SELECT faculty_id, first_name, last_name FROM faculty ORDER BY last_name, first_name");
    $stmt->execute();
    $all_faculty = $stmt->fetchAll();
} catch (Exception $e) {
    $all_faculty = [];
}

// Generate CSRF token
$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="navbar">
        <h1>Manage Users</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="view_faculty.php">Faculty</a>
            <a href="view_research.php">Research</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <?php if ($success): ?>
            <div class="alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
            <div class="alert-error">
                <ul>
                    <?php foreach ($errors as $err): ?>
                        <li><?php echo htmlspecialchars($err); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="card stats" style="display:flex; gap:10px; margin-bottom:20px;">
            <div class="stat-card card" style="flex:1; text-align:center;">
                <h3><?php echo count($users); ?></h3>
                <p>Total Users</p>
            </div>
            <div class="stat-card card" style="flex:1; text-align:center;">
                <h3><?php echo count(array_filter($users, function($u) { 
                    return strtolower($u['user_type']) === 'administrator' || strtolower($u['user_type']) === 'admin'; 
                })); ?></h3>
                <p>Administrators</p>
            </div>
            <div class="stat-card card" style="flex:1; text-align:center;">
                <h3><?php echo count(array_filter($users, function($u) { 
                    return strtolower($u['user_type']) === 'faculty'; 
                })); ?></h3>
                <p>Faculty Users</p>
            </div>
            <div class="stat-card card" style="flex:1; text-align:center;">
                <h3><?php echo count($unlinked_faculty); ?></h3>
                <p>Faculty Without Login</p>
            </div>
        </div>

        <!-- Edit User Form (shown when edit_id is in URL) -->
        <?php if (isset($_GET['edit_id'])): ?>
            <?php 
            $editUserId = intval($_GET['edit_id']);
            $editUser = $userModel->getById($editUserId);
            
            if ($editUser):
                // Get all faculty for the dropdown
                $allFacultyForEdit = $unlinked_faculty;
                
                // If user has a faculty link, add it to the list
                if (!empty($editUser['faculty_id'])) {
                    $facultyStmt = $db->prepare("SELECT faculty_id, first_name, last_name FROM faculty WHERE faculty_id = ?");
                    $facultyStmt->execute([$editUser['faculty_id']]);
                    $currentFaculty = $facultyStmt->fetch();
                    
                    if ($currentFaculty) {
                        // Check if not already in unlinked list
                        $found = false;
                        foreach ($allFacultyForEdit as $f) {
                            if ($f['faculty_id'] == $currentFaculty['faculty_id']) {
                                $found = true;
                                break;
                            }
                        }
                        if (!$found) {
                            array_unshift($allFacultyForEdit, $currentFaculty);
                        }
                    }
                }
            ?>
            <div class="card alert alert-warning">
                <h2>✏️ Edit User: <?php echo htmlspecialchars($editUser['username']); ?></h2>
                <form method="POST">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="user_id" value="<?php echo $editUserId; ?>">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="edit_username">Username <span style="color: red;">*</span></label>
                            <input type="text" id="edit_username" name="username" 
                                   value="<?php echo htmlspecialchars($editUser['username']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="edit_password">New Password (leave blank to keep current)</label>
                            <div style="position: relative;">
                                <input type="password" id="edit_password" name="password" minlength="6">
                                <span onclick="toggleEditPassword()" 
                                      style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; user-select: none;">
                                    👁️
                                </span>
                            </div>
                            <small>Minimum 6 characters</small>
                        </div>

                        <div class="form-group">
                            <label for="edit_user_type">User Type <span style="color: red;">*</span></label>
                            <select id="edit_user_type" name="user_type_id" required onchange="toggleEditFacultySelect()">
                                <?php foreach ($userTypes as $type): ?>
                                    <?php 
                                        $tid = intval($type['user_type_id']);
                                        $tname = $type['type_name'];
                                        $slug = strtolower(trim($tname));
                                    ?>
                                    <option value="<?php echo $tid; ?>" 
                                            data-slug="<?php echo htmlspecialchars($slug); ?>"
                                            <?php echo ($tid === intval($editUser['user_type_id'])) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($tname); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group" id="edit_faculty_select_group">
                            <label for="edit_faculty_id">Link to Faculty (Optional)</label>
                            <select id="edit_faculty_id" name="faculty_id">
                                <option value="">No Faculty Link</option>
                                <?php foreach ($allFacultyForEdit as $faculty): ?>
                                    <?php $fid = intval($faculty['faculty_id']); ?>
                                    <option value="<?php echo $fid; ?>" 
                                            <?php echo (!empty($editUser['faculty_id']) && $fid === intval($editUser['faculty_id'])) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success">Update User</button>
                    <a href="manage_users.php" class="btn btn-secondary" style="background: #6c757d; margin-left: 10px;">Cancel</a>
                </form>
            </div>
            <?php else: ?>
                <div class="alert-error">User not found!</div>
                <a href="manage_users.php" class="btn btn-secondary">Back to Users</a>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Create User Form -->
        <?php if (!isset($_GET['edit_id'])): ?>
        <div class="card">
            <h2>Create New User Account</h2>
            
            <!-- Info Box -->
            <!--<div class="info-box">
                <p><strong>ℹ️ Note:</strong> This creates system login credentials. To add faculty profiles and academic information, use the <strong>Faculty</strong> section in the navigation menu. You can optionally link user accounts to existing faculty profiles below.</p>
            </div>
            -->
            
            <form method="POST">
                <input type="hidden" name="action" value="create">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="username">Username <span style="color: red;">*</span></label>
                        <input type="text" id="username" name="username" required>
                    </div>

                    <div class="form-group">
                        <label for="password">Password <span style="color: red;">*</span></label>
                        <div style="position: relative;">
                            <input type="password" id="password" name="password" required minlength="6">
                            <span onclick="togglePassword()" 
                                  style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; user-select: none;">
                                👁️
                            </span>
                        </div>
                        <small>Minimum 6 characters</small>
                    </div>

                    <div class="form-group">
                        <label for="user_type">User Type <span style="color: red;">*</span></label>
                        <select id="user_type" name="user_type_id" required onchange="toggleFacultySelect()">
                            <option value="">Select Type</option>
                            <?php foreach ($userTypes as $type): ?>
                                <?php
                                    $tid = intval($type['user_type_id']);
                                    $tname = $type['type_name'];
                                    $slug = strtolower(trim($tname));
                                ?>
                                <option value="<?php echo $tid; ?>" data-slug="<?php echo htmlspecialchars($slug); ?>">
                                    <?php echo htmlspecialchars($tname); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group" id="faculty_select_group" style="display: none;">
                        <label for="faculty_id">Link to Faculty (Optional)</label>
                        <select id="faculty_id" name="faculty_id">
                            <option value="">No Faculty Link</option>
                            <?php foreach ($all_faculty as $faculty): ?>
                                <?php
                                    // Check if this faculty is already linked to a user
                                    $isLinked = false;
                                    foreach ($users as $u) {
                                        if (!empty($u['faculty_id']) && intval($u['faculty_id']) === intval($faculty['faculty_id'])) {
                                            $isLinked = true;
                                            break;
                                        }
                                    }
                                    $displayName = htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']);
                                    if ($isLinked) {
                                        $displayName .= ' (Already Linked)';
                                    }
                                ?>
                                <option value="<?php echo intval($faculty['faculty_id']); ?>" 
                                        <?php echo $isLinked ? 'disabled' : ''; ?>>
                                    <?php echo $displayName; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <small style="color: #666;">Link this user account to an existing faculty profile</small>
                    </div>
                </div>

                <button type="submit" class="btn btn-success">Create User</button>
            </form>
        </div>
        <?php endif; ?>

        <!-- Users List -->
        <?php if (!isset($_GET['edit_id'])): ?>
        <div class="card">
            <h2>System Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Type</th>
                        <th>Linked Faculty</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                    <?php
                        $typeSlug = strtolower(preg_replace('/\s+/', '_', $user['user_type']));
                        $isFacultyType = (strtolower($user['user_type']) === 'faculty');
                        $hasLink = !empty($user['faculty_id']);
                    ?>
                    <tr>
                        <td><?php echo intval($user['user_id']); ?></td>
                        <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                        <td>
                            <span class="badge badge-<?php echo htmlspecialchars($typeSlug); ?>">
                                <?php echo htmlspecialchars(ucfirst($user['user_type'])); ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($hasLink): ?>
                                <!-- User has faculty link - show name and unlink button -->
                                <a href="view_faculty_detail.php?id=<?php echo intval($user['faculty_id']); ?>">
                                    <?php echo htmlspecialchars($user['first_name'] . ' ' . $user['last_name']); ?>
                                </a>
                                <form method="POST" style="display: inline;" 
                                      onsubmit="return confirm('Unlink this faculty member from the user account?')">
                                    <input type="hidden" name="action" value="unlink_faculty">
                                    <input type="hidden" name="faculty_id" value="<?php echo intval($user['faculty_id']); ?>">
                                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                    <button type="submit" class="unlink-btn">Unlink</button>
                                </form>
                            <?php elseif (!$hasLink): ?>
                                <!-- User has no faculty link - show dropdown if unlinked faculty exist -->
                                <?php if (!empty($unlinked_faculty)): ?>
                                    <form method="POST" class="link-faculty-form">
                                        <input type="hidden" name="action" value="link_faculty">
                                        <input type="hidden" name="user_id" value="<?php echo intval($user['user_id']); ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                        <select name="faculty_id" required>
                                            <option value="">Select Faculty</option>
                                            <?php foreach ($unlinked_faculty as $faculty): ?>
                                                <option value="<?php echo intval($faculty['faculty_id']); ?>">
                                                    <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button type="submit" class="btn btn-primary">Link</button>
                                    </form>
                                <?php else: ?>
                                    <span style="color: #999;">No available faculty to link</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span style="color: #999;">No faculty link</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars(date('M d, Y', strtotime($user['created_at']))); ?></td>
                        <td>
                            <div class="actions">
                                <?php if (intval($user['user_id']) !== intval($_SESSION['user_id'])): ?>
                                    <a href="manage_users.php?edit_id=<?php echo intval($user['user_id']); ?>" class="btn btn-primary">Edit</a>
                                    <form method="POST" onsubmit="return confirm('Delete user <?php echo htmlspecialchars($user['username']); ?>?')" style="display: inline;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="user_id" value="<?php echo intval($user['user_id']); ?>">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                <?php else: ?>
                                    <span style="color: #999; font-size: 12px;">Current User</span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
            } else {
                passwordInput.type = 'password';
            }
        }

        function toggleEditPassword() {
            const passwordInput = document.getElementById('edit_password');
            if (passwordInput && passwordInput.type === 'password') {
                passwordInput.type = 'text';
            } else if (passwordInput) {
                passwordInput.type = 'password';
            }
        }

        function toggleFacultySelect() {
            const selectElem = document.getElementById('user_type');
            const facultyGroup = document.getElementById('faculty_select_group');
            const selected = selectElem.options[selectElem.selectedIndex];
            const slug = selected ? (selected.dataset.slug || '').toLowerCase() : '';
            
            if (slug === 'faculty') {
                facultyGroup.style.display = 'block';
            } else {
                facultyGroup.style.display = 'none';
                const faculty = document.getElementById('faculty_id');
                if (faculty) faculty.value = '';
            }
        }

        function toggleEditFacultySelect() {
            const selectElem = document.getElementById('edit_user_type');
            const facultyGroup = document.getElementById('edit_faculty_select_group');
            
            if (selectElem && facultyGroup) {
                const selected = selectElem.options[selectElem.selectedIndex];
                const slug = selected ? (selected.dataset.slug || '').toLowerCase() : '';
                
                if (slug === 'faculty') {
                    facultyGroup.style.display = 'block';
                } else {
                    facultyGroup.style.display = 'none';
                    const faculty = document.getElementById('edit_faculty_id');
                    if (faculty) faculty.value = '';
                }
            }
        }

        // Initialize visibility on page load
        document.addEventListener('DOMContentLoaded', function() {
            toggleFacultySelect();
            toggleEditFacultySelect();
        });
    </script>
</body>
</html>