<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

$db = Database::getInstance()->getConnection();

requireLogin();

$errors = [];

// Get faculty_id from URL
$faculty_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($faculty_id <= 0) {
    session()->setFlash('error', 'Invalid faculty ID.');
    redirect('view_faculty.php');
}

// Fetch faculty data
$stmt = $db->prepare("SELECT * FROM faculty WHERE faculty_id = ?");
$stmt->execute([$faculty_id]);
$faculty = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$faculty) {
    session()->setFlash('error', 'Faculty member not found.');
    redirect('view_faculty.php');
}

// Check if user has permission to edit
if (!canEditFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to edit this profile.");
    redirect('view_faculty.php');
}

// Fetch departments for dropdown
$stmt = $db->query("SELECT * FROM departments ORDER BY department_name");
$departments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid security token. Please try again.";
    }

    if (empty($errors)) {
        $first_name = trim($_POST['first_name'] ?? '');
        $last_name = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $department_id = !empty($_POST['department_id']) ? intval($_POST['department_id']) : null;
        
        // Validation
        if ($error = validateRequired($first_name, 'First name')) {
            $errors[] = $error;
        }
        if ($error = validateRequired($last_name, 'Last name')) {
            $errors[] = $error;
        }
        if ($error = validateRequired($email, 'Email')) {
            $errors[] = $error;
        }
        
        if (empty($errors) && ($error = validateEmail($email))) {
            $errors[] = $error;
        }
        
        if (!empty($phone) && ($error = validatePhone($phone))) {
            $errors[] = $error;
        }
        
        if ($error = validateLength($first_name, 1, 100, 'First name')) {
            $errors[] = $error;
        }
        if ($error = validateLength($last_name, 1, 100, 'Last name')) {
            $errors[] = $error;
        }
        if ($error = validateLength($email, 1, 100, 'Email')) {
            $errors[] = $error;
        }
        
        // Check if email already exists (excluding current faculty)
        if (empty($errors)) {
            $stmt = $db->prepare("SELECT faculty_id FROM faculty WHERE email = ? AND faculty_id != ?");
            $stmt->execute([$email, $faculty_id]);
            if ($stmt->fetch()) {
                $errors[] = "Email address already exists.";
            }
        }
        
        // Keep existing photo by default
        $photo_url = $faculty['photo_url'] ?? null;
        
        // Handle photo upload
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadResult = handleImageUpload($_FILES['photo'], $faculty['photo_url'] ?? null);
            if (!$uploadResult['success']) {
                $errors = array_merge($errors, $uploadResult['errors']);
            } else {
                $photo_url = $uploadResult['path'];
            }
        }
        
        if (empty($errors)) {
            try {
                // Track which fields were updated for notification
                $fields_updated = [];
                
                // Check what changed
                if ($first_name !== $faculty['first_name'] || $last_name !== $faculty['last_name']) {
                    $fields_updated[] = 'name';
                }
                if ($email !== $faculty['email']) {
                    $fields_updated[] = 'email';
                }
                if ($phone !== $faculty['phone']) {
                    $fields_updated[] = 'phone';
                }
                if ($address !== $faculty['address']) {
                    $fields_updated[] = 'address';
                }
                if ($department_id !== $faculty['department_id']) {
                    $fields_updated[] = 'department';
                }
                if ($photo_url !== $faculty['photo_url']) {
                    $fields_updated[] = 'photo';
                }
                
                $stmt = $db->prepare(
                    "UPDATE faculty 
                    SET department_id = ?, first_name = ?, last_name = ?, email = ?, 
                        phone = ?, address = ?, photo_url = ?, updated_by = ? 
                    WHERE faculty_id = ?"
                );
                
                $stmt->execute([
                    $department_id,
                    sanitize($first_name),
                    sanitize($last_name),
                    sanitize($email),
                    !empty($phone) ? sanitize($phone) : null,
                    !empty($address) ? sanitize($address) : null,
                    $photo_url,
                    getCurrentUserId(),
                    $faculty_id
                ]);
                
                // ✅ SEND NOTIFICATION AFTER SUCCESSFUL UPDATE
                $stmt = $db->prepare("SELECT user_id FROM faculty WHERE faculty_id = ?");
                $stmt->execute([$faculty_id]);
                $faculty_user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!empty($faculty_user['user_id']) && !empty($fields_updated)) {
                    require_once __DIR__ . '/../classes/FacultyNotification.php';
                    $notifier = new FacultyNotification();
                    
                    // Get who updated the profile
                    $stmt = $db->prepare("SELECT username FROM users WHERE user_id = ?");
                    $stmt->execute([getCurrentUserId()]);
                    $updated_by_name = $stmt->fetchColumn() ?: 'Administrator';
                    
                    if (in_array('photo', $fields_updated)) {
                        $notifier->notifyProfilePictureUpdated(
                            $faculty_user['user_id'], 
                            $first_name . ' ' . $last_name
                        );
                    } else {
                        $notifier->notifyProfileUpdated(
                            $faculty_user['user_id'], 
                            $first_name . ' ' . $last_name,
                            $updated_by_name,
                            $fields_updated
                        );
                    }
                }
                
                session()->setFlash('success', 'Faculty information updated successfully!');
                redirect('view_faculty_detail.php?id=' . $faculty_id);
                
            } catch (PDOException $e) {
                error_log("Error updating faculty: " . $e->getMessage());
                $errors[] = "An error occurred while updating the faculty member. Please try again.";
            }
        }
    }
    
    // Refresh faculty data if update failed
    if (!empty($errors)) {
        $stmt = $db->prepare("SELECT * FROM faculty WHERE faculty_id = ?");
        $stmt->execute([$faculty_id]);
        $faculty = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

$csrf_token = generateCSRFToken();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Faculty - <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?></title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
   
    <script>
        function previewPhoto(input) {
            const preview = document.getElementById('photo_preview');
            const fileInfo = document.getElementById('file_info');
            
            if (input.files && input.files[0]) {
                const file = input.files[0];
                
                if (file.size > 5 * 1024 * 1024) {
                    alert('File size must not exceed 5MB');
                    input.value = '';
                    preview.classList.remove('show');
                    fileInfo.textContent = '';
                    return;
                }
                
                const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                if (!allowedTypes.includes(file.type)) {
                    alert('Only JPG, PNG, GIF, and WebP images are allowed');
                    input.value = '';
                    preview.classList.remove('show');
                    fileInfo.textContent = '';
                    return;
                }
                
                const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
                fileInfo.textContent = `New photo selected: ${file.name} (${sizeInMB} MB)`;
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.add('show');
                };
                reader.readAsDataURL(file);
            } else {
                preview.classList.remove('show');
                fileInfo.textContent = '';
            }
        }
    </script>
</head>
<body>
    <div class="navbar">
        <h1>Edit Faculty</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="view_faculty.php">View Faculty</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="form-container">
            <h2>Edit Faculty Information</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="error">
                    <strong>Please fix the following errors:</strong>
                    <ul>
                        <?php foreach ($errors as $err): ?>
                            <li><?php echo htmlspecialchars($err); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                
                <div class="form-group">
                    <label for="first_name">First Name <span style="color: red;">*</span></label>
                    <input type="text" id="first_name" name="first_name" 
                           value="<?php echo htmlspecialchars($faculty['first_name']); ?>"
                           maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="last_name">Last Name <span style="color: red;">*</span></label>
                    <input type="text" id="last_name" name="last_name" 
                           value="<?php echo htmlspecialchars($faculty['last_name']); ?>"
                           maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email <span style="color: red;">*</span></label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo htmlspecialchars($faculty['email']); ?>"
                           maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" id="phone" name="phone" 
                           value="<?php echo htmlspecialchars($faculty['phone'] ?? ''); ?>"
                           pattern="[0-9\-\+\s\(\)]*" maxlength="20" 
                           autocomplete="tel" placeholder="e.g., 123-456-7890">
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="3"><?php echo htmlspecialchars($faculty['address'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="department_id">Department</label>
                    <select id="department_id" name="department_id">
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo $dept['department_id']; ?>" 
                                    <?php echo ($faculty['department_id'] ?? '') == $dept['department_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($dept['department_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="photo">Photo (Max 5MB, JPEG/PNG/GIF/WebP)</label>
                    
                    <?php 
                    $current_photo = $faculty['photo_url'] ?? null;
                    if (!empty($current_photo) && file_exists($current_photo)): 
                    ?>
                        <div class="current-photo">
                            <strong>Current Photo:</strong>
                            <img src="<?php echo htmlspecialchars($current_photo); ?>" 
                                 alt="Current faculty photo"
                                 onerror="this.style.display='none'; this.parentElement.innerHTML+='<p style=\'color:#999\'>Photo file not found</p>';">
                        </div>
                    <?php elseif (!empty($current_photo)): ?>
                        <div class="current-photo">
                            <p style="color: #999;">Current photo path exists but file not found</p>
                        </div>
                    <?php endif; ?>
                    
                    <input type="file" id="photo" name="photo" 
                           accept="image/jpeg,image/png,image/gif,image/webp"
                           onchange="previewPhoto(this)">
                    <div class="file-info" id="file_info"></div>
                    
                    <div>
                        <img id="photo_preview" class="photo-preview" alt="New Photo Preview">
                    </div>
                    
                    <small style="color: #666;">Leave empty to keep current photo</small>
                </div>
                
                <div class="btn-group">
                    <button type="submit">Update Faculty</button>
                    <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>