<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Models\DepartmentModel;
use Config\Database;

requireAdmin();

$db = Database::getInstance()->getConnection();
$departmentModel = new DepartmentModel();
$errors = [];

$departments = $departmentModel->getAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid security token. Please try again.";
    }
    
    if (empty($errors)) {
        $first_name = trim($_POST['first_name'] ?? '');
        $last_name = trim($_POST['last_name'] ?? '');
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $phone = trim($_POST['phone'] ?? '');
        $address = trim($_POST['address'] ?? '');
        $department_id = filter_var($_POST['department_id'] ?? null, FILTER_VALIDATE_INT);
        
        if ($error = validateRequired($first_name, 'First name')) {
            $errors[] = $error;
        }
        if ($error = validateRequired($last_name, 'Last name')) {
            $errors[] = $error;
        }
        if ($error = validateRequired($email, 'Email')) {
            $errors[] = $error;
        }
        
        if (empty($errors) && ($error = validateEmail($email))) {
            $errors[] = $error;
        }
        
        if (!empty($phone) && ($error = validatePhone($phone))) {
            $errors[] = $error;
        }
        
        if ($error = validateLength($first_name, 1, 100, 'First name')) {
            $errors[] = $error;
        }
        if ($error = validateLength($last_name, 1, 100, 'Last name')) {
            $errors[] = $error;
        }
        if ($error = validateLength($email, 1, 100, 'Email')) {
            $errors[] = $error;
        }
        
        if (empty($errors)) {
            $stmt = $db->prepare("SELECT COUNT(*) FROM faculty WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = "A faculty member with this email already exists.";
            }
        }
        
        $create_account = isset($_POST['create_account']) && $_POST['create_account'] === '1';
        if ($create_account && empty($errors)) {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if ($error = validateRequired($username, 'Username')) {
                $errors[] = $error;
            }
            if ($error = validateRequired($password, 'Password')) {
                $errors[] = $error;
            }
            
            if ($error = validateLength($username, 3, 50, 'Username')) {
                $errors[] = $error;
            }
            if (empty($errors) && strlen($password) < 6) {
                $errors[] = "Password must be at least 6 characters long.";
            }
            
            if (empty($errors)) {
                $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
                $stmt->execute([$username]);
                if ($stmt->fetchColumn() > 0) {
                    $errors[] = "Username already exists. Please choose a different username.";
                }
            }
        }
        
        $photo_url = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadResult = handleImageUpload($_FILES['photo']);
            if (!$uploadResult['success']) {
                $errors = array_merge($errors, $uploadResult['errors']);
            } else {
                $photo_url = $uploadResult['path'];
            }
        }
        
        if (empty($errors)) {
            try {
                $db->beginTransaction();
                
                $user_id = null;
                
                if ($create_account) {
                    $username = sanitize($username);
                    $password_hash = password_hash($password, PASSWORD_BCRYPT);
                    
                    $stmt = $db->prepare("SELECT user_type_id FROM user_types WHERE LOWER(type_name) = 'faculty' LIMIT 1");
                    $stmt->execute();
                    $faculty_type = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if (!$faculty_type) {
                        throw new Exception("Faculty user type not found in database.");
                    }
                    
                    $faculty_type_id = $faculty_type['user_type_id'];
                    
                    $stmt = $db->prepare("INSERT INTO users (username, password, email, user_type_id, created_by) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$username, $password_hash, $email, $faculty_type_id, getCurrentUserId()]);
                    $user_id = $db->lastInsertId();
                }
                
                $stmt = $db->prepare(
                    "INSERT INTO faculty (user_id, department_id, first_name, last_name, email, phone, address, photo_url, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
                );
                $stmt->execute([
                    $user_id, 
                    $department_id, 
                    sanitize($first_name), 
                    sanitize($last_name), 
                    sanitize($email), 
                    !empty($phone) ? sanitize($phone) : null, 
                    !empty($address) ? sanitize($address) : null, 
                    $photo_url, 
                    getCurrentUserId()
                ]);
                
                $new_faculty_id = $db->lastInsertId();
                
                $db->commit();
                
                if ($create_account && !empty($user_id)) {
                    require_once __DIR__ . '/../classes/FacultyNotification.php';
                    $notifier = new FacultyNotification();
                    
                    $notifier->createNotification(
                        $user_id,
                        '🎉 Welcome to Faculty Information System',
                        "Welcome {$first_name} {$last_name}! Your account has been created. Username: {$username}. Please complete your profile to get started.",
                        'success',
                        'profile.php'
                    );
                }
                
                session()->setFlash('success', $create_account 
                    ? "Faculty member added successfully with login credentials!" 
                    : "Faculty member added successfully!");
                redirect('view_faculty.php');
            } catch (Exception $e) {
                $db->rollBack();
                error_log("Error adding faculty: " . $e->getMessage());
                $errors[] = "An error occurred while adding the faculty member. Please try again.";
                
                if ($photo_url && file_exists($photo_url)) {
                    unlink($photo_url);
                }
            }
        }
    }
}

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Faculty - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    
    <script>
        function toggleAccountFields() {
            const checkbox = document.getElementById('create_account');
            const fields = document.getElementById('account_fields');
            const username = document.getElementById('username');
            const password = document.getElementById('password');
            
            if (checkbox.checked) {
                fields.style.display = 'block';
                username.setAttribute('required', 'required');
                password.setAttribute('required', 'required');
            } else {
                fields.style.display = 'none';
                username.removeAttribute('required');
                password.removeAttribute('required');
            }
        }
        
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleBtn = document.getElementById('toggle-password-btn');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleBtn.textContent = '🙈';
            } else {
                passwordInput.type = 'password';
                toggleBtn.textContent = '👁️';
            }
        }
        
        function previewPhoto(input) {
            const preview = document.getElementById('photo_preview');
            const fileInfo = document.getElementById('file_info');
            
            if (input.files && input.files[0]) {
                const file = input.files[0];
                
                if (file.size > 5 * 1024 * 1024) {
                    alert('File size must not exceed 5MB');
                    input.value = '';
                    preview.classList.remove('show');
                    fileInfo.textContent = '';
                    return;
                }
                
                const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                if (!allowedTypes.includes(file.type)) {
                    alert('Only JPG, PNG, GIF, and WebP images are allowed');
                    input.value = '';
                    preview.classList.remove('show');
                    fileInfo.textContent = '';
                    return;
                }
                
                const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
                fileInfo.textContent = `Selected: ${file.name} (${sizeInMB} MB)`;
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.classList.add('show');
                };
                reader.readAsDataURL(file);
            } else {
                preview.classList.remove('show');
                fileInfo.textContent = '';
            }
        }
    </script>
</head>
<body>
    <div class="navbar">
        <h1>Add New Faculty</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="view_faculty.php">View Faculty</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>
        
        <div class="form-container">
            <h2>Faculty Information</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="error">
                    <strong>Please fix the following errors:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                
                <div class="form-group">
                    <label for="first_name">First Name <span style="color: red;">*</span></label>
                    <input type="text" id="first_name" name="first_name" 
                           value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>"
                           maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="last_name">Last Name <span style="color: red;">*</span></label>
                    <input type="text" id="last_name" name="last_name" 
                           value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>"
                           maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email <span style="color: red;">*</span></label>
                    <input type="email" id="email" name="email" 
                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                           maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" id="phone" name="phone" 
                           value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>"
                           pattern="[0-9\-\+\s\(\)]*" maxlength="20" 
                           autocomplete="tel" placeholder="e.g., 123-456-7890">
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="3"><?php echo htmlspecialchars($_POST['address'] ?? ''); ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="department_id">Department</label>
                    <select id="department_id" name="department_id">
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo $dept['department_id']; ?>"
                                    <?php echo (isset($_POST['department_id']) && $_POST['department_id'] == $dept['department_id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($dept['department_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="photo">Photo (Max 5MB, JPEG/PNG/GIF/WebP)</label>
                    <input type="file" id="photo" name="photo" 
                           accept="image/jpeg,image/png,image/gif,image/webp"
                           onchange="previewPhoto(this)">
                    <div class="file-info" id="file_info"></div>
                    <div class="photo-preview-container">
                        <img id="photo_preview" class="photo-preview" alt="Photo Preview">
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" id="create_account" name="create_account" value="1" 
                               onchange="toggleAccountFields()"
                               <?php echo (isset($_POST['create_account']) && $_POST['create_account'] === '1') ? 'checked' : ''; ?>>
                        <label for="create_account" style="margin: 0;">Create login account for this faculty</label>
                    </div>
                    
                    <div id="account_fields" class="account-fields" style="display: <?php echo (isset($_POST['create_account']) && $_POST['create_account'] === '1') ? 'block' : 'none'; ?>;">
                        <div class="form-group">
                            <label for="username">Username <span style="color: red;">*</span></label>
                            <input type="text" id="username" name="username" 
                                   value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                                   autocomplete="username" maxlength="50">
                        </div>
                        <div class="form-group">
                            <label for="password">Password <span style="color: red;">*</span></label>
                            <div style="position: relative;">
                                <input type="password" id="password" name="password" autocomplete="new-password">
                                <span id="toggle-password-btn" onclick="togglePassword()" 
                                      style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer; user-select: none;">👁️</span>
                            </div>
                            <small>Minimum 6 characters</small>
                        </div>
                    </div>
                </div>
                
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">Add Faculty</button>
                    <a href="view_faculty.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>