<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}

use Config\Database;
use Config\BaseUrl;

$db = Database::getInstance()->getConnection();
$message = '';
$success = false;

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    
    try {
        // Find user with this token
        $stmt = $db->prepare("
            SELECT user_id, username, email, verification_token_expiry 
            FROM users 
            WHERE verification_token = ? 
            AND email_verified = 0
        ");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if (!$user) {
            $message = "Invalid or already used verification link.";
        } elseif (strtotime($user['verification_token_expiry']) < time()) {
            $message = "Verification link has expired. Please request a new one.";
         } else {
            // Verify the email
            $updateStmt = $db->prepare("
                UPDATE users 
                SET email_verified = 1,
                    verification_token = NULL,
                    verification_token_expiry = NULL,
                    verified_at = NOW()
                WHERE user_id = ?
            ");
            
            if ($updateStmt->execute([$user['user_id']])) {
                $rowsAffected = $updateStmt->rowCount();
                error_log("✅ Email verified for user_id: {$user['user_id']}, rows affected: {$rowsAffected}");
                
                $success = true;
                $message = "Email verified successfully! You can now login.";
                
                // ADDED: Redirect to new verification.php page for better UX
                header("Location: " . BaseUrl::get() . "../public/verification.php?status=success");
                exit();
            } else {
                error_log("❌ Failed to update email_verified status for user_id: {$user['user_id']}");
                $message = "An error occurred during verification. Please contact support.";
                
                // ADDED: Redirect to verification page with error status
                header("Location: " . BaseUrl::get() . "../public/verification.php?status=error&message=" . urlencode("Database update failed"));
                exit();
            }
        } 
    } catch (Exception $e) {
        error_log("Verification Error: " . $e->getMessage());
        $message = "An error occurred during verification. Please try again.";
    }
} else {
    $message = "No verification token provided.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="verification-container">
        <?php if ($success): ?>
            <div class="success-icon">✓</div>
            <h2>Email Verified!</h2>
        <?php else: ?>
            <div class="error-icon">✗</div>
            <h2>Verification Failed</h2>
        <?php endif; ?>
        
        <p class="message"><?= htmlspecialchars($message) ?></p>
        
        <?php if ($success): ?>
            <a href="login.php" class="login-btn">Go to Login</a>
            <script>
                // Auto redirect after 3 seconds
                setTimeout(function() {
                    window.location.href = 'login.php';
                }, 3000);
            </script>
        <?php else: ?>
            <a href="login.php" class="login-btn">Back to Login</a>
        <?php endif; ?>
    </div>
</body>
</html>