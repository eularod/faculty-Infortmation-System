<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}
require_once __DIR__ . '/../helpers/notification_helper.php';

use Config\Database;

requireLogin();

$db = Database::getInstance()->getConnection();
$errors = [];

$faculty_id = filter_var($_GET['faculty_id'] ?? 0, FILTER_VALIDATE_INT);

if (!$faculty_id) {
    session()->setFlash('error', 'Invalid faculty ID.');
    redirect('view_faculty.php');
}

if (!canEditFaculty($faculty_id)) {
    session()->setFlash('error', "You don't have permission to add records for this faculty.");
    redirect('view_faculty_detail.php?id=' . $faculty_id);
}

$stmt = $db->prepare("SELECT first_name, last_name FROM faculty WHERE faculty_id = ?");
$stmt->execute([$faculty_id]);
$faculty = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$faculty) {
    session()->setFlash('error', 'Faculty member not found.');
    redirect('view_faculty.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        $errors[] = "Invalid security token. Please try again.";
    }
    
    if (empty($errors)) {
        $school_name = trim($_POST['school_name'] ?? '');
        $degree_title = trim($_POST['degree_title'] ?? '');
        $field_of_study = trim($_POST['field_of_study'] ?? '');
        $year_graduated = filter_var($_POST['year_graduated'] ?? '', FILTER_VALIDATE_INT);
        
        if ($error = validateRequired($school_name, 'School name')) {
            $errors[] = $error;
        }
        if ($error = validateRequired($degree_title, 'Degree title')) {
            $errors[] = $error;
        }
        if (!$year_graduated) {
            $errors[] = "Year graduated is required.";
        }
        
        if (empty($errors) && ($error = validateYear($year_graduated))) {
            $errors[] = $error;
        }
        
        if ($error = validateLength($school_name, 1, 200, 'School name')) {
            $errors[] = $error;
        }
        if ($error = validateLength($degree_title, 1, 100, 'Degree title')) {
            $errors[] = $error;
        }
        if (!empty($field_of_study) && ($error = validateLength($field_of_study, 1, 100, 'Field of study'))) {
            $errors[] = $error;
        }
        
        if (empty($errors)) {
            try {
                $stmt = $db->prepare(
                    "INSERT INTO education (faculty_id, school_name, degree_title, field_of_study, year_graduated) 
                    VALUES (?, ?, ?, ?, ?)"
                );
                $stmt->execute([
                    $faculty_id, 
                    sanitize($school_name), 
                    sanitize($degree_title), 
                    !empty($field_of_study) ? sanitize($field_of_study) : null, 
                    $year_graduated
                ]);
                
                $stmt = $db->prepare("SELECT user_id FROM faculty WHERE faculty_id = ?");
                $stmt->execute([$faculty_id]);
                $faculty_user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!empty($faculty_user['user_id'])) {
                    require_once __DIR__ . '/../classes/FacultyNotification.php';
                    $notifier = new FacultyNotification();
                    $notifier->notifyEducationAdded(
                        $faculty_user['user_id'], 
                        $degree_title, 
                        $school_name
                    );
                }
                
                session()->setFlash('success', 'Education record added successfully!');
                redirect('view_faculty_detail.php?id=' . $faculty_id);
            } catch (PDOException $e) {
                error_log("Error adding education: " . $e->getMessage());
                $errors[] = "An error occurred while adding the education record. Please try again.";
            }
        }
    }
}

$csrf_token = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Education - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
</head>
<body>
    <div class="navbar">
        <h1>Add Education Record</h1>
        <div>
            <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>">Back to Profile</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <?php displayFlashMessage(); ?>
        
        <div class="form-container">
            <h2>Add Education Record</h2>
            
            <div class="faculty-info">
                <strong>Faculty:</strong> <?php echo htmlspecialchars($faculty['first_name'] . ' ' . $faculty['last_name']); ?>
            </div>
            
            <?php if (!empty($errors)): ?>
                <div class="error">
                    <strong>Please fix the following errors:</strong>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token); ?>">
                
                <div class="form-group">
                    <label for="degree_title">Degree Title <span style="color: red;">*</span></label>
                    <input type="text" id="degree_title" name="degree_title" 
                           value="<?php echo htmlspecialchars($_POST['degree_title'] ?? ''); ?>"
                           placeholder="e.g., Bachelor of Science, Master of Arts, PhD" 
                           maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="school_name">School/University Name <span style="color: red;">*</span></label>
                    <input type="text" id="school_name" name="school_name" 
                           value="<?php echo htmlspecialchars($_POST['school_name'] ?? ''); ?>"
                           placeholder="e.g., University of the Philippines"
                           maxlength="200" required>
                </div>
                
                <div class="form-group">
                    <label for="field_of_study">Field of Study</label>
                    <input type="text" id="field_of_study" name="field_of_study" 
                           value="<?php echo htmlspecialchars($_POST['field_of_study'] ?? ''); ?>"
                           placeholder="e.g., Computer Science, Mathematics" 
                           maxlength="100">
                </div>
                
                <div class="form-group">
                    <label for="year_graduated">Year Graduated <span style="color: red;">*</span></label>
                    <input type="number" id="year_graduated" name="year_graduated" 
                           value="<?php echo htmlspecialchars($_POST['year_graduated'] ?? ''); ?>"
                           min="1950" max="<?php echo date('Y') + 10; ?>" required>
                </div>
                
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">Add Education</button>
                    <a href="view_faculty_detail.php?id=<?php echo $faculty_id; ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>