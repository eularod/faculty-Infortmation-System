<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/../init.php';
}

use Controllers\ReportController;
use Config\Database;

$db = Database::getInstance()->getConnection();

requireLogin();

$reportController = new ReportController();

// Handle export requests
if (isset($_GET['export'])) {
    $export_type = $_GET['export'];
    
    switch ($export_type) {
        case 'faculty':
            $data = $reportController->generateFacultyListReport([]);
            $headers = ['ID', 'First Name', 'Last Name', 'Email', 'Phone', 'Department', 'Address'];
            $filename = 'faculty_' . date('Y-m-d') . '.csv';
            break;
            
        case 'research':
            $data = $reportController->generateResearchSummaryReport([]);
            $headers = ['ID', 'Title', 'Faculty', 'Department', 'Type', 'Status', 'Year', 'Description'];
            $filename = 'research_' . date('Y-m-d') . '.csv';
            break;
            
        case 'education':
            $data = $reportController->generateEducationSummaryReport([]);
            $headers = ['Degree Title', 'School', 'Field of Study', 'Year', 'Faculty'];
            $filename = 'education_' . date('Y-m-d') . '.csv';
            break;
            
        case 'departments':
            $data = $reportController->generateDepartmentSummaryReport([]);
            $headers = ['Department', 'Code', 'Faculty Count', 'Research Count', 'Awards Count'];
            $filename = 'departments_' . date('Y-m-d') . '.csv';
            break;
            
        default:
            session()->setFlash('error', 'Invalid export type.');
            redirect('export_data.php');
    }
    
    // Generate CSV
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    $output = fopen('php://output', 'w');
    
    // Add BOM for Excel UTF-8 compatibility
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Write headers
    fputcsv($output, $headers);
    
    // Write data
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit();
}

// Get statistics for display
$stats = [
    'faculty' => $db->query("SELECT COUNT(*) FROM faculty")->fetchColumn(),
    'research' => $db->query("SELECT COUNT(*) FROM research")->fetchColumn(),
    'education' => $db->query("SELECT COUNT(*) FROM education")->fetchColumn(),
    'departments' => $db->query("SELECT COUNT(*) FROM departments")->fetchColumn()
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Data - Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">

</head>
<body>
    <div class="navbar">
        <h1>📥 Export Data</h1>
        <div>
            <a href="dashboard.php">Dashboard</a>
            <a href="reports.php">Reports</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="header-section">
            <h2>Export Data to CSV</h2>
            <p>Download data in CSV format for use in Excel, Google Sheets, or other applications</p>
        </div>
        
        <?php displayFlashMessage(); ?>
        
        <!-- Export Options -->
        <div class="export-grid">
            <div class="export-card">
                <div class="export-icon">👥</div>
                <h3>Faculty Data</h3>
                <p>Export complete list of faculty members with contact information and departments</p>
                <div class="export-stats">
                    <?php echo $stats['faculty']; ?> records
                </div>
                <a href="export_data.php?export=faculty" class="btn btn-primary">📥 Export Faculty</a>
            </div>
            
            <div class="export-card">
                <div class="export-icon">📚</div>
                <h3>Research Data</h3>
                <p>Export all research publications with author details, types, and status</p>
                <div class="export-stats">
                    <?php echo $stats['research']; ?> records
                </div>
                <a href="export_data.php?export=research" class="btn btn-primary">📥 Export Research</a>
            </div>
            
            <div class="export-card">
                <div class="export-icon">🎓</div>
                <h3>Education Data</h3>
                <p>Export all education records with degrees, institutions, and graduation years</p>
                <div class="export-stats">
                    <?php echo $stats['education']; ?> records
                </div>
                <a href="export_data.php?export=education" class="btn btn-primary">📥 Export Education</a>
            </div>
            
            <div class="export-card">
                <div class="export-icon">🏢</div>
                <h3>Department Summary</h3>
                <p>Export department statistics including faculty and research counts</p>
                <div class="export-stats">
                    <?php echo $stats['departments']; ?> departments
                </div>
                <a href="export_data.php?export=departments" class="btn btn-primary">📥 Export Departments</a>
            </div>
        </div>
        
        <!-- Instructions -->
        <div class="instructions">
            <h3>📋 How to Use Exported Data</h3>
            <ul>
                <li><strong>Excel/Sheets:</strong> Open the CSV file directly in Microsoft Excel or Google Sheets</li>
                <li><strong>Import:</strong> Use the imported data for analysis, reporting, or backup purposes</li>
                <li><strong>UTF-8:</strong> All files are encoded in UTF-8 for proper character support</li>
                <li><strong>Format:</strong> CSV (Comma-Separated Values) format compatible with all major spreadsheet applications</li>
            </ul>
        </div>
        
        <!-- Quick Actions -->
        <div class="quick-actions">
            <h3>Quick Actions</h3>
            <div class="action-buttons">
                <a href="reports.php" class="btn btn-secondary">← Back to Reports</a>
                <a href="kpi_dashboard.php" class="btn btn-info">📊 View KPI Dashboard</a>
                <a href="dashboard.php" class="btn btn-secondary">🏠 Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>