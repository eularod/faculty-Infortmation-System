<?php
// Start session first, before any output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// If user is already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Robust path resolution for any environment
$publicDir = dirname(__FILE__);
$rootDir = dirname($publicDir);

// Pre-load Database class first
$databasePaths = [
    $rootDir . '/Config/Database.php',
    $rootDir . '/config/Database.php',
    $rootDir . '/app/Config/Database.php',
];

foreach ($databasePaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

// Pre-load SessionManager before init.php runs
$sessionManagerPaths = [
    $rootDir . '/Modules/SessionManager.php',
    $rootDir . '/modules/SessionManager.php',
    $rootDir . '/app/Modules/SessionManager.php',
];

foreach ($sessionManagerPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

// Pre-load Auth class as well
$authPaths = [
    $rootDir . '/Modules/Auth.php',
    $rootDir . '/modules/Auth.php',
    $rootDir . '/app/Modules/Auth.php',
];

foreach ($authPaths as $path) {
    if (file_exists($path)) {
        require_once $path;
        break;
    }
}

// Initialize with error handling
$initError = null;

if (!defined('BASE_PATH')) {
    try {
        // Check if init.php exists before requiring
        if (file_exists($rootDir . '/init.php')) {
            require_once $rootDir . '/init.php';
        } else {
            throw new Exception("Initialization file not found");
        }
    } catch (Exception $e) {
        $initError = $e->getMessage();
        error_log('Initialization error: ' . $initError);
    } catch (Error $e) {
        // Catch fatal errors like missing classes
        $initError = "System initialization failed: " . $e->getMessage();
        error_log('Initialization fatal error: ' . $e->getMessage());
    }
}

$error = '';

// Only process login if initialization was successful
if (!$initError) {
    try {
        $auth = new \Modules\Auth();
        
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = trim($_POST['username'] ?? '');
            $password = $_POST['password'] ?? '';
            
            if (empty($username) || empty($password)) {
                $error = "Please enter both username and password.";
            } else {
                if ($auth->login($username, $password)) {
                    // Check if there's a redirect URL in session
                    if (isset($_SESSION['redirect_after_login'])) {
                        $redirect = $_SESSION['redirect_after_login'];
                        unset($_SESSION['redirect_after_login']);
                        header("Location: $redirect", true, 302);
                        exit();
                    } else {
                        // Direct redirect to dashboard using relative path
                        header("Location: dashboard.php", true, 302);
                        exit();
                    }
                } else {
                    $error = "Invalid username or password.";
                }
            }
        }
    } catch (Exception $e) {
        $error = "Login system error. Please try again later.";
        error_log("Login error: " . $e->getMessage());
    }
} else {
    $error = "System initialization failed. Please contact support.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Faculty Information System</title>
    <style>
        /* Reset all styles to prevent conflicts */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            width: 100%;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        /* Hide any elements that might be inherited */
        body > *:not(.login-container) {
            display: none !important;
        }

        .login-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            max-width: 420px;
            width: 100%;
            padding: 40px;
            display: block !important;
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-header h2 {
            color: #333;
            font-size: 28px;
            margin-bottom: 8px;
        }

        .login-header p {
            color: #666;
            font-size: 14px;
        }

        .error {
            background-color: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
            font-size: 14px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 15px;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-actions {
            margin-top: 25px;
        }

        .form-actions button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .form-actions button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .form-actions button:active {
            transform: translateY(0);
        }

        .login-footer {
            margin-top: 25px;
            text-align: center;
            font-size: 14px;
            color: #666;
        }

        .login-footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s;
        }

        .login-footer a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        .login-footer span {
            margin: 0 10px;
            color: #ccc;
        }
    </style>
</head> 
<body>
    <div class="login-container">
        <div class="login-header">
            <h2>Faculty Information System</h2>
            <p>Sign in to continue</p>
        </div>
        
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST" action="login.php" autocomplete="off">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required autofocus 
                       autocomplete="off" placeholder="Enter your username">
            </div>
            
            <div class="form-group password-wrapper">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required 
                       autocomplete="new-password" placeholder="Enter your password">
            </div>
            
            <div class="form-actions">
                <button type="submit">Login</button>
            </div>
        </form>
        
        <div class="login-footer">
            <a href="faculty_register.php">Create an account</a>
            <span>|</span>
            <a href="/">Back to Home</a>
        </div>
    </div>
</body>
</html>