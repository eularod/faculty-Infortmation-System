<?php
/**
 * Notification Helper Functions
 * Handles flash messages and database notifications
 */

// ============================================
// FLASH MESSAGE FUNCTIONS
// ============================================

if (!function_exists('setFlashMessage')) {
    /**
     * Set a flash message in session
     * @param string $type Message type (success, error, warning, info)
     * @param string $message Message text
     * @return void
     */
    function setFlashMessage($type, $message) {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $_SESSION['flash_message'] = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
        $_SESSION['flash_type'] = htmlspecialchars($type, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('getFlashMessage')) {
    /**
     * Get and clear the flash message from session
     * @return array|null Flash message data or null
     */
    function getFlashMessage() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        $message = null;
        
        // Check new-style flash messages
        if (isset($_SESSION['flash_message']) && isset($_SESSION['flash_type'])) {
            $message = [
                'type' => $_SESSION['flash_type'],
                'message' => $_SESSION['flash_message']
            ];
            unset($_SESSION['flash_message'], $_SESSION['flash_type']);
        }
        // Check old-style flash messages for backward compatibility
        elseif (isset($_SESSION['success'])) {
            $message = ['type' => 'success', 'message' => $_SESSION['success']];
            unset($_SESSION['success']);
        }
        elseif (isset($_SESSION['error'])) {
            $message = ['type' => 'error', 'message' => $_SESSION['error']];
            unset($_SESSION['error']);
        }
        
        return $message;
    }
}

if (!function_exists('displayFlashMessage')) {
    /**
     * Display flash message HTML if one exists
     * @return void
     */
    function displayFlashMessage() {
        $flash = getFlashMessage();
        
        if (!$flash) return;
        
        $type = htmlspecialchars($flash['type'], ENT_QUOTES, 'UTF-8');
        $message = htmlspecialchars($flash['message'], ENT_QUOTES, 'UTF-8');
        
        $iconMap = [
            'success' => 'fa-check-circle',
            'error' => 'fa-exclamation-circle',
            'warning' => 'fa-exclamation-triangle',
            'info' => 'fa-info-circle'
        ];
        
        $colorMap = [
            'success' => ['bg' => '#d4edda', 'text' => '#155724', 'border' => '#28a745'],
            'error' => ['bg' => '#f8d7da', 'text' => '#721c24', 'border' => '#dc3545'],
            'warning' => ['bg' => '#fff3cd', 'text' => '#856404', 'border' => '#ffc107'],
            'info' => ['bg' => '#d1ecf1', 'text' => '#0c5460', 'border' => '#17a2b8']
        ];
        
        $icon = $iconMap[$type] ?? 'fa-info-circle';
        $colors = $colorMap[$type] ?? $colorMap['info'];
        
        echo <<<HTML
<div class="flash-message alert alert-{$type}" style="
    padding: 15px 20px;
    margin: 20px 0;
    background: {$colors['bg']};
    color: {$colors['text']};
    border-left: 4px solid {$colors['border']};
    border-radius: 8px;
    display: flex;
    align-items: center;
    gap: 10px;
    animation: slideInDown 0.3s ease-out;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
">
    <i class="fas {$icon}" style="font-size: 20px;"></i>
    <span style="flex: 1;">{$message}</span>
    <button onclick="this.parentElement.remove()" style="
        background: none;
        border: none;
        font-size: 20px;
        cursor: pointer;
        opacity: 0.5;
        color: {$colors['text']};
        padding: 0;
        margin-left: 10px;
    " title="Dismiss">&times;</button>
</div>
<style>
    @keyframes slideInDown {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
HTML;
    }
}