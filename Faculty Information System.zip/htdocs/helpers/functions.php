<?php
/**
 * Helper Functions
 * Backward compatibility and utility functions
 */

use Modules\Auth;
use Modules\SessionManager;
use Modules\CSRF;
use Modules\Validator;

// ============================================
// AUTHENTICATION FUNCTIONS
// ============================================

function isLoggedIn() {
    return auth()->isLoggedIn();
}

function isAdmin() {
    return auth()->isAdmin();
}

function isFaculty() {
    return auth()->isFaculty();
}

function requireLogin() {
    auth()->requireLogin();
}

function requireAdmin() {
    auth()->requireAdmin();
}

function getCurrentUserId() {
    return session()->getUserId();
}

function getCurrentFacultyId() {
    return auth()->getCurrentFacultyId();
}

function canEditFaculty($facultyId) {
    return auth()->canEditFaculty(intval($facultyId));
}

function canDeleteFaculty($facultyId) {
    return auth()->canDeleteFaculty(intval($facultyId));
}

function getUserFacultyId($userId) {
    return auth()->getUserFacultyId(intval($userId));
}

// ============================================
// VALIDATION FUNCTIONS
// ============================================

function sanitize($data) {
    return Validator::sanitize($data);
}

function validateRequired($value, $fieldName) {
    return Validator::required($value, $fieldName);
}

function validateEmail($email) {
    return Validator::email($email);
}

function validateYear($year) {
    return Validator::year($year);
}

function validatePhone($phone) {
    return Validator::phone($phone);
}

function validateLength($value, $min, $max, $fieldName) {
    return Validator::length($value, $min, $max, $fieldName);
}

function validateImageUpload($file) {
    return Validator::file($file);
}

// ============================================
// CSRF FUNCTIONS
// ============================================

function generateCSRFToken() {
    return csrf()->generateToken();
}

function validateCSRFToken($token) {
    return csrf()->validateToken($token);
}

function csrfField() {
    return csrf()->getTokenField();
}

// ============================================
// FILE UPLOAD FUNCTIONS
// ============================================

function handleImageUpload($file, $oldPath = null) {
    $fileUpload = new \Modules\FileUpload();
    return $fileUpload->uploadImage($file, $oldPath);
}

// ============================================
// DATABASE QUERY FUNCTIONS
// ============================================

function getDepartments() {
    $model = new \Models\DepartmentModel();
    return $model->getAll();
}

function getResearchTypes() {
    $model = new \Models\ResearchModel();
    return $model->getResearchTypes();
}

function getResearchStatuses() {
    $model = new \Models\ResearchModel();
    return $model->getResearchStatuses();
}

function getUserTypes() {
    $model = new \Models\UserModel();
    return $model->getUserTypes();
}

function getFacultyAwards($facultyId) {
    $model = new \Models\AwardModel();
    return $model->getByFacultyId(intval($facultyId));
}

function getFacultyEducation($facultyId) {
    $model = new \Models\EducationModel();
    return $model->getByFacultyId(intval($facultyId));
}

function getFacultyResearch($facultyId) {
    $model = new \Models\ResearchModel();
    return $model->getByFacultyId(intval($facultyId));
}

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Log user action
 * @param string $action Action type
 * @param string $details Action details
 * @return void
 */
function logUserAction($action, $details) {
    $userId = getCurrentUserId();
    $action = htmlspecialchars($action, ENT_QUOTES, 'UTF-8');
    $details = htmlspecialchars($details, ENT_QUOTES, 'UTF-8');
    
    error_log("User Action [ID:{$userId}]: {$action} - {$details}");
}

/**
 * Display flash message
 * @param string|null $type Message type (success, error, info, warning)
 * @return void
 */
function displayFlashMessage($type = null) {
    $session = session();
    
    if ($type) {
        $message = $session->getFlash($type);
        if ($message) {
            $alertClass = $type === 'error' ? 'alert-error' : 'alert-success';
            echo '<div class="alert ' . $alertClass . '">' . htmlspecialchars($message) . '</div>';
        }
    } else {
        // Display all flash messages
        foreach (['success', 'error', 'info', 'warning'] as $flashType) {
            displayFlashMessage($flashType);
        }
    }
}

/**
 * Format date for display
 * @param string $date Date string
 * @param string $format Date format
 * @return string Formatted date
 */
function formatDate($date, $format = 'M d, Y') {
    if (empty($date)) return 'N/A';
    return date($format, strtotime($date));
}

/**
 * Truncate text to specified length
 * @param string $text Text to truncate
 * @param int $length Maximum length
 * @param string $suffix Suffix to append
 * @return string Truncated text
 */
function truncateText($text, $length = 100, $suffix = '...') {
    $text = strip_tags($text);
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . $suffix;
}

/**
 * Generate random token
 * @param int $length Token length
 * @return string Random token
 */
function generateToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Check if string is valid JSON
 * @param string $string String to check
 * @return bool True if valid JSON
 */
function isJson($string) {
    json_decode($string);
    return json_last_error() === JSON_ERROR_NONE;
}

/**
 * Safe redirect
 * @param string $url URL to redirect to
 * @param int $statusCode HTTP status code
 * @return void
 */
function safeRedirect($url, $statusCode = 302) {
    // Sanitize URL
    $url = filter_var($url, FILTER_SANITIZE_URL);
    
    header("Location: $url", true, $statusCode);
    exit();
}