<?php
namespace Helpers;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/**
 * Email Helper
 * Handles email sending operations using PHPMailer
 */
class EmailHelper {
    private $mail;
    private $config;
    
    public function __construct() {
        $configPath = __DIR__ . '/../config/email_config.php';
        if (!file_exists($configPath)) {
            throw new \Exception('Email configuration file not found');
        }
        
        $this->config = require $configPath;
        $this->mail = new PHPMailer(true);
        $this->setupSMTP();
    }
    
    /**
     * Configure SMTP settings
     * @return void
     */
    private function setupSMTP() {
        $smtp = $this->config['smtp'];
        
        $this->mail->isSMTP();
        $this->mail->Host = $smtp['host'];
        $this->mail->SMTPAuth = true;
        $this->mail->Username = $smtp['username'];
        $this->mail->Password = $smtp['password'];
        $this->mail->SMTPSecure = ($smtp['secure'] === 'tls') 
            ? PHPMailer::ENCRYPTION_STARTTLS 
            : PHPMailer::ENCRYPTION_SMTPS;
        $this->mail->Port = $smtp['port'];
        
        $this->mail->setFrom($smtp['from']['email'], $smtp['from']['name']);
    }
    
    /**
     * Send OTP verification email
     * @param string $email Recipient email address
     * @param string $username Recipient username
     * @param string $otp One-time password code
     * @return array Result with success status and message
     */
    public function sendVerificationOTP($email, $username, $otp) {
        try {
            // Sanitize inputs
            $email = filter_var($email, FILTER_SANITIZE_EMAIL);
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return ['success' => false, 'message' => 'Invalid email address'];
            }
            
            $username = htmlspecialchars($username, ENT_QUOTES, 'UTF-8');
            $otp = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');
            
            $this->mail->clearAddresses();
            $this->mail->addAddress($email, $username);
            
            $this->mail->isHTML(true);
            $this->mail->Subject = 'Email Verification Code';
            
            $this->mail->Body = $this->getOTPEmailTemplate($username, $otp);
            $this->mail->AltBody = "Hello {$username},\n\nYour verification code is: {$otp}\n\nThis code expires in 15 minutes.";
            
            $this->mail->send();
            error_log('✓ OTP sent to: ' . $email);
            
            return ['success' => true, 'message' => 'Email sent successfully'];
            
        } catch (Exception $e) {
            error_log('✗ Mail Error: ' . $this->mail->ErrorInfo);
            return ['success' => false, 'message' => $this->mail->ErrorInfo];
        }
    }
    
    /**
     * Get OTP email HTML template
     * @param string $username Recipient username
     * @param string $otp OTP code
     * @return string HTML email template
     */
    private function getOTPEmailTemplate($username, $otp) {
        $currentYear = date('Y');
        
        return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { 
            background: linear-gradient(135deg, #990000 0%, #7a0000 100%); 
            color: white; 
            padding: 30px; 
            text-align: center; 
            border-radius: 10px 10px 0 0; 
        }
        .header h1 { margin: 0; font-size: 24px; }
        .content { 
            background: #f9f9f9; 
            padding: 30px; 
            border-radius: 0 0 10px 10px; 
        }
        .otp-box { 
            background: white; 
            padding: 20px; 
            margin: 20px 0; 
            text-align: center; 
            border-radius: 8px; 
            border: 2px dashed #990000; 
        }
        .otp-code { 
            font-size: 32px; 
            font-weight: bold; 
            color: #990000; 
            letter-spacing: 8px; 
            margin: 10px 0; 
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 12px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔐 Email Verification</h1>
            <p>Verify your email address</p>
        </div>
        <div class="content">
            <p>Hello <strong>{$username}</strong>,</p>
            <p>Your email verification code is:</p>
            <div class="otp-box">
                <div class="otp-code">{$otp}</div>
            </div>
            <p><strong>This code will expire in 15 minutes.</strong></p>
            <p>If you didn't request this verification, please ignore this email.</p>
            <div class="footer">
                <p>This is an automated message, please do not reply.</p>
                <p>&copy; {$currentYear} Faculty Information System</p>
            </div>
        </div>
    </div>
</body>
</html>
HTML;
    }
}