<?php
/**
 * Faculty Data Helper Functions
 * Provides utility functions for faculty data retrieval and manipulation
 */

use Config\Database;

/**
 * Get complete faculty profile by user_id
 * @param int $user_id User ID
 * @return array|null Faculty data or null if not found
 */
function getFacultyProfile($user_id) {
    try {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("
            SELECT 
                f.*,
                u.username,
                u.email as user_email,
                u.user_type,
                u.is_active,
                u.email_verified,
                u.created_at as account_created,
                u.last_login
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE f.user_id = ?
        ");
        
        $stmt->execute([intval($user_id)]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        
    } catch (Exception $e) {
        error_log('Error fetching faculty profile: ' . $e->getMessage());
        return null;
    }
}

/**
 * Get complete faculty profile by faculty_id
 * @param int $faculty_id Faculty ID
 * @return array|null Faculty data or null if not found
 */
function getFacultyProfileById($faculty_id) {
    try {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("
            SELECT 
                f.*,
                u.username,
                u.email as user_email,
                u.user_type,
                u.is_active,
                u.email_verified,
                u.created_at as account_created,
                u.last_login
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE f.faculty_id = ?
        ");
        
        $stmt->execute([intval($faculty_id)]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        
    } catch (Exception $e) {
        error_log('Error fetching faculty profile by ID: ' . $e->getMessage());
        return null;
    }
}

/**
 * Get all faculty members with complete profile data
 * @param bool $active_only Return only active faculty
 * @param string|null $department Filter by department
 * @return array Array of faculty data
 */
function getAllFaculty($active_only = false, $department = null) {
    try {
        $db = Database::getInstance()->getConnection();
        
        $sql = "
            SELECT 
                f.*,
                u.username,
                u.email as user_email,
                u.user_type,
                u.is_active,
                u.email_verified,
                u.created_at as account_created,
                u.last_login
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE 1=1
        ";
        
        $params = [];
        
        if ($active_only) {
            $sql .= " AND u.is_active = 1";
        }
        
        if ($department) {
            $sql .= " AND f.department = ?";
            $params[] = $department;
        }
        
        $sql .= " ORDER BY f.last_name, f.first_name";
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log('Error fetching all faculty: ' . $e->getMessage());
        return [];
    }
}

/**
 * Format faculty full name
 * @param array $faculty Faculty data array
 * @param bool $include_middle Include middle name
 * @return string Formatted full name
 */
function formatFacultyName($faculty, $include_middle = true) {
    if (!$faculty) return 'N/A';
    
    $nameParts = [$faculty['first_name']];
    
    if ($include_middle && !empty($faculty['middle_name'])) {
        $nameParts[] = $faculty['middle_name'];
    }
    
    $nameParts[] = $faculty['last_name'];
    
    return implode(' ', array_map('htmlspecialchars', $nameParts));
}

/**
 * Get faculty statistics for dashboard
 * @return array Statistics data
 */
function getFacultyStatistics() {
    try {
        $db = Database::getInstance()->getConnection();
        $stats = [];
        
        // Total faculty count
        $stmt = $db->query("SELECT COUNT(*) as total FROM faculty");
        $stats['total'] = $stmt->fetchColumn();
        
        // Active faculty count
        $stmt = $db->query("
            SELECT COUNT(*) as active 
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE u.is_active = 1
        ");
        $stats['active'] = $stmt->fetchColumn();
        
        // Pending approval count
        $stmt = $db->query("
            SELECT COUNT(*) as pending 
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE u.is_active = 0
        ");
        $stats['pending'] = $stmt->fetchColumn();
        
        // Faculty by department
        $stmt = $db->query("
            SELECT 
                COALESCE(f.department, 'Unassigned') as department,
                COUNT(*) as count
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE u.is_active = 1
            GROUP BY f.department
            ORDER BY count DESC
        ");
        $stats['by_department'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $stats['inactive'] = $stats['total'] - $stats['active'];
        
        return $stats;
        
    } catch (Exception $e) {
        error_log('Error fetching faculty statistics: ' . $e->getMessage());
        return [
            'total' => 0,
            'active' => 0,
            'pending' => 0,
            'inactive' => 0,
            'by_department' => []
        ];
    }
}

/**
 * Update faculty profile information
 * @param int $faculty_id Faculty ID
 * @param array $data Fields to update
 * @return bool True on success
 */
function updateFacultyProfile($faculty_id, $data) {
    try {
        $db = Database::getInstance()->getConnection();
        
        $allowed_fields = [
            'first_name', 'middle_name', 'last_name', 'email',
            'contact_number', 'department', 'position'
        ];
        
        $update_fields = [];
        $params = [];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = ?";
                $params[] = $data[$field];
            }
        }
        
        if (empty($update_fields)) {
            return false;
        }
        
        $params[] = intval($faculty_id);
        
        $sql = "UPDATE faculty SET " . implode(', ', $update_fields) . ", updated_at = NOW() WHERE faculty_id = ?";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute($params);
        
    } catch (Exception $e) {
        error_log('Error updating faculty profile: ' . $e->getMessage());
        return false;
    }
}

/**
 * Search faculty by name, email, or department
 * @param string $search_term Search string
 * @return array Array of matching faculty
 */
function searchFaculty($search_term) {
    try {
        $db = Database::getInstance()->getConnection();
        $search_pattern = '%' . $search_term . '%';
        
        $stmt = $db->prepare("
            SELECT 
                f.*,
                u.username,
                u.email as user_email,
                u.is_active
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE 
                f.first_name LIKE ? OR
                f.middle_name LIKE ? OR
                f.last_name LIKE ? OR
                f.email LIKE ? OR
                f.department LIKE ? OR
                f.position LIKE ?
            ORDER BY f.last_name, f.first_name
        ");
        
        $params = array_fill(0, 6, $search_pattern);
        $stmt->execute($params);
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log('Error searching faculty: ' . $e->getMessage());
        return [];
    }
}

/**
 * Get faculty pending approval
 * @return array Array of pending faculty
 */
function getPendingFaculty() {
    try {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("
            SELECT 
                f.*,
                u.username,
                u.email as user_email,
                u.created_at as registration_date
            FROM faculty f
            INNER JOIN users u ON f.user_id = u.user_id
            WHERE u.is_active = 0
            ORDER BY u.created_at DESC
        ");
        
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (Exception $e) {
        error_log('Error fetching pending faculty: ' . $e->getMessage());
        return [];
    }
}

/**
 * Approve faculty account
 * @param int $user_id User ID to approve
 * @return bool True on success
 */
function approveFaculty($user_id) {
    try {
        $db = Database::getInstance()->getConnection();
        
        $stmt = $db->prepare("
            UPDATE users 
            SET is_active = 1, email_verified = 1
            WHERE user_id = ? AND user_type = 'faculty'
        ");
        
        return $stmt->execute([intval($user_id)]);
        
    } catch (Exception $e) {
        error_log('Error approving faculty: ' . $e->getMessage());
        return false;
    }
}

/**
 * Display faculty profile card (HTML output)
 * @param array $faculty Faculty data
 * @param bool $show_actions Show edit/delete actions
 * @return string HTML output
 */
function displayFacultyCard($faculty, $show_actions = false) {
    if (!$faculty) return '<p>Faculty not found</p>';
    
    $full_name = formatFacultyName($faculty);
    $status_class = $faculty['is_active'] ? 'active' : 'inactive';
    $status_text = $faculty['is_active'] ? 'Active' : 'Pending Approval';
    
    ob_start();
    ?>
    <div class="faculty-card <?php echo $status_class; ?>">
        <div class="faculty-header">
            <h3><?php echo $full_name; ?></h3>
            <span class="status-badge <?php echo $status_class; ?>">
                <?php echo $status_text; ?>
            </span>
        </div>
        
        <div class="faculty-details">
            <?php if (!empty($faculty['position'])): ?>
            <p><strong>Position:</strong> <?php echo htmlspecialchars($faculty['position']); ?></p>
            <?php endif; ?>
            
            <?php if (!empty($faculty['department'])): ?>
            <p><strong>Department:</strong> <?php echo htmlspecialchars($faculty['department']); ?></p>
            <?php endif; ?>
            
            <p><strong>Email:</strong> <?php echo htmlspecialchars($faculty['email']); ?></p>
            
            <?php if (!empty($faculty['contact_number'])): ?>
            <p><strong>Contact:</strong> <?php echo htmlspecialchars($faculty['contact_number']); ?></p>
            <?php endif; ?>
            
            <p><strong>Username:</strong> <?php echo htmlspecialchars($faculty['username']); ?></p>
            
            <?php if (isset($faculty['account_created'])): ?>
            <p><strong>Member Since:</strong> <?php echo date('M d, Y', strtotime($faculty['account_created'])); ?></p>
            <?php endif; ?>
        </div>
        
        <?php if ($show_actions): ?>
        <div class="faculty-actions">
            <a href="edit_faculty.php?id=<?php echo intval($faculty['faculty_id']); ?>" class="btn btn-primary">
                <i class="fas fa-edit"></i> Edit
            </a>
            <a href="view_faculty.php?id=<?php echo intval($faculty['faculty_id']); ?>" class="btn btn-secondary">
                <i class="fas fa-eye"></i> View Details
            </a>
        </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}