<?php
/**
 * Get Notifications
 * Returns list of notifications for authenticated user
 */

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

header('Content-Type: application/json');
require_once '../config/Database.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Not authenticated'
    ]);
    exit();
}

try {
    // Sanitize user ID
    $userId = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
    if ($userId === false) {
        throw new Exception('Invalid user ID');
    }
    
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
    
    // Fetch latest 10 notifications
    $stmt = $pdo->prepare("
        SELECT 
            id,              
            user_id, 
            title, 
            message, 
            type, 
            is_read, 
            created_at 
        FROM notifications 
        WHERE user_id = ? 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $stmt->execute([$userId]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'notifications' => $notifications
    ]);
    
} catch (PDOException $e) {
    error_log("Get Notifications Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error'
    ]);
} catch (Exception $e) {
    error_log("Get Notifications Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred'
    ]);
}