<?php
/**
 * Delete Notification
 * Deletes a specific notification for the authenticated user
 */

session_start();
header('Content-Type: application/json');
require_once '../config/Database.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Unauthorized'
    ]);
    exit();
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false, 
        'message' => 'Invalid request method'
    ]);
    exit();
}

try {
    // Get and validate input
    $data = json_decode(file_get_contents('php://input'), true);
    $notificationId = filter_var(
        $data['notification_id'] ?? 0, 
        FILTER_VALIDATE_INT
    );
    
    if ($notificationId === false || $notificationId <= 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'Valid notification ID required'
        ]);
        exit();
    }
    
    // Sanitize user ID
    $userId = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
    if ($userId === false) {
        throw new Exception('Invalid user ID');
    }
    
    // Delete notification
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
    
    $stmt = $pdo->prepare("
        DELETE FROM notifications 
        WHERE notification_id = ? AND user_id = ?
    ");
    $stmt->execute([$notificationId, $userId]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true, 
            'message' => 'Notification deleted'
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Notification not found'
        ]);
    }
    
} catch (PDOException $e) {
    error_log("Delete Notification Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error'
    ]);
} catch (Exception $e) {
    error_log("Delete Notification Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred'
    ]);
}