<?php
/**
 * Mark All Notifications Read
 * Marks all unread notifications as read for authenticated user
 */

session_start();
header('Content-Type: application/json');
require_once '../config/Database.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Not authenticated'
    ]);
    exit();
}

try {
    // Sanitize user ID
    $userId = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
    if ($userId === false) {
        throw new Exception('Invalid user ID');
    }
    
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
    
    // Mark all as read
    $stmt = $pdo->prepare("
        UPDATE notifications 
        SET is_read = 1 
        WHERE user_id = ? AND is_read = 0
    ");
    $stmt->execute([$userId]);
    
    echo json_encode([
        'success' => true,
        'message' => 'All notifications marked as read'
    ]);
    
} catch (PDOException $e) {
    error_log("Mark All Read Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database error'
    ]);
} catch (Exception $e) {
    error_log("Mark All Read Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred'
    ]);
}