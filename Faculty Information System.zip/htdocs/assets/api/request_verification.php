<?php
/**
 * Request Email Verification
 * Generates OTP and sends verification email
 */

session_start();
header('Content-Type: application/json');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/Database.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Not authenticated'
    ]);
    exit();
}

try {
    // Sanitize user ID
    $userId = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
    if ($userId === false) {
        throw new Exception('Invalid user ID');
    }
    
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
    
    // Get user info
    $stmt = $pdo->prepare("
        SELECT email, username, email_verified 
        FROM users 
        WHERE user_id = ?
    ");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode([
            'success' => false, 
            'message' => 'User not found'
        ]);
        exit();
    }
    
    // Check if already verified
    if ($user['email_verified'] == 1) {
        echo json_encode([
            'success' => false, 
            'message' => 'Email already verified'
        ]);
        exit();
    }
    
    // Generate secure 6-digit OTP
    $otp = sprintf("%06d", random_int(0, 999999));
    $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));
    
    // Store OTP in database
    $stmt = $pdo->prepare("
        UPDATE users 
        SET verification_token = ?,
            verification_token_expiry = ?,
            updated_at = NOW()
        WHERE user_id = ?
    ");
    $stmt->execute([$otp, $expiry, $userId]);
    
    // Send email
    $mail = new PHPMailer(true);
    
    // SMTP Configuration
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'YOUR_EMAIL@gmail.com'; // Change this
    $mail->Password = 'YOUR_16_CHAR_APP_PASSWORD'; // Change this
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    
    // Email settings
    $mail->setFrom('YOUR_EMAIL@gmail.com', 'Your App Name');
    $mail->addAddress($user['email'], $user['username']);
    $mail->isHTML(true);
    $mail->Subject = 'Email Verification Code';
    
    // Clean output for security
    $cleanUsername = htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8');
    $cleanOtp = htmlspecialchars($otp, ENT_QUOTES, 'UTF-8');
    
    // Email body
    $mail->Body = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                color: white; 
                padding: 30px; 
                text-align: center; 
                border-radius: 10px 10px 0 0; 
            }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .otp-box { 
                background: white; 
                padding: 20px; 
                margin: 20px 0; 
                text-align: center; 
                border-radius: 8px; 
                border: 2px dashed #667eea; 
            }
            .otp-code { 
                font-size: 32px; 
                font-weight: bold; 
                color: #667eea; 
                letter-spacing: 8px; 
                margin: 10px 0; 
            }
            .footer { 
                text-align: center; 
                margin-top: 20px; 
                font-size: 12px; 
                color: #666; 
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🔐 Email Verification</h1>
                <p>Verify your email address</p>
            </div>
            <div class='content'>
                <p>Hello <strong>{$cleanUsername}</strong>,</p>
                <p>Your email verification code is:</p>
                <div class='otp-box'>
                    <div class='otp-code'>{$cleanOtp}</div>
                </div>
                <p><strong>This code will expire in 15 minutes.</strong></p>
                <p>If you didn't request this verification, please ignore this email.</p>
                <div class='footer'>
                    <p>This is an automated message, please do not reply.</p>
                </div>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $mail->AltBody = "Hello {$cleanUsername},\n\n"
                   . "Your email verification code is: {$cleanOtp}\n\n"
                   . "This code will expire in 15 minutes.\n"
                   . "If you didn't request this verification, please ignore this email.";
    
    $mail->send();
    
    echo json_encode([
        'success' => true, 
        'message' => 'Verification code sent successfully'
    ]);
    
} catch (Exception $e) {
    error_log("Verification Email Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Failed to send verification code'
    ]);
} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database error occurred'
    ]);
}