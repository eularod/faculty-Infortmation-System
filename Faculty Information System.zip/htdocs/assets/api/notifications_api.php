<?php
/**
 * Notifications API
 * Multiple notification endpoints in one file
 * Usage: Add ?action=get_latest or ?action=get_all etc.
 */

session_start();
header('Content-Type: application/json');
require_once '../config/Database.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Unauthorized'
    ]);
    exit();
}

// Sanitize user ID
$userId = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
if ($userId === false) {
    echo json_encode([
        'success' => false, 
        'message' => 'Invalid user ID'
    ]);
    exit();
}

// Get database connection
try {
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
} catch (PDOException $e) {
    error_log("Database Connection Error: " . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'message' => 'Database connection failed'
    ]);
    exit();
}

// Determine action
$action = $_GET['action'] ?? 'get_all';

try {
    switch ($action) {
        
        // Get latest notifications since last check
        case 'get_latest':
            $lastCheck = $_SESSION['last_notification_check'] ?? date('Y-m-d H:i:s', strtotime('-1 hour'));
            
            $stmt = $pdo->prepare("
                SELECT notification_id, title, message, type, is_read, link, created_at
                FROM notifications 
                WHERE user_id = ? 
                AND created_at > ?
                AND is_read = 0
                ORDER BY created_at DESC
                LIMIT 5
            ");
            $stmt->execute([$userId, $lastCheck]);
            $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $_SESSION['last_notification_check'] = date('Y-m-d H:i:s');
            
            echo json_encode([
                'success' => true,
                'notifications' => $notifications,
                'has_new' => count($notifications) > 0,
                'count' => count($notifications)
            ]);
            break;
            
        // Get all notifications with pagination
        case 'get_all':
            $limit = filter_var($_GET['limit'] ?? 20, FILTER_VALIDATE_INT);
            $offset = filter_var($_GET['offset'] ?? 0, FILTER_VALIDATE_INT);
            
            // Validate limits
            $limit = ($limit === false || $limit < 1 || $limit > 100) ? 20 : $limit;
            $offset = ($offset === false || $offset < 0) ? 0 : $offset;
            
            $stmt = $pdo->prepare("
                SELECT 
                    notification_id,
                    title,
                    message,
                    type,
                    is_read,
                    link,
                    created_at,
                    TIMESTAMPDIFF(SECOND, created_at, NOW()) as seconds_ago
                FROM notifications 
                WHERE user_id = ? 
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$userId, $limit, $offset]);
            $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format time ago
            foreach ($notifications as &$notif) {
                $notif['time_ago'] = formatTimeAgo($notif['seconds_ago']);
            }
            
            echo json_encode([
                'success' => true,
                'notifications' => $notifications,
                'count' => count($notifications)
            ]);
            break;
            
        // Mark notification as read
        case 'mark_read':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                echo json_encode([
                    'success' => false, 
                    'message' => 'POST method required'
                ]);
                exit();
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            $notificationId = filter_var($data['notification_id'] ?? 0, FILTER_VALIDATE_INT);
            
            if ($notificationId === false || $notificationId <= 0) {
                echo json_encode([
                    'success' => false, 
                    'message' => 'Valid notification ID required'
                ]);
                exit();
            }
            
            $stmt = $pdo->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE notification_id = ? AND user_id = ?
            ");
            $stmt->execute([$notificationId, $userId]);
            
            echo json_encode([
                'success' => $stmt->rowCount() > 0,
                'message' => $stmt->rowCount() > 0 ? 'Marked as read' : 'Notification not found'
            ]);
            break;
            
        // Mark all as read
        case 'mark_all_read':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                echo json_encode([
                    'success' => false, 
                    'message' => 'POST method required'
                ]);
                exit();
            }
            
            $stmt = $pdo->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE user_id = ? AND is_read = 0
            ");
            $stmt->execute([$userId]);
            
            echo json_encode([
                'success' => true,
                'message' => 'All notifications marked as read',
                'count' => $stmt->rowCount()
            ]);
            break;
            
        // Get unread count
        case 'unread_count':
            $stmt = $pdo->prepare("
                SELECT COUNT(*) as unread_count 
                FROM notifications 
                WHERE user_id = ? AND is_read = 0
            ");
            $stmt->execute([$userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode([
                'success' => true,
                'count' => (int)$result['unread_count']
            ]);
            break;
            
        default:
            echo json_encode([
                'success' => false, 
                'message' => 'Invalid action'
            ]);
            break;
    }
    
} catch (PDOException $e) {
    error_log("Notification API Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error'
    ]);
}

/**
 * Format seconds to human-readable time ago
 */
function formatTimeAgo($seconds) {
    $seconds = (int)$seconds;
    
    if ($seconds < 60) return 'Just now';
    if ($seconds < 3600) return floor($seconds / 60) . 'm ago';
    if ($seconds < 86400) return floor($seconds / 3600) . 'h ago';
    if ($seconds < 604800) return floor($seconds / 86400) . 'd ago';
    if ($seconds < 2592000) return floor($seconds / 604800) . 'w ago';
    
    return date('M j, Y', time() - $seconds);
}