<?php
/**
 * Mark Notification Read
 * Marks a single notification as read for authenticated user
 */

session_start();
header('Content-Type: application/json');
require_once '../config/Database.php';

// Check authentication
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false, 
        'message' => 'Not authenticated'
    ]);
    exit();
}

try {
    // Get and validate input
    $input = json_decode(file_get_contents('php://input'), true);
    $notificationId = filter_var(
        $input['notification_id'] ?? 0, 
        FILTER_VALIDATE_INT
    );
    
    if ($notificationId === false || $notificationId <= 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'Valid notification ID required'
        ]);
        exit();
    }
    
    // Sanitize user ID
    $userId = filter_var($_SESSION['user_id'], FILTER_VALIDATE_INT);
    if ($userId === false) {
        throw new Exception('Invalid user ID');
    }
    
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
    
    // Mark notification as read
    $stmt = $pdo->prepare("
        UPDATE notifications 
        SET is_read = 1 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$notificationId, $userId]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Notification marked as read'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Notification not found'
        ]);
    }
    
} catch (PDOException $e) {
    error_log("Mark Notification Read Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error'
    ]);
} catch (Exception $e) {
    error_log("Mark Notification Read Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred'
    ]);
}