<?php
require_once '../init.php';

// Set JSON header
header('Content-Type: application/json');

// Validate user_id parameter
$user_id = (int)($_GET['user_id'] ?? 0);

if ($user_id <= 0) {
    echo json_encode([
        'success' => false,
        'verified' => false,
        'message' => 'Invalid user ID'
    ]);
    exit;
}

try {
    // Get database connection
    $db = \Config\Database::getInstance()->getConnection();
    
    // Check email verification status
    $stmt = $db->prepare("SELECT email_verified FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user_data) {
        $is_verified = ($user_data['email_verified'] == 1);
        
        echo json_encode([
            'success' => true,
            'verified' => $is_verified,
            'timestamp' => date('Y-m-d H:i:s')
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'verified' => false,
            'message' => 'User not found'
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'verified' => false,
        'message' => 'Database error',
        'error' => $e->getMessage()
    ]);
}
?>