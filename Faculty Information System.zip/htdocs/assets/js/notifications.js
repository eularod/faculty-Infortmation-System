/**
 * Notification Manager
 * Handles real-time notification updates
 */

// Helper function to get correct API path
function getApiPath(path) {
    if (document.currentScript && document.currentScript.src.includes('/assets/js/')) {
        return '../api/' + path.replace(/^\.\.\/api\//, '');
    }
    return 'api/' + path.replace(/^\.\.\/api\//, '');
}

const NotificationManager = {
    isOpen: false,
    lastCheckTime: null,
    checkInterval: null,
    unreadCount: 0,
    notifications: [],
    
    /**
     * Initialize notification manager
     */
    init: function() {
        console.log('NotificationManager initializing...');
        this.setupEventListeners();
        this.loadNotifications();
        this.startPolling();
        this.updateUnreadCount();
    },
    
    /**
     * Setup event listeners
     */
    setupEventListeners: function() {
        const bell = document.getElementById('notificationBell');
        const dropdown = document.getElementById('notificationDropdown');
        
        if (!bell) {
            console.error('Notification bell not found!');
            return;
        }
        
        // Toggle dropdown on bell click
        bell.addEventListener('click', function(e) {
            e.stopPropagation();
            NotificationManager.toggleDropdown();
        });
        
        // Close on outside click
        document.addEventListener('click', function(e) {
            const bellElement = document.getElementById('notificationBell');
            const dropdownElement = document.getElementById('notificationDropdown');
            
            if (dropdownElement && bellElement && 
                !dropdownElement.contains(e.target) && 
                !bellElement.contains(e.target)) {
                NotificationManager.closeDropdown();
            }
        });
        
        // Prevent dropdown close when clicking inside
        if (dropdown) {
            dropdown.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        }
    },
    
    /**
     * Toggle dropdown visibility
     */
    toggleDropdown: function() {
        const dropdown = document.getElementById('notificationDropdown');
        if (!dropdown) return;
        
        this.isOpen = !this.isOpen;
        
        if (this.isOpen) {
            dropdown.classList.add('show');
            this.loadNotifications();
        } else {
            dropdown.classList.remove('show');
        }
    },
    
    /**
     * Close dropdown
     */
    closeDropdown: function() {
        const dropdown = document.getElementById('notificationDropdown');
        if (dropdown) {
            dropdown.classList.remove('show');
            this.isOpen = false;
        }
    },
    
    /**
     * Load notifications from server
     */
    loadNotifications: function(offset, append) {
        offset = offset || 0;
        append = append || false;
        
        const list = document.getElementById('notificationList');
        if (!list) return;
        
        if (!append) {
            list.innerHTML = '<div class="loading-spinner">Loading notifications...</div>';
        }
        
        fetch(getApiPath('get_notifications.php?limit=20&offset=' + offset))
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.success) {
                    if (append) {
                        NotificationManager.notifications = NotificationManager.notifications.concat(data.notifications);
                    } else {
                        NotificationManager.notifications = data.notifications;
                    }
                    NotificationManager.renderNotifications();
                } else {
                    list.innerHTML = '<div class="no-notifications"><div class="no-notifications-icon">⚠️</div><p>Failed to load</p></div>';
                }
            })
            .catch(function(error) {
                console.error('Load error:', error);
                list.innerHTML = '<div class="no-notifications"><div class="no-notifications-icon">⚠️</div><p>Error loading</p></div>';
            });
    },
    
    /**
     * Render notifications in DOM
     */
    renderNotifications: function() {
        const list = document.getElementById('notificationList');
        if (!list) return;
        
        if (this.notifications.length === 0) {
            list.innerHTML = '<div class="no-notifications"><div class="no-notifications-icon">🔔</div><p>No notifications yet</p></div>';
            return;
        }
        
        let html = '';
        this.notifications.forEach(function(notif) {
            const unreadClass = notif.is_read == 0 ? 'unread' : '';
            const typeClass = notif.type || 'info';
            const escapedTitle = NotificationManager.escapeHtml(notif.title);
            const escapedMessage = NotificationManager.escapeHtml(notif.message);
            const escapedLink = notif.link || '';
            
            html += '<div class="notification-item ' + unreadClass + '" data-id="' + notif.id + '" onclick="NotificationManager.handleNotificationClick(' + notif.id + ', \'' + escapedLink + '\')">';
            html += '<span class="notification-type ' + typeClass + '">' + typeClass.toUpperCase() + '</span>';
            html += '<div class="notification-title">' + escapedTitle + '</div>';
            html += '<div class="notification-message">' + escapedMessage + '</div>';
            html += '<div class="notification-time">' + NotificationManager.formatTime(notif.created_at) + '</div>';
            html += '</div>';
        });
        
        list.innerHTML = html;
    },
    
    /**
     * Handle notification click
     */
    handleNotificationClick: function(notificationId, link) {
        this.markAsRead(notificationId);
        
        if (link && link !== 'null' && link !== '' && link !== 'undefined') {
            window.location.href = link;
        }
    },
    
    /**
     * Mark notification as read
     */
    markAsRead: function(notificationId) {
        fetch(getApiPath('mark_notification_read.php'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ notification_id: notificationId })
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.success) {
                const item = document.querySelector('[data-id="' + notificationId + '"]');
                if (item) {
                    item.classList.remove('unread');
                }
                
                NotificationManager.updateUnreadCount();
                
                // Update local array
                const notif = NotificationManager.notifications.find(function(n) {
                    return n.id == notificationId;
                });
                if (notif) {
                    notif.is_read = 1;
                }
            }
        })
        .catch(function(error) {
            console.error('Mark read error:', error);
        });
    },
    
    /**
     * Update unread notification count
     */
    updateUnreadCount: function() {
        fetch(getApiPath('get_unread_count.php'))
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                if (data.success) {
                    NotificationManager.unreadCount = data.count;
                    const badge = document.getElementById('notificationBadge');
                    const bellContainer = document.getElementById('notificationBell');
                    
                    if (NotificationManager.unreadCount > 0) {
                        if (!badge && bellContainer) {
                            const newBadge = document.createElement('span');
                            newBadge.className = 'notification-badge';
                            newBadge.id = 'notificationBadge';
                            newBadge.textContent = NotificationManager.unreadCount;
                            bellContainer.appendChild(newBadge);
                        } else if (badge) {
                            badge.textContent = NotificationManager.unreadCount;
                            badge.style.display = 'block';
                        }
                    } else if (badge) {
                        badge.style.display = 'none';
                    }
                }
            })
            .catch(function(error) {
                console.error('Update count error:', error);
            });
    },
    
    /**
     * Start polling for new notifications
     */
    startPolling: function() {
        this.checkInterval = setInterval(function() {
            if (!NotificationManager.isOpen) {
                NotificationManager.updateUnreadCount();
            }
        }, 30000);
    },
    
    /**
     * Format timestamp to readable time
     */
    formatTime: function(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return diffMins + ' minute' + (diffMins > 1 ? 's' : '') + ' ago';
        if (diffHours < 24) return diffHours + ' hour' + (diffHours > 1 ? 's' : '') + ' ago';
        if (diffDays < 7) return diffDays + ' day' + (diffDays > 1 ? 's' : '') + ' ago';
        
        return date.toLocaleDateString();
    },
    
    /**
     * Escape HTML to prevent XSS
     */
    escapeHtml: function(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    
    /**
     * Destroy notification manager
     */
    destroy: function() {
        if (this.checkInterval) {
            clearInterval(this.checkInterval);
        }
    }
};

/**
 * Mark all notifications as read
 */
function markAllAsRead() {
    fetch(getApiPath('mark_all_notifications_read.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(data) {
        if (data.success) {
            document.querySelectorAll('.notification-item.unread').forEach(function(item) {
                item.classList.remove('unread');
            });
            
            NotificationManager.updateUnreadCount();
            
            const markAllBtn = document.querySelector('.mark-all-read');
            if (markAllBtn) {
                markAllBtn.style.display = 'none';
            }
        }
    })
    .catch(function(error) {
        console.error('Mark all error:', error);
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing NotificationManager...');
    NotificationManager.init();
});

// Cleanup on page unload
window.addEventListener('beforeunload', function() {
    NotificationManager.destroy();
});