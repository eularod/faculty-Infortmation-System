-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2025 at 05:28 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS `faculty_info_system`;
USE `faculty_info_system`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty_info_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_requests`
--

CREATE TABLE `admin_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `awards_achievements`
--

CREATE TABLE `awards_achievements` (
  `award_id` int(11) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `award_type_id` int(11) DEFAULT NULL,
  `award_name` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `awarding_organization` varchar(200) DEFAULT NULL,
  `year_received` int(11) DEFAULT NULL,
  `prize_amount` decimal(10,2) DEFAULT NULL,
  `certificate_path` varchar(255) DEFAULT NULL,
  `is_national` tinyint(1) DEFAULT 0,
  `is_international` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `awards_achievements`
--

INSERT INTO `awards_achievements` (`award_id`, `faculty_id`, `award_type_id`, `award_name`, `description`, `awarding_organization`, `year_received`, `prize_amount`, `certificate_path`, `is_national`, `is_international`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, NULL, 1, 'NSTP', '', 'WMSU', NULL, 0.00, NULL, 0, 0, '2025-12-15 07:47:15', '2025-12-15 07:47:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `award_types`
--

CREATE TABLE `award_types` (
  `award_type_id` int(11) NOT NULL,
  `type_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `award_types`
--

INSERT INTO `award_types` (`award_type_id`, `type_name`, `description`, `category`, `is_active`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'Best Researcher', 'Awarded to faculty members with outstanding research contributions', 'Research Excellence', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(2, 'Teaching Excellence', 'Recognizes exceptional teaching performance and student engagement', 'Teaching', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(3, 'Community Service', 'Honors faculty members for outstanding community service and outreach', 'Service', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(4, 'Innovation Award', 'Recognizes innovative approaches in teaching, research, or administration', 'Innovation', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(5, 'Publication Award', 'Awarded for significant publications in peer-reviewed journals', 'Research Excellence', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(6, 'Mentor of the Year', 'Recognizes outstanding mentorship of students and junior faculty', 'Mentorship', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(7, 'Leadership Award', 'Honors exceptional leadership in academic or administrative roles', 'Leadership', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(8, 'Curriculum Development', 'Recognizes significant contributions to curriculum innovation', 'Teaching', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(9, 'International Collaboration', 'Awarded for fostering international partnerships and collaborations', 'Collaboration', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(10, 'Lifetime Achievement', 'Honors a distinguished career of service to the institution', 'Special Recognition', 1, '2025-12-15 07:41:06', '2025-12-15 07:41:06', 1, 1),
(11, 'Research Excellence Award', 'Awarded to faculty members with outstanding research contributions and publications', 'Research', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(12, 'Best Teacher Award', 'Recognizes exceptional teaching performance and student engagement', 'Teaching', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(13, 'Community Extension Award', 'Honors faculty members for outstanding community service and outreach programs', 'Extension', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(14, 'Innovation in Education Award', 'Recognizes innovative approaches in teaching methodologies and curriculum development', 'Teaching', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(15, 'Outstanding Publication Award', 'Awarded for significant publications in high-impact peer-reviewed journals', 'Research', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(16, 'Best Mentor Award', 'Recognizes outstanding mentorship of students and junior faculty members', 'Mentorship', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(17, 'Leadership Excellence Award', 'Honors exceptional leadership in academic or administrative roles', 'Leadership', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(18, 'International Collaboration Award', 'Awarded for fostering international partnerships and research collaborations', 'Research', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(19, 'Student Choice Award', 'Awarded based on student votes for most impactful teacher', 'Teaching', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(20, 'Lifetime Achievement Award', 'Honors a distinguished career of service and contribution to the institution', 'Special', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(21, 'Best Research Paper Award', 'Recognizes the best research paper published in a given year', 'Research', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(22, 'Extension Program of the Year', 'Awarded for the most impactful community extension program', 'Extension', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(23, 'Creative Teaching Award', 'Recognizes creativity and innovation in teaching methods', 'Teaching', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(24, 'Professional Development Award', 'Honors commitment to continuous professional growth and development', 'Professional', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL),
(25, 'Service Excellence Award', 'Recognizes exceptional service to the university community', 'Service', 1, '2025-12-15 07:45:32', '2025-12-15 07:45:32', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `department_id` int(11) NOT NULL,
  `department_name` varchar(100) NOT NULL,
  `department_code` varchar(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`department_id`, `department_name`, `department_code`, `description`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(11, 'Computer Science', 'CS', 'Department of Computer Science', '2025-12-14 09:28:16', '2025-12-14 09:28:16', NULL, NULL),
(12, 'Information Technology', 'IT', 'Department of Information Technology', '2025-12-14 09:28:16', '2025-12-14 09:28:16', NULL, NULL),
(13, 'Biology', 'BIO', 'Department of Biology', '2025-12-14 09:28:16', '2025-12-14 09:28:16', NULL, NULL),
(14, 'Mathematics', 'MATH', 'Department of Mathematics', '2025-12-14 09:28:16', '2025-12-14 09:28:16', NULL, NULL),
(15, 'Physics', 'PHYS', 'Department of Physics', '2025-12-14 09:28:16', '2025-12-14 09:28:16', NULL, NULL),
(16, 'Chemistry', 'CHEM', 'Department of Chemistry', '2025-12-14 09:28:16', '2025-12-14 09:28:16', NULL, NULL),
(17, 'English', 'ENG', 'Department of English', '2025-12-14 09:28:16', '2025-12-14 09:28:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `education_id` int(11) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `school_name` varchar(200) DEFAULT NULL,
  `degree_title` varchar(200) DEFAULT NULL,
  `year_graduated` int(11) DEFAULT NULL,
  `field_of_study` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`education_id`, `faculty_id`, `school_name`, `degree_title`, `year_graduated`, `field_of_study`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 1, 'Western Mindanao State University', 'Bachelor of Science in Information Technology', 2020, 'Information Technology', '2025-12-15 07:39:23', '2025-12-15 07:39:23', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `faculty_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`faculty_id`, `user_id`, `department_id`, `first_name`, `middle_name`, `last_name`, `email`, `contact_number`, `address`, `photo_url`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 3, 14, 'Kevin', NULL, 'Dela Cruz', 'eulagraciellarodriguez@gmail.com', '12345678911', 'Tumaga, Z.C.', NULL, '2025-12-13 08:43:27', '2025-12-14 19:08:18', 2, 2),
(5, 9, 11, 'Eula', NULL, 'Rodriguez', 'muchachasxd1@gmail.com', NULL, NULL, NULL, '2025-12-15 07:14:49', '2025-12-15 08:05:55', NULL, 2);



--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `title`, `message`, `type`, `is_read`, `read_at`, `link`, `created_at`) VALUES
(1, 3, '🎉 Welcome to Faculty Information System', 'Welcome Kevin Dela Cruz! Your account has been created. Username: kevin. Please complete your profile to get started.', 'success', 1, NULL, 'profile.php', '2025-12-13 08:43:27'),
(2, 3, '👤 Profile Updated', 'Your email has been updated by admin.', 'info', 0, NULL, 'profile.php', '2025-12-13 10:06:22'),
(5, 3, '👤 Profile Updated', 'Your department has been updated by admin.', 'info', 0, NULL, 'profile.php', '2025-12-14 19:08:18'),
(7, 2, 'Verification Email Resent', 'Resent verification email to muchachasxd1 (muchachasxd1@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-14 20:32:00'),
(9, 2, 'Verification Code Sent', 'Sent OTP verification code to zhanjianahjaji21 (zhanjianahjaji21@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 01:30:48'),
(12, 2, 'Faculty Account Approved', 'You have approved the account for jessaf805 (jessaf805@gmail.com). Verification email sent.', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 01:51:38'),
(17, 2, 'Verification Code Sent', 'Sent OTP verification code to jessaf805 (jessaf805@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 02:10:06'),
(19, 2, 'Verification Code Sent', 'Sent OTP verification code to jessaf805 (jessaf805@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 02:11:35'),
(21, 2, 'Verification Code Sent', 'Sent OTP verification code to jessaf805 (jessaf805@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 02:14:24'),
(25, 2, 'Verification Code Sent', 'Sent OTP verification code to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:07:28'),
(27, 2, 'Verification Code Sent', 'Sent OTP verification code to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:07:49'),
(29, 2, 'Verification Link Sent', 'Sent verification link to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:31:56'),
(31, 2, 'Verification Link Sent', 'Sent verification link to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:32:45'),
(33, 2, 'Verification Link Sent', 'Sent verification link to jessaf805 (jessaf805@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:33:00'),
(35, 2, 'Verification Link Sent', 'Sent verification link to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:38:34'),
(37, 2, 'Verification Link Sent', 'Sent verification link to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:38:37'),
(40, 2, 'Verification Link Sent', 'Sent verification link to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:47:53'),
(42, 2, 'Verification Link Sent', 'Sent verification link to jessaf805 (jessaf805@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 03:48:07'),
(44, 2, 'Verification Link Sent', 'Sent verification link to jessaf805 (jessaf805@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 04:09:27'),
(46, 2, 'Verification Link Sent', 'Sent verification link to marc (kevindelacruz1521@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 04:13:50'),
(54, 9, '🎉 Account Activated', 'Congratulations! Your account has been activated by the administrator. A verification email has been sent to muchachasxd1@gmail.com. Please verify your email address within 24 hours to complete the activation process.', 'success', 0, NULL, 'verify_email.php', '2025-12-15 07:15:16'),
(55, 2, 'Faculty Account Approved', 'You have approved the account for muchachasxd1 (muchachasxd1@gmail.com). Verification email sent successfully.', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 07:15:16'),
(56, 9, '📧 Verification Link Sent', 'A verification link has been sent to muchachasxd1@gmail.com. Please check your inbox and click the link to verify your account within 24 hours.', 'info', 0, NULL, NULL, '2025-12-15 07:15:48'),
(57, 2, 'Verification Link Sent', 'Sent verification link to muchachasxd1 (muchachasxd1@gmail.com).', 'info', 0, NULL, 'admin_requests.php', '2025-12-15 07:15:48'),
(58, 9, 'Profile Updated', 'Your phone, address has been updated by admin.', 'info', 0, NULL, 'profile.php', '2025-12-15 07:20:43'),
(59, 3, 'Education Added', 'Your Bachelor of Science Master of Information Technology from Western Mindanao State University has been added to your profile.', 'success', 0, NULL, 'profile.php#education', '2025-12-15 07:39:24'),
(60, 3, 'Research Added', 'Your research &#039;Exploring the Impact of Gamification on Student Motivation in Learning Computer Programming&#039; has been added to your profile.', 'success', 0, NULL, 'profile.php#research', '2025-12-15 07:39:51'),
(61, 3, 'Award Added', 'Congratulations! The award &#039;NSTP&#039; from WMSU has been added to your profile.', 'success', 0, NULL, 'profile.php#awards', '2025-12-15 07:47:15');

-- --------------------------------------------------------

--
-- Table structure for table `research`
--

CREATE TABLE `research` (
  `research_id` int(11) NOT NULL,
  `faculty_id` int(11) DEFAULT NULL,
  `research_title` varchar(255) NOT NULL,
  `research_type_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `year` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `research`
--

INSERT INTO `research` (`research_id`, `faculty_id`, `research_title`, `research_type_id`, `status_id`, `year`, `description`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 1, 'Exploring the Impact of Gamification on Student Motivation in Learning Computer Programming', 2, 2, 2020, NULL, '2025-12-15 07:39:51', '2025-12-15 07:39:51', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `research_statuses`
--

CREATE TABLE `research_statuses` (
  `status_id` int(11) NOT NULL,
  `status_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `research_statuses`
--

INSERT INTO `research_statuses` (`status_id`, `status_name`, `description`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'ongoing', 'Research currently in progress', '2025-12-13 08:42:13', '2025-12-13 08:42:13', NULL, NULL),
(2, 'completed', 'Research completed but not published', '2025-12-13 08:42:13', '2025-12-13 08:42:13', NULL, NULL),
(3, 'published', 'Research completed and published', '2025-12-13 08:42:13', '2025-12-13 08:42:13', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `research_types`
--

CREATE TABLE `research_types` (
  `research_type_id` int(11) NOT NULL,
  `type_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `research_types`
--

INSERT INTO `research_types` (`research_type_id`, `type_name`, `description`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'project', 'Research project', '2025-12-13 08:42:13', '2025-12-13 08:42:13', NULL, NULL),
(2, 'paper', 'Academic paper or article', '2025-12-13 08:42:13', '2025-12-13 08:42:13', NULL, NULL),
(3, 'publication', 'Published work', '2025-12-13 08:42:13', '2025-12-13 08:42:13', NULL, NULL),
(4, 'thesis', 'Graduate or postgraduate thesis', '2025-12-13 08:42:13', '2025-12-13 08:42:13', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `user_type_id` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `email_verified` tinyint(1) DEFAULT 0,
  `verification_token` varchar(255) DEFAULT NULL,
  `verification_token_expiry` datetime DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `verification_success_email_sent` tinyint(1) DEFAULT 0 COMMENT 'Flag to track if verification success email was sent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `email`, `user_type_id`, `is_active`, `email_verified`, `verification_token`, `verification_token_expiry`, `verified_at`, `created_at`, `updated_at`, `created_by`, `updated_by`, `verification_success_email_sent`) VALUES
(2, 'admin', '$2y$10$RjegNM7sUw6CzUBmgb77eOqAmP67LewMSxSItGUb/TirFybj/CwvW', 'admin@faculty.edu', 1, 1, 0, '124288', '2025-12-13 09:23:49', NULL, '2025-12-13 08:08:16', '2025-12-13 08:08:49', NULL, NULL, 0),
(3, 'kevin', '$2y$10$bLJV44Y0gurOqN7iJfe80ubGUMgSk02Vh1eYm.MzWt8yfX1Rqug/.', 'eulagraciellarodriguez@gmail.com', 2, 1, 1, NULL, NULL, '2025-12-13 18:19:31', '2025-12-13 08:43:27', '2025-12-13 10:19:31', 2, NULL, 0),
(9, 'eula', '$2y$10$wudLKbsmocxgItBBHO3usuM0QR77U7v0ZDSAcp0UqmY0q6Lv8M.Me', 'muchachasxd1@gmail.com', 2, 1, 1, NULL, NULL, '2025-12-15 15:21:42', '2025-12-15 07:14:49', '2025-12-15 07:21:42', NULL, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE `user_types` (
  `user_type_id` int(11) NOT NULL,
  `type_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`user_type_id`, `type_name`, `description`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'Admin', NULL, '2025-12-13 08:06:43', '2025-12-13 08:06:43', NULL, NULL),
(2, 'Faculty', NULL, '2025-12-13 08:06:43', '2025-12-13 08:06:43', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_requests`
--
ALTER TABLE `admin_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `processed_by` (`processed_by`);

--
-- Indexes for table `awards_achievements`
--
ALTER TABLE `awards_achievements`
  ADD PRIMARY KEY (`award_id`),
  ADD KEY `award_type_id` (`award_type_id`),
  ADD KEY `idx_awards_faculty` (`faculty_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `award_types`
--
ALTER TABLE `award_types`
  ADD PRIMARY KEY (`award_type_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`department_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`education_id`),
  ADD KEY `faculty_id` (`faculty_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`faculty_id`),
  ADD KEY `idx_faculty_user_id` (`user_id`),
  ADD KEY `idx_faculty_department` (`department_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);



--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `idx_notifications_user` (`user_id`);

--
-- Indexes for table `research`
--
ALTER TABLE `research`
  ADD PRIMARY KEY (`research_id`),
  ADD KEY `research_type_id` (`research_type_id`),
  ADD KEY `status_id` (`status_id`),
  ADD KEY `idx_research_faculty` (`faculty_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `research_statuses`
--
ALTER TABLE `research_statuses`
  ADD PRIMARY KEY (`status_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `research_types`
--
ALTER TABLE `research_types`
  ADD PRIMARY KEY (`research_type_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `user_type_id` (`user_type_id`),
  ADD KEY `idx_users_email` (`email`),
  ADD KEY `idx_users_username` (`username`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`),
  ADD KEY `idx_verification_email_sent` (`verification_success_email_sent`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`user_type_id`),
  ADD KEY `created_by` (`created_by`),
  ADD KEY `updated_by` (`updated_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_requests`
--
ALTER TABLE `admin_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `awards_achievements`
--
ALTER TABLE `awards_achievements`
  MODIFY `award_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `award_types`
--
ALTER TABLE `award_types`
  MODIFY `award_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `education_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `research`
--
ALTER TABLE `research`
  MODIFY `research_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `research_statuses`
--
ALTER TABLE `research_statuses`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `research_types`
--
ALTER TABLE `research_types`
  MODIFY `research_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_types`
--
ALTER TABLE `user_types`
  MODIFY `user_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_requests`
--
ALTER TABLE `admin_requests`
  ADD CONSTRAINT `admin_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `admin_requests_ibfk_2` FOREIGN KEY (`processed_by`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `awards_achievements`
--
ALTER TABLE `awards_achievements`
  ADD CONSTRAINT `awards_achievements_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`),
  ADD CONSTRAINT `awards_achievements_ibfk_2` FOREIGN KEY (`award_type_id`) REFERENCES `award_types` (`award_type_id`),
  ADD CONSTRAINT `awards_achievements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `awards_achievements_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `departments_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `education`
--
ALTER TABLE `education`
  ADD CONSTRAINT `education_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`),
  ADD CONSTRAINT `education_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `education_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `faculty_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `faculty_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`department_id`),
  ADD CONSTRAINT `faculty_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `faculty_ibfk_4` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;



--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `research`
--
ALTER TABLE `research`
  ADD CONSTRAINT `research_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`faculty_id`),
  ADD CONSTRAINT `research_ibfk_2` FOREIGN KEY (`research_type_id`) REFERENCES `research_types` (`research_type_id`),
  ADD CONSTRAINT `research_ibfk_3` FOREIGN KEY (`status_id`) REFERENCES `research_statuses` (`status_id`),
  ADD CONSTRAINT `research_ibfk_4` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `research_ibfk_5` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `research_statuses`
--
ALTER TABLE `research_statuses`
  ADD CONSTRAINT `research_statuses_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `research_statuses_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `research_types`
--
ALTER TABLE `research_types`
  ADD CONSTRAINT `research_types_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `research_types_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`user_type_id`) REFERENCES `user_types` (`user_type_id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `user_types`
--
ALTER TABLE `user_types`
  ADD CONSTRAINT `user_types_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL,
  ADD CONSTRAINT `user_types_ibfk_2` FOREIGN KEY (`updated_by`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
