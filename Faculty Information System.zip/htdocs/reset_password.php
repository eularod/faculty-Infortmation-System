<?php
// reset_password.php
session_start();
require_once 'config/Database.php';

$database = \Config\Database::getInstance();
$pdo = $database->getConnection();

$token = $_GET['token'] ?? '';
$message = '';
$status = '';
$valid_token = false;
$user_id = null;

// Verify token
if ($token) {
    try {
        $stmt = $pdo->prepare("
            SELECT user_id, username, verification_token_expiry 
            FROM users 
            WHERE verification_token = ?
        ");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if ($user) {
            if (strtotime($user['verification_token_expiry']) < time()) {
                $message = 'Reset link has expired. Please request a new one.';
                $status = 'error';
            } else {
                $valid_token = true;
                $user_id = $user['user_id'];
            }
        } else {
            $message = 'Invalid or already used reset link.';
            $status = 'error';
        }
    } catch (PDOException $e) {
        $message = 'An error occurred. Please try again.';
        $status = 'error';
    }
}

// Handle password reset
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reset_password'])) {
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $user_id = $_POST['user_id'];
    $token = $_POST['token'];
    
    if ($password !== $confirm_password) {
        $message = 'Passwords do not match.';
        $status = 'error';
        $valid_token = true; // Keep form visible
    } elseif (strlen($password) < 8) {
        $message = 'Password must be at least 8 characters long.';
        $status = 'error';
        $valid_token = true;
    } else {
        try {
            // Verify token again
            $verify_stmt = $pdo->prepare("
                SELECT user_id FROM users 
                WHERE user_id = ? AND verification_token = ? 
                AND verification_token_expiry > NOW()
            ");
            $verify_stmt->execute([$user_id, $token]);
            
            if ($verify_stmt->fetch()) {
                // Hash password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                // Update password and clear token
                $update_stmt = $pdo->prepare("
                    UPDATE users 
                    SET password = ?,
                        verification_token = NULL,
                        verification_token_expiry = NULL,
                        updated_at = NOW()
                    WHERE user_id = ?
                ");
                $update_stmt->execute([$hashed_password, $user_id]);
                
                // Create notification
                $notif_stmt = $pdo->prepare("
                    INSERT INTO notifications (user_id, title, message, type, created_at) 
                    VALUES (?, 'Password Changed', 'Your password has been successfully changed.', 'info', NOW())
                ");
                $notif_stmt->execute([$user_id]);
                
                $message = 'Password reset successfully! You can now login with your new password.';
                $status = 'success';
                $valid_token = false;
            } else {
                $message = 'Invalid or expired reset link.';
                $status = 'error';
            }
        } catch (PDOException $e) {
            $message = 'An error occurred. Please try again.';
            $status = 'error';
            error_log("Password Update Error: " . $e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="<?php echo asset('css/layout.css'); ?>">
    <link rel="stylesheet" href="<?php echo asset('css/components.css'); ?>">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #990000 0%, #7a0000 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .reset-container {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
            max-width: 450px;
            width: 100%;
        }
        
        .reset-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .reset-icon {
            width: 70px;
            height: 70px;
            background: #990000;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 35px;
            color: white;
        }
        
        h1 {
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        .subtitle {
            color: #666;
            font-size: 14px;
        }
        
        .alert {
            padding: 12px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 14px;
        }
        
        input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        input[type="password"]:focus {
            outline: none;
            border-color: #990000;
        }
        
        .password-requirements {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        
        .btn {
            width: 100%;
            padding: 12px;
            background: #990000;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background: #7a0000;
        }
        
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-link a {
            color: #990000;
            text-decoration: none;
            font-size: 14px;
        }
        
        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <div class="reset-header">
            <div class="reset-icon">🔑</div>
            <h1>Reset Password</h1>
            <?php if ($valid_token): ?>
                <p class="subtitle">Enter your new password</p>
            <?php endif; ?>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $status; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($valid_token): ?>
            <form method="POST" action="" onsubmit="return validateForm()">
                <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                
                <div class="form-group">
                    <label for="password">New Password</label>
                    <input type="password" id="password" name="password" required minlength="8">
                    <div class="password-requirements">
                        Must be at least 8 characters long
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                </div>
                
                <button type="submit" name="reset_password" class="btn">Reset Password</button>
            </form>
        <?php else: ?>
            <div class="back-link">
                <a href="login.php">← Back to Login</a>
            </div>
        <?php endif; ?>
        
        <?php if ($status === 'success'): ?>
            <div class="back-link">
                <a href="login.php">← Go to Login</a>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        function validateForm() {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return false;
            }
            
            if (password.length < 6) {
                alert('Password must be at least 6 characters long!');
                return false;
            }
            
            return true;
        }
    </script>
</body>
</html>