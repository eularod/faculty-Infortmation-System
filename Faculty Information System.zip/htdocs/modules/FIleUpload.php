<?php
/**
 * File Upload Module
 * Handles file uploads with validation and security
 */

namespace Modules;

class FileUpload {
    private $uploadDir = 'uploads/photos/';
    private $maxSize = 5242880; // 5MB
    private $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    
    /**
     * Handle image upload
     */
    public function uploadImage($file, $oldPath = null) {
        $errors = Validator::file($file, $this->maxSize, $this->allowedTypes);
        if (!empty($errors)) {
            return ['success' => false, 'errors' => $errors];
        }
        
        if ($file['error'] === UPLOAD_ERR_NO_FILE) {
            return ['success' => true, 'path' => $oldPath];
        }
        
        if (!file_exists($this->uploadDir)) {
            if (!mkdir($this->uploadDir, 0755, true)) {
                return ['success' => false, 'errors' => ['Failed to create upload directory.']];
            }
        }
        
        if ($oldPath && file_exists($oldPath) && is_file($oldPath)) {
            @unlink($oldPath);
        }
        
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $newFileName = uniqid('faculty_', true) . '.' . $fileExtension;
        $targetPath = $this->uploadDir . $newFileName;
        
        if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
            return ['success' => false, 'errors' => ['Failed to save uploaded file.']];
        }
        
        chmod($targetPath, 0644);
        return ['success' => true, 'path' => $targetPath];
    }
    
    /**
     * Delete uploaded file
     */
    public function deleteFile($filePath) {
        if ($filePath && file_exists($filePath) && is_file($filePath)) {
            return @unlink($filePath);
        }
        return false;
    }
    
    /**
     * Set upload directory
     */
    public function setUploadDir($dir) {
        $this->uploadDir = rtrim($dir, '/') . '/';
    }
    
    /**
     * Set max file size
     */
    public function setMaxSize($size) {
        $this->maxSize = filter_var($size, FILTER_VALIDATE_INT);
    }
    
    /**
     * Set allowed file types
     */
    public function setAllowedTypes($types) {
        if (is_array($types)) {
            $this->allowedTypes = $types;
        }
    }
}