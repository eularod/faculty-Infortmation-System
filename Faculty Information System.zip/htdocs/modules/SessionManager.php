<?php
/**
 * Session Manager Module
 * Handles all session-related operations including security and timeout
 */

namespace Modules;

class SessionManager {
    private static $instance = null;
    private const SESSION_TIMEOUT = 1800; // 30 minutes
    
    private function __construct() {
        $this->initializeSession();
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Initialize secure session
     */
    private function initializeSession() {
        if (session_status() === PHP_SESSION_NONE) {
            ini_set('session.cookie_httponly', 1);
            ini_set('session.use_only_cookies', 1);
            ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS
            session_start();
        }
        
        $this->checkSessionTimeout();
    }
    
    /**
     * Check and handle session timeout
     */
    private function checkSessionTimeout() {
        if (isset($_SESSION['last_activity'])) {
            if ((time() - $_SESSION['last_activity']) > self::SESSION_TIMEOUT) {
                $this->destroy();
                header("Location: login.php?timeout=1");
                exit();
            }
        }
        $_SESSION['last_activity'] = time();
    }
    
    /**
     * Set session variable
     */
    public function set($key, $value) {
        $_SESSION[$key] = $value;
    }
    
    /**
     * Get session variable
     */
    public function get($key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }
    
    /**
     * Check if session variable exists
     */
    public function has($key) {
        return isset($_SESSION[$key]);
    }
    
    /**
     * Remove session variable
     */
    public function remove($key) {
        unset($_SESSION[$key]);
    }
    
    /**
     * Destroy session
     */
    public function destroy() {
        session_unset();
        session_destroy();
    }
    
    /**
     * Check if user is logged in
     */
    public function isLoggedIn() {
        return $this->has('user_id') && !empty($this->get('user_id'));
    }
    
    /**
     * Get current user ID
     */
    public function getUserId() {
        return $this->get('user_id');
    }
    
    /**
     * Get current user type
     */
    public function getUserType() {
        return $this->get('user_type');
    }
    
    /**
     * Get current faculty ID
     */
    public function getFacultyId() {
        return $this->get('faculty_id');
    }
    
    /**
     * Set flash message
     */
    public function setFlash($type, $message) {
        $_SESSION['flash'][$type] = $message;
    }
    
    /**
     * Get and clear flash message
     */
    public function getFlash($type) {
        if (isset($_SESSION['flash'][$type])) {
            $message = $_SESSION['flash'][$type];
            unset($_SESSION['flash'][$type]);
            return $message;
        }
        return null;
    }
}