<?php
/**
 * Validator Module
 * Handles all input validation and sanitization
 */

namespace Modules;

class Validator {
    /**
     * Sanitize user input
     */
    public static function sanitize($data) {
        if (is_null($data)) {
            return null;
        }
        return htmlspecialchars(trim(stripslashes($data)), ENT_QUOTES, 'UTF-8');
    }
    
    /**
     * Validate required field
     */
    public static function required($value, $fieldName) {
        return (is_null($value) || trim($value) === '') ? "$fieldName is required." : null;
    }
    
    /**
     * Validate email format
     */
    public static function email($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) ? null : "Invalid email format.";
    }
    
    /**
     * Validate year value
     */
    public static function year($year) {
        if (empty($year)) {
            return null;
        }
        
        $currentYear = (int)date('Y');
        $year = filter_var($year, FILTER_VALIDATE_INT);
        
        if ($year === false || $year < 1950 || $year > ($currentYear + 10)) {
            return "Year must be between 1950 and " . ($currentYear + 10) . ".";
        }
        return null;
    }
    
    /**
     * Validate phone number format
     */
    public static function phone($phone) {
        if (empty(trim($phone))) {
            return null;
        }
        
        if (!preg_match('/^[\d\s\-\+\(\)]+$/', $phone)) {
            return "Invalid phone number format. Use only numbers, spaces, hyphens, plus sign, and parentheses.";
        }
        
        return strlen($phone) > 20 ? "Phone number is too long (maximum 20 characters)." : null;
    }
    
    /**
     * Validate string length
     */
    public static function length($value, $min, $max, $fieldName) {
        $length = strlen($value);
        return ($length < $min || $length > $max) 
            ? "$fieldName must be between $min and $max characters." 
            : null;
    }
    
    /**
     * Validate numeric value
     */
    public static function numeric($value, $fieldName) {
        return is_numeric($value) ? null : "$fieldName must be a number.";
    }
    
    /**
     * Validate minimum value
     */
    public static function min($value, $min, $fieldName) {
        return ($value < $min) ? "$fieldName must be at least $min." : null;
    }
    
    /**
     * Validate maximum value
     */
    public static function max($value, $max, $fieldName) {
        return ($value > $max) ? "$fieldName must not exceed $max." : null;
    }
    
    /**
     * Validate password strength
     */
    public static function password($password, $minLength = 6) {
        return (strlen($password) < $minLength) 
            ? "Password must be at least $minLength characters long." 
            : null;
    }
    
    /**
     * Validate file upload
     */
    public static function file($file, $maxSize = 5242880, $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp']) {
        if (!isset($file['error'], $file['size'], $file['tmp_name'])) {
            return ["Invalid file upload structure."];
        }
        
        if ($file['error'] === UPLOAD_ERR_NO_FILE) {
            return [];
        }
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $uploadErrors = [
                UPLOAD_ERR_INI_SIZE => 'File exceeds server maximum upload size.',
                UPLOAD_ERR_FORM_SIZE => 'File exceeds form maximum upload size.',
                UPLOAD_ERR_PARTIAL => 'File was only partially uploaded.',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder.',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload.'
            ];
            return [$uploadErrors[$file['error']] ?? "Unknown upload error code: {$file['error']}"];
        }
        
        $errors = [];
        
        if ($file['size'] > $maxSize) {
            $maxSizeMB = $maxSize / (1024 * 1024);
            $errors[] = "File size must not exceed {$maxSizeMB}MB.";
        }
        
        if (file_exists($file['tmp_name'])) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            
            if (!$mimeType || !in_array($mimeType, $allowedTypes)) {
                $errors[] = "Invalid file type. Only JPEG, PNG, GIF, and WebP images are allowed.";
            }
        }
        
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($fileExtension, $allowedExtensions)) {
            $errors[] = "Invalid file extension.";
        }
        
        return $errors;
    }
}