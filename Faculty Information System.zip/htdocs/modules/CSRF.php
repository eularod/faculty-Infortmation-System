<?php
/**
 * CSRF Protection Module
 * Handles CSRF token generation and validation
 */

namespace Modules;

class CSRF {
    private $session;
    private const TOKEN_NAME = 'csrf_token';
    
    public function __construct() {
        $this->session = SessionManager::getInstance();
    }
    
    /**
     * Generate CSRF token
     */
    public function generateToken() {
        if (!$this->session->has(self::TOKEN_NAME)) {
            $token = bin2hex(random_bytes(32));
            $this->session->set(self::TOKEN_NAME, $token);
        }
        return $this->session->get(self::TOKEN_NAME);
    }
    
    /**
     * Validate CSRF token
     */
    public function validateToken($token) {
        if (!$this->session->has(self::TOKEN_NAME) || empty($token)) {
            return false;
        }
        return hash_equals($this->session->get(self::TOKEN_NAME), $token);
    }
    
    /**
     * Get token field HTML
     */
    public function getTokenField() {
        $token = htmlspecialchars($this->generateToken(), ENT_QUOTES, 'UTF-8');
        return '<input type="hidden" name="' . self::TOKEN_NAME . '" value="' . $token . '">';
    }
    
    /**
     * Refresh token (generate new one)
     */
    public function refreshToken() {
        $token = bin2hex(random_bytes(32));
        $this->session->set(self::TOKEN_NAME, $token);
        return $token;
    }
}