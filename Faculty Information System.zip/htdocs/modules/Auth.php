<?php

namespace Modules;

/**
 * Authentication Module
 * Handles user authentication and authorization
 */

use Config\Database;
use PDO;

class Auth {
    private $db;
    private $session;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->session = SessionManager::getInstance();
    }
    
    /**
     * Check if user is logged in
     */
    public function isLoggedIn() {
        return $this->session->isLoggedIn();
    }
    
    /**
     * Require user to be logged in
     */
    public function requireLogin() {
        if (!$this->isLoggedIn()) {
            $redirect = filter_var($_SERVER['REQUEST_URI'] ?? '/', FILTER_SANITIZE_URL);
            $this->session->set('redirect_after_login', $redirect);
            header("Location: login.php");
            exit();
        }
    }
    
    /**
     * Check if user is admin
     */
    public function isAdmin() {
        $userType = $this->session->getUserType();
        if (!$userType) {
            return false;
        }
        
        $userType = strtolower(trim($userType));
        return in_array($userType, ['admin', 'administrator']);
    }
    
    /**
     * Check if user is faculty
     */
    public function isFaculty() {
        $userType = $this->session->getUserType();
        return $userType && strtolower(trim($userType)) === 'faculty';
    }
    
    /**
     * Require admin privileges
     */
    public function requireAdmin() {
        $this->requireLogin();
        
        if (!$this->isAdmin()) {
            $this->session->setFlash('error', "You don't have permission to access this page.");
            header("Location: dashboard.php");
            exit();
        }
    }
    
    /**
     * Get faculty ID for current user
     */
    public function getCurrentFacultyId() {
        if (!$this->isLoggedIn()) {
            return null;
        }
        
        if ($this->session->has('faculty_id')) {
            return $this->session->getFacultyId();
        }
        
        $facultyId = $this->getUserFacultyId($this->session->getUserId());
        
        if ($facultyId) {
            $this->session->set('faculty_id', $facultyId);
        }
        
        return $facultyId;
    }
    
    /**
     * Get faculty ID for a specific user
     */
    public function getUserFacultyId($userId) {
        $userId = filter_var($userId, FILTER_VALIDATE_INT);
        if ($userId === false) {
            return null;
        }
        
        try {
            $stmt = $this->db->prepare("SELECT faculty_id FROM faculty WHERE user_id = ? LIMIT 1");
            $stmt->execute([$userId]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result ? (int)$result['faculty_id'] : null;
        } catch (\PDOException $e) {
            error_log("Error getting faculty ID: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Check if user can edit faculty profile
     */
    public function canEditFaculty($facultyId) {
        if ($this->isAdmin()) {
            return true;
        }
        
        if (!$this->isLoggedIn()) {
            return false;
        }
        
        $userFacultyId = $this->getCurrentFacultyId();
        return $userFacultyId && (int)$userFacultyId === (int)$facultyId;
    }
    
    /**
     * Check if user can delete faculty profile
     */
    public function canDeleteFaculty($facultyId) {
        return $this->isAdmin();
    }
    
    /**
     * Login user
     */
    public function login($username, $password) {
        $username = filter_var($username, FILTER_SANITIZE_FULL_SPECIAL_CHARS);
        
        try {
            $stmt = $this->db->prepare("
                SELECT u.*, ut.type_name as user_type 
                FROM users u
                INNER JOIN user_types ut ON u.user_type_id = ut.user_type_id
                WHERE u.username = ?
            ");
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$user || !password_verify($password, $user['password'])) {
                return false;
            }
            
            $this->session->set('user_id', $user['user_id']);
            $this->session->set('username', $user['username']);
            $this->session->set('user_type', $user['user_type']);
            
            if (strtolower(trim($user['user_type'])) === 'faculty') {
                $facultyId = $this->getUserFacultyId($user['user_id']);
                if ($facultyId) {
                    $this->session->set('faculty_id', $facultyId);
                }
            }
            
            return true;
        } catch (\PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Logout user
     */
    public function logout() {
        $this->session->destroy();
        header("Location: login.php");
        exit();
    }
}