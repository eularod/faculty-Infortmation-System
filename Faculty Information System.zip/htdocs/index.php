<?php
/**
 * Faculty Information System - Home Page
 */
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is already logged in and redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: public/dashboard.php");
    exit();
}

// Try to include init.php, but don't fail if it's not available
if (!defined('BASE_PATH')) {
    if (file_exists(__DIR__ . '/init.php')) {
        require_once __DIR__ . '/init.php';
    }
}

// Helper function for assets if not defined
if (!function_exists('asset')) {
    function asset($path) {
        return $path;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Information System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .home-container {
            max-width: 1200px;
            width: 100%;
        }

        header {
            text-align: center;
            margin-bottom: 50px;
            color: #333;
        }

        header h1 {
            font-size: 42px;
            margin-bottom: 15px;
            color: #2c3e50;
        }

        header p {
            font-size: 18px;
            color: #7f8c8d;
        }

        .welcome-section {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 60px 40px;
            text-align: center;
            max-width: 500px;
            margin: 0 auto;
        }

        .welcome-section h2 {
            color: #e74c3c;
            font-size: 32px;
            margin-bottom: 20px;
        }

        .welcome-section p {
            color: #666;
            font-size: 16px;
            margin-bottom: 30px;
        }

        .login-button {
            display: inline-block;
            padding: 15px 50px;
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 18px;
            font-weight: 600;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 15px rgba(231, 76, 60, 0.3);
        }

        .login-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(231, 76, 60, 0.4);
        }

        .login-button:active {
            transform: translateY(-1px);
        }

        footer {
            text-align: center;
            margin-top: 40px;
            color: #7f8c8d;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="home-container">
        <header>
            <h1>Welcome to Faculty Information System</h1>
            <p>Manage faculty information efficiently and securely.</p>
        </header>
        <main>
            <div class="welcome-section">
                <h2>Get Started</h2>
                <p>Please log in to access the system.</p>
                <a href="public/login.php" class="login-button">Login</a>
            </div>
        </main>
        <footer>
            <p>&copy; 2024 Faculty Information System. All rights reserved.</p>
        </footer>
    </div>
</body>
</html>