<?php
/**
 * Initialization File
 * Sets up autoloading, error handling, and initializes core modules
 */

// Define base path
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__FILE__));
}

// Load environment configuration (must be first!)
$configFile = BASE_PATH . '/config/config.php';
if (file_exists($configFile)) {
    require_once $configFile;
} else {
    // Fallback: Define essential constants if config.php is missing
    error_log("WARNING: config/config.php not found. Using fallback configuration.");
    
    // Basic environment detection
    $hostname = $_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? 'localhost';
    $isLocalhost = strpos($hostname, 'localhost') !== false || strpos($hostname, '127.') === 0;
    
    define('APP_ENV', $isLocalhost ? 'development' : 'production');
    define('IS_LOCALHOST', $isLocalhost);
    define('BASE_URL', ($isLocalhost ? 'http://localhost/faculty' : 'http://example.com'));
    
    // Database defaults
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'faculty_info_system');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    
    // Email defaults
    define('EMAIL_HOST', 'smtp.gmail.com');
    define('EMAIL_PORT', 587);
    define('EMAIL_ENCRYPTION', 'tls');
    define('EMAIL_USERNAME', 'test@gmail.com');
    define('EMAIL_PASSWORD', '');
    define('EMAIL_FROM_ADDRESS', 'noreply@facultysystem.com');
    define('EMAIL_FROM_NAME', 'Faculty Information System');
    define('EMAIL_REPLY_TO', 'support@facultysystem.com');
    
    // Other constants
    define('DEBUG_MODE', IS_LOCALHOST);
}

// Error reporting configuration
$isProduction = defined('APP_ENV') && APP_ENV === 'production';
error_reporting(E_ALL);
ini_set('display_errors', $isProduction ? '0' : '1');
ini_set('log_errors', '1');

$logDir = BASE_PATH . '/logs';
if (!is_dir($logDir)) {
    @mkdir($logDir, 0755, true);
}
ini_set('error_log', $logDir . '/error.log');

// Autoloader with namespace support
spl_autoload_register(function ($class) {
    // Convert namespace to file path
    $classPath = str_replace('\\', DIRECTORY_SEPARATOR, $class);
    
    // Try different base directories
    $baseDirs = [
        BASE_PATH . '/',
        BASE_PATH . '/app/',
        BASE_PATH . '/modules/',
        BASE_PATH . '/models/',
        BASE_PATH . '/controllers/',
        BASE_PATH . '/classes/',
        BASE_PATH . '/helpers/'
    ];
    
    foreach ($baseDirs as $baseDir) {
        // Try original case
        $file = $baseDir . $classPath . '.php';
        if (file_exists($file)) {
            require_once $file;
            return true;
        }
        
        // Try lowercase
        $file = $baseDir . strtolower($classPath) . '.php';
        if (file_exists($file)) {
            require_once $file;
            return true;
        }
    }
    
    return false;
});

// Include backward compatibility functions
$functionsFile = BASE_PATH . '/helpers/functions.php';
if (file_exists($functionsFile)) {
    require_once $functionsFile;
}

// Initialize session
use Modules\SessionManager;
SessionManager::getInstance();

// Set timezone
date_default_timezone_set('Asia/Manila');

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Get Auth instance
 * @return \Modules\Auth
 */
function auth() {
    static $auth = null;
    if ($auth === null) {
        $auth = new \Modules\Auth();
    }
    return $auth;
}

/**
 * Get Session instance
 * @return \Modules\SessionManager
 */
function session() {
    return SessionManager::getInstance();
}

/**
 * Get CSRF instance
 * @return \Modules\CSRF
 */
function csrf() {
    static $csrf = null;
    if ($csrf === null) {
        $csrf = new \Modules\CSRF();
    }
    return $csrf;
}

/**
 * Redirect to URL
 * @param string $url URL to redirect to
 * @param int $statusCode HTTP status code
 * @return void
 */
function redirect($url, $statusCode = 302) {
    // For relative URLs in public folder, use direct header redirect
    // This works across all hosting environments
    header("Location: $url", true, $statusCode);
    exit();
}

/**
 * Get old input value
 * @param string $key Input key
 * @param mixed $default Default value
 * @return mixed Input value or default
 */
function old($key, $default = '') {
    return isset($_POST[$key]) ? htmlspecialchars($_POST[$key], ENT_QUOTES, 'UTF-8') : $default;
}

/**
 * Get asset path
 * @param string $path Asset path (e.g., 'css/login.css', 'js/script.js')
 * @return string Full asset URL
 */
function asset($path) {
    $path = ltrim($path, '/');
    
    // For files in public folder, use relative path (works on all hosts)
    // Check if we're running from public folder by looking at script filename
    $scriptFile = $_SERVER['SCRIPT_FILENAME'] ?? '';
    
    // If public is in the path, we're in the public folder
    if (preg_match('#[/\\\\]public[/\\\\]#i', $scriptFile)) {
        return '../' . $path;
    }
    
    // Fallback: use BASE_URL if available
    if (defined('BASE_URL') && !empty(BASE_URL)) {
        return BASE_URL . '/' . $path;
    }
    
    // Last resort: assume structure
    return '/' . $path;
}

/**
 * Escape HTML output
 * @param string $text Text to escape
 * @return string Escaped text
 */
function e($text) {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

/**
 * Check if current environment is production
 * @return bool
 */
function isProduction() {
    return defined('APP_ENV') && APP_ENV === 'production';
}

/**
 * Check if current environment is development
 * @return bool
 */
function isDevelopment() {
    return !isProduction();
}