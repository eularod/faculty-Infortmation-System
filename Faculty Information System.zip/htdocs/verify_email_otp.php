<?php
/**
 * Email Verification OTP Page - FIXED VERSION
 * Fix: Form submission now properly includes verify_otp parameter
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once __DIR__ . '/config/Database.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/vendor/autoload.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: public/login.php");
    exit();
}

// Initialize database
try {
    $database = \Config\Database::getInstance();
    $pdo = $database->getConnection();
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

$error = '';
$success = '';

// Fetch user information
try {
    $stmt = $pdo->prepare("SELECT email_verified, email, username FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        session_destroy();
        header("Location: public/login.php");
        exit();
    }
    
    // Redirect if already verified
    if ($user['email_verified'] == 1) {
        $_SESSION['success'] = "Your email is already verified!";
        header("Location: public/dashboard.php");
        exit();
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// Function to send OTP email
function sendVerificationOTP($email, $username, $otp) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'muchachasxd1@gmail.com';
        $mail->Password   = 'ceqazkeqqzgmelkv';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        $mail->setFrom('muchachasxd1@gmail.com', 'Faculty Information System');
        $mail->addAddress($email, $username);
        
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification Code';
        
        $mail->Body = "
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: linear-gradient(135deg, #990000 0%, #7a0000 100%); 
                             color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .otp-box { background: white; padding: 20px; margin: 20px 0; 
                              text-align: center; border-radius: 8px; border: 2px dashed #990000; }
                    .otp-code { font-size: 32px; font-weight: bold; color: #990000; 
                               letter-spacing: 8px; margin: 10px 0; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h1>🔐 Email Verification</h1>
                    </div>
                    <div class='content'>
                        <p>Hello <strong>{$username}</strong>,</p>
                        <p>Your email verification code is:</p>
                        <div class='otp-box'>
                            <div class='otp-code'>{$otp}</div>
                        </div>
                        <p><strong>This code will expire in 15 minutes.</strong></p>
                    </div>
                </div>
            </body>
            </html>
        ";
        
        $mail->send();
        error_log("✓ OTP sent to: " . $email);
        return true;
    } catch (Exception $e) {
        error_log("✗ Mail Error: " . $mail->ErrorInfo);
        return false;
    }
}

// HANDLE OTP VERIFICATION - FIXED: Check for both POST method AND otp field
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp']) && !isset($_POST['resend_otp'])) {
    $entered_otp = trim($_POST['otp']);
    
    // Log for debugging
    error_log("=== VERIFICATION ATTEMPT ===");
    error_log("User ID: " . $_SESSION['user_id']);
    error_log("Entered OTP: " . $entered_otp);
    error_log("POST data: " . print_r($_POST, true));
    
    if (empty($entered_otp)) {
        $error = "Please enter the verification code.";
        error_log("Error: Empty OTP");
    } elseif (strlen($entered_otp) !== 6 || !ctype_digit($entered_otp)) {
        $error = "Verification code must be 6 digits.";
        error_log("Error: Invalid OTP format - Length: " . strlen($entered_otp));
    } else {
        try {
            $stmt = $pdo->prepare("SELECT verification_token, verification_token_expiry FROM users WHERE user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            error_log("Database OTP: " . ($user_data['verification_token'] ?? 'NULL'));
            error_log("Expiry: " . ($user_data['verification_token_expiry'] ?? 'NULL'));
            
            if (!$user_data || empty($user_data['verification_token'])) {
                $error = "No verification code found. Please request a new one.";
                error_log("Error: No token in database");
            } elseif (strtotime($user_data['verification_token_expiry']) < time()) {
                $error = "Verification code has expired. Please request a new one.";
                error_log("Error: Token expired");
                $pdo->prepare("UPDATE users SET verification_token = NULL, verification_token_expiry = NULL WHERE user_id = ?")->execute([$_SESSION['user_id']]);
            } elseif ($entered_otp !== $user_data['verification_token']) {
                $error = "Invalid verification code. Please try again.";
                error_log("Error: OTP mismatch - Expected: {$user_data['verification_token']}, Got: {$entered_otp}");
            } else {
                // SUCCESS - Verify email
                error_log("✓ OTP MATCH! Verifying email...");
                
                $update_stmt = $pdo->prepare("
                    UPDATE users 
                    SET email_verified = 1,
                        verified_at = NOW(),
                        verification_token = NULL,
                        verification_token_expiry = NULL,
                        updated_at = NOW()
                    WHERE user_id = ?
                ");
                
                if ($update_stmt->execute([$_SESSION['user_id']])) {
                    $rows_affected = $update_stmt->rowCount();
                    error_log("✓ Database updated. Rows affected: " . $rows_affected);
                    
                    $_SESSION['email_verified'] = true;
                    unset($_SESSION['otp_sent']);
                    
                    // Success page with redirect
                    ?>
                    <!DOCTYPE html>
                    <html>
                    <head>
                        <meta charset="UTF-8">
                        <meta http-equiv="refresh" content="2;url=public/dashboard.php">
                        <style>
                            body {
                                font-family: Arial, sans-serif;
                                display: flex;
                                justify-content: center;
                                align-items: center;
                                min-height: 100vh;
                                margin: 0;
                                background: linear-gradient(135deg, #990000 0%, #7a0000 100%);
                            }
                            .success-box {
                                background: white;
                                padding: 40px;
                                border-radius: 20px;
                                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                                text-align: center;
                                max-width: 500px;
                                animation: slideUp 0.5s ease-out;
                            }
                            @keyframes slideUp {
                                from { opacity: 0; transform: translateY(30px); }
                                to { opacity: 1; transform: translateY(0); }
                            }
                            .success-icon {
                                font-size: 64px;
                                color: #28a745;
                                margin-bottom: 20px;
                            }
                            h2 { color: #28a745; margin: 0 0 10px 0; }
                            p { color: #666; margin: 10px 0; }
                            .spinner {
                                border: 3px solid #f3f3f3;
                                border-top: 3px solid #990000;
                                border-radius: 50%;
                                width: 30px;
                                height: 30px;
                                animation: spin 1s linear infinite;
                                margin: 20px auto 0;
                            }
                            @keyframes spin {
                                0% { transform: rotate(0deg); }
                                100% { transform: rotate(360deg); }
                            }
                        </style>
                    </head>
                    <body>
                        <div class="success-box">
                            <div class="success-icon">✓</div>
                            <h2>Email Verified Successfully!</h2>
                            <p>Welcome to the Faculty Information System.</p>
                            <p style="font-size: 14px; color: #999;">Redirecting to dashboard...</p>
                            <div class="spinner"></div>
                        </div>
                    </body>
                    </html>
                    <?php
                    exit();
                } else {
                    $error = "Failed to update verification status.";
                    error_log("✗ Database update failed");
                }
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
            error_log("✗ Database error: " . $e->getMessage());
        }
    }
}

// HANDLE RESEND REQUEST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resend_otp'])) {
    error_log("=== RESEND REQUEST ===");
    
    try {
        $otp = sprintf("%06d", mt_rand(0, 999999));
        $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        
        error_log("Resending OTP for user {$_SESSION['user_id']}: {$otp}");
        
        $update_stmt = $pdo->prepare("
            UPDATE users 
            SET verification_token = ?,
                verification_token_expiry = ?,
                updated_at = NOW()
            WHERE user_id = ?
        ");
        
        if ($update_stmt->execute([$otp, $expiry, $_SESSION['user_id']])) {
            if (sendVerificationOTP($user['email'], $user['username'], $otp)) {
                $success = "New verification code sent successfully!";
                error_log("✓ New OTP sent successfully");
            } else {
                $error = "Failed to send verification email.";
                error_log("✗ Failed to send email");
            }
        }
    } catch (PDOException $e) {
        $error = "Failed to resend code: " . $e->getMessage();
        error_log("✗ Resend error: " . $e->getMessage());
    }
}

// SEND INITIAL OTP
if (!isset($_SESSION['otp_sent']) && empty($error)) {
    try {
        $otp = sprintf("%06d", mt_rand(0, 999999));
        $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        
        error_log("=== INITIAL OTP ===");
        error_log("Generated OTP for user {$_SESSION['user_id']}: {$otp}");
        
        $update_stmt = $pdo->prepare("
            UPDATE users 
            SET verification_token = ?,
                verification_token_expiry = ?,
                updated_at = NOW()
            WHERE user_id = ?
        ");
        
        if ($update_stmt->execute([$otp, $expiry, $_SESSION['user_id']])) {
            error_log("✓ OTP saved to database");
            if (sendVerificationOTP($user['email'], $user['username'], $otp)) {
                $_SESSION['otp_sent'] = true;
                $success = "Verification code sent to " . $user['email'];
                error_log("✓ Initial OTP sent successfully");
            } else {
                $error = "Failed to send verification email.";
                error_log("✗ Failed to send initial email");
            }
        }
    } catch (PDOException $e) {
        $error = "Database error: " . $e->getMessage();
        error_log("✗ Initial OTP error: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Email - Faculty Information System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #990000 0%, #7a0000 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .verification-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 500px;
            width: 100%;
            overflow: hidden;
            animation: slideUp 0.5s ease-out;
        }
        
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .header {
            background: linear-gradient(135deg, #990000 0%, #7a0000 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        
        .header i {
            font-size: 60px;
            margin-bottom: 15px;
        }
        
        .header h1 {
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .content {
            padding: 40px 30px;
        }
        
        .user-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        
        .user-info .email {
            font-size: 16px;
            color: #990000;
            font-weight: 600;
            margin-top: 10px;
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        
        .otp-input-group {
            display: flex;
            gap: 10px;
            justify-content: center;
            margin: 30px 0;
        }
        
        .otp-input {
            width: 60px;
            height: 70px;
            font-size: 32px;
            text-align: center;
            border: 2px solid #ddd;
            border-radius: 10px;
            font-weight: bold;
            color: #990000;
            transition: all 0.3s;
        }
        
        .otp-input:focus {
            outline: none;
            border-color: #990000;
            box-shadow: 0 0 0 3px rgba(153, 0, 0, 0.1);
            transform: scale(1.05);
        }
        
        .btn {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #990000 0%, #7a0000 100%);
            color: white;
        }
        
        .btn-primary:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(153, 0, 0, 0.3);
        }
        
        .btn-primary:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .btn-secondary {
            background: #f8f9fa;
            color: #990000;
            margin-top: 10px;
            border: 2px solid #990000;
        }
        
        .btn-secondary:hover:not(:disabled) {
            background: #e9ecef;
        }
        
        .btn-secondary:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .resend-info {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        
        .timer {
            color: #dc3545;
            font-weight: 600;
        }
        
        .back-link {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-link a {
            color: #990000;
            text-decoration: none;
            font-size: 14px;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255,255,255,0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .debug-info {
            margin-top: 20px;
            padding: 10px;
            background: #fff3cd;
            border-radius: 5px;
            font-size: 12px;
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="verification-container">
        <div class="header">
            <i class="fas fa-envelope-open-text"></i>
            <h1>Verify Your Email</h1>
            <p>Enter the 6-digit code sent to your email</p>
        </div>
        
        <div class="content">
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo htmlspecialchars($success); ?></span>
                </div>
            <?php endif; ?>
            
            <div class="user-info">
                <i class="fas fa-user-circle" style="font-size: 24px; color: #990000;"></i>
                <div style="margin-top: 10px; color: #666;">
                    <?php echo htmlspecialchars($user['username']); ?>
                </div>
                <div class="email">
                    <?php echo htmlspecialchars($user['email']); ?>
                </div>
            </div>
            
            <form method="POST" id="otpForm">
                <div class="otp-input-group">
                    <input type="text" class="otp-input" maxlength="1" id="otp1" autocomplete="off" inputmode="numeric" pattern="[0-9]">
                    <input type="text" class="otp-input" maxlength="1" id="otp2" autocomplete="off" inputmode="numeric" pattern="[0-9]">
                    <input type="text" class="otp-input" maxlength="1" id="otp3" autocomplete="off" inputmode="numeric" pattern="[0-9]">
                    <input type="text" class="otp-input" maxlength="1" id="otp4" autocomplete="off" inputmode="numeric" pattern="[0-9]">
                    <input type="text" class="otp-input" maxlength="1" id="otp5" autocomplete="off" inputmode="numeric" pattern="[0-9]">
                    <input type="text" class="otp-input" maxlength="1" id="otp6" autocomplete="off" inputmode="numeric" pattern="[0-9]">
                </div>
                
                <!-- CRITICAL: Hidden input that stores the complete OTP -->
                <input type="hidden" name="otp" id="otpValue" value="">
                
                <button type="submit" class="btn btn-primary" id="verifyBtn" disabled>
                    <i class="fas fa-check-circle"></i>
                    <span id="verifyText">Verify Email</span>
                </button>
            </form>
            
            <form method="POST" id="resendForm">
                <button type="submit" name="resend_otp" value="1" class="btn btn-secondary" id="resendBtn" disabled>
                    <i class="fas fa-paper-plane"></i>
                    <span id="resendText">Resend Code</span>
                </button>
            </form>
            
            <div class="resend-info">
                <span id="timerText">You can resend in <span class="timer" id="timer">60</span> seconds</span>
            </div>
            
            <div class="back-link">
                <a href="public/dashboard.php">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
            
            <!-- Debug info (remove in production) -->
            <div class="debug-info" id="debugInfo" style="display:none;">
                OTP Value: <span id="debugOtp"></span>
            </div>
        </div>
    </div>
    
    <script>
        console.log('=== OTP Verification Script Loaded ===');
        
        const otpInputs = document.querySelectorAll('.otp-input');
        const otpValue = document.getElementById('otpValue');
        const verifyBtn = document.getElementById('verifyBtn');
        const verifyText = document.getElementById('verifyText');
        const resendBtn = document.getElementById('resendBtn');
        const resendText = document.getElementById('resendText');
        const timerSpan = document.getElementById('timer');
        const debugOtp = document.getElementById('debugOtp');
        const otpForm = document.getElementById('otpForm');
        
        let timeLeft = 60;
        let timerInterval;
        
        // Focus first input
        if (otpInputs.length > 0) {
            otpInputs[0].focus();
        }
        
        // OTP input handling with improved logic
        otpInputs.forEach((input, index) => {
            input.addEventListener('input', function(e) {
                // Only allow digits
                this.value = this.value.replace(/[^0-9]/g, '');
                
                console.log(`Input ${index + 1}: ${this.value}`);
                
                // Move to next input if digit entered
                if (this.value.length === 1 && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
                
                // Update OTP value
                updateOTPValue();
            });
            
            input.addEventListener('keydown', function(e) {
                // Backspace handling
                if (e.key === 'Backspace') {
                    if (this.value === '' && index > 0) {
                        // Move to previous input if current is empty
                        otpInputs[index - 1].focus();
                        otpInputs[index - 1].value = '';
                    } else {
                        // Clear current input
                        this.value = '';
                    }
                    updateOTPValue();
                    e.preventDefault();
                }
                
                // Arrow key navigation
                if (e.key === 'ArrowLeft' && index > 0) {
                    otpInputs[index - 1].focus();
                }
                if (e.key === 'ArrowRight' && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
            });
            
            // Paste handling
            input.addEventListener('paste', function(e) {
                e.preventDefault();
                const pastedData = e.clipboardData.getData('text').replace(/[^0-9]/g, '');
                
                console.log('Pasted data:', pastedData);
                
                if (pastedData.length === 6) {
                    otpInputs.forEach((inp, i) => {
                        inp.value = pastedData[i] || '';
                    });
                    updateOTPValue();
                    otpInputs[5].focus();
                }
            });
        });
        
        // Update hidden OTP value and button state
        function updateOTPValue() {
            const otp = Array.from(otpInputs).map(input => input.value).join('');
            otpValue.value = otp;
            
            // Update debug display
            if (debugOtp) {
                debugOtp.textContent = otp || '(empty)';
            }
            
            // Enable/disable verify button
            const isComplete = otp.length === 6;
            verifyBtn.disabled = !isComplete;
            
            console.log('OTP Updated:', otp, 'Length:', otp.length, 'Complete:', isComplete);
            
            return otp;
        }
        
        // FIXED: Form submission - Let the form submit naturally
        otpForm.addEventListener('submit', function(e) {
            const otp = updateOTPValue(); // Ensure OTP is updated
            
            console.log('=== FORM SUBMISSION ===');
            console.log('OTP Value:', otp);
            console.log('OTP Length:', otp.length);
            console.log('Hidden Input Value:', otpValue.value);
            
            if (otp.length !== 6) {
                e.preventDefault(); // Only prevent if invalid
                alert('⚠️ Please enter all 6 digits of the verification code.');
                otpInputs[0].focus();
                return false;
            }
            
            // Show loading state
            verifyText.innerHTML = '<span class="spinner"></span> Verifying...';
            verifyBtn.disabled = true;
            resendBtn.disabled = true;
            
            // Disable all inputs
            otpInputs.forEach(input => input.disabled = true);
            
            console.log('Submitting form with OTP:', otp);
            
            // Let the form submit naturally - DO NOT call e.preventDefault() or this.submit()
        });
        
        // Resend button with timer check
        document.getElementById('resendForm').addEventListener('submit', function(e) {
            if (timeLeft > 0) {
                e.preventDefault();
                alert('Please wait ' + timeLeft + ' seconds before resending.');
                return false;
            }
            
            resendBtn.disabled = true;
            resendText.innerHTML = '<span class="spinner"></span> Sending...';
            
            console.log('Resending OTP...');
        });
        
        // Timer function
        function startTimer() {
            timeLeft = 60;
            resendBtn.disabled = true;
            
            clearInterval(timerInterval);
            timerInterval = setInterval(() => {
                timeLeft--;
                timerSpan.textContent = timeLeft;
                
                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    resendBtn.disabled = false;
                    document.getElementById('timerText').innerHTML = 'Didn\'t receive the code? <strong>Click Resend</strong>';
                    console.log('Timer expired - resend enabled');
                }
            }, 1000);
        }
        
        // Start timer on page load
        startTimer();
        console.log('Timer started');
        
        // Show debug info in development (Ctrl+D to toggle)
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'd') {
                e.preventDefault();
                const debugDiv = document.getElementById('debugInfo');
                debugDiv.style.display = debugDiv.style.display === 'none' ? 'block' : 'none';
            }
        });
        
        // Log initial state
        console.log('Initial button state:', verifyBtn.disabled);
        console.log('Initial OTP value:', otpValue.value);
    </script>
</body>
</html>