<?php
namespace Controllers;

use Config\Database;
use Modules\Auth;
use Modules\SessionManager;
use PDO;

/**
 * Report Controller
 * Handles report generation and data export operations
 */
class ReportController {
    private $db;
    private $auth;
    private $session;
    
    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->auth = new Auth();
        $this->session = SessionManager::getInstance();
    }
    
    /**
     * Generate faculty list report
     * @param array $filters Filter parameters
     * @return array Report data
     */
    public function generateFacultyListReport($filters = []) {
        $sql = "SELECT 
                    f.faculty_id,
                    f.first_name,
                    f.last_name,
                    f.email,
                    f.phone,
                    COALESCE(d.department_name, 'N/A') as department_name,
                    COALESCE(f.address, 'N/A') as address,
                    COUNT(DISTINCT r.research_id) as research_count
                FROM faculty f
                LEFT JOIN departments d ON f.department_id = d.department_id
                LEFT JOIN research r ON f.faculty_id = r.faculty_id
                WHERE 1=1";
        
        $params = [];
        
        if (!empty($filters['department_id'])) {
            $sql .= " AND f.department_id = ?";
            $params[] = intval($filters['department_id']);
        }
        
        $sql .= " GROUP BY f.faculty_id ORDER BY f.last_name, f.first_name";
        
        return $this->executeQuery($sql, $params);
    }
    
    /**
     * Generate research summary report
     * @param array $filters Filter parameters
     * @return array Report data
     */
    public function generateResearchSummaryReport($filters = []) {
        $sql = "SELECT 
                    r.research_id,
                    r.research_title,
                    r.year,
                    rt.type_name,
                    rs.status_name,
                    CONCAT(f.first_name, ' ', f.last_name) as faculty_name,
                    COALESCE(d.department_name, 'N/A') as department_name,
                    COALESCE(r.description, '') as description
                FROM research r
                INNER JOIN faculty f ON r.faculty_id = f.faculty_id
                LEFT JOIN departments d ON f.department_id = d.department_id
                INNER JOIN research_types rt ON r.research_type_id = rt.research_type_id
                INNER JOIN research_statuses rs ON r.status_id = rs.status_id
                WHERE 1=1";
        
        list($sql, $params) = $this->applyResearchFilters($sql, $filters);
        
        $sql .= " ORDER BY r.year DESC, r.research_title";
        
        return $this->executeQuery($sql, $params);
    }
    
    /**
     * Generate department summary report
     * @param array $filters Filter parameters
     * @return array Report data
     */
    public function generateDepartmentSummaryReport($filters = []) {
        $sql = "SELECT 
                    d.department_id,
                    d.department_name,
                    d.department_code,
                    COUNT(DISTINCT f.faculty_id) as faculty_count,
                    COUNT(DISTINCT r.research_id) as research_count
                FROM departments d
                LEFT JOIN faculty f ON d.department_id = f.department_id
                LEFT JOIN research r ON f.faculty_id = r.faculty_id
                WHERE 1=1";
        
        $params = [];
        
        if (!empty($filters['department_id'])) {
            $sql .= " AND d.department_id = ?";
            $params[] = intval($filters['department_id']);
        }
        
        $sql .= " GROUP BY d.department_id ORDER BY d.department_name";
        
        return $this->executeQuery($sql, $params);
    }
    
    /**
     * Generate education summary report
     * @param array $filters Filter parameters
     * @return array Report data
     */
    public function generateEducationSummaryReport($filters = []) {
        try {
            // Check if education table exists
            $stmt = $this->db->query("SHOW TABLES LIKE 'education'");
            if ($stmt->rowCount() == 0) {
                return [];
            }
            
            $columns = $this->getEducationColumns();
            $selectParts = $this->buildEducationSelectClause($columns);
            
            $sql = "SELECT " . implode(",\n                    ", $selectParts) . ",
                    CONCAT(f.first_name, ' ', f.last_name) AS faculty
                FROM education e
                LEFT JOIN faculty f ON e.faculty_id = f.faculty_id
                WHERE 1=1";
            
            $params = [];
            
            if (!empty($filters['department_id'])) {
                $sql .= " AND f.department_id = ?";
                $params[] = intval($filters['department_id']);
            }
            
            $sql .= $columns['year'] ? " ORDER BY f.last_name ASC, e.{$columns['year']} DESC" : " ORDER BY f.last_name ASC";
            
            return $this->executeQuery($sql, $params);
            
        } catch (\PDOException $e) {
            error_log('Education report error: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Generate faculty research report
     * @param array $filters Filter parameters
     * @return array Report data
     */
    public function generateFacultyResearchReport($filters = []) {
        $sql = "SELECT
                    CONCAT(f.first_name, ' ', f.last_name) AS faculty_name,
                    d.department_name,
                    r.research_title AS research_title,
                    rt.type_name AS research_type,
                    rs.status_name AS research_status,
                    r.year
                FROM research r
                LEFT JOIN faculty f ON r.faculty_id = f.faculty_id
                LEFT JOIN departments d ON f.department_id = d.department_id
                LEFT JOIN research_types rt ON r.research_type_id = rt.research_type_id
                LEFT JOIN research_statuses rs ON r.status_id = rs.status_id
                WHERE 1=1";
        
        list($sql, $params) = $this->applyResearchFilters($sql, $filters);
        
        $sql .= " ORDER BY f.last_name, r.year DESC";
        
        return $this->executeQuery($sql, $params);
    }
    
    /**
     * Generate awards report
     * @param array $filters Filter parameters
     * @return array Report data
     */
    public function generateAwardsReport($filters = []) {
        try {
            // Check if awards table exists
            $stmt = $this->db->query("SHOW TABLES LIKE 'awards'");
            if ($stmt->rowCount() == 0) {
                return [];
            }
            
            $columns = $this->getAwardsColumns();
            $selectParts = $this->buildAwardsSelectClause($columns);
            
            $conditions = [];
            $params = [];
            
            if (!empty($filters['department_id'])) {
                $conditions[] = "f.department_id = ?";
                $params[] = intval($filters['department_id']);
            }
            
            if (!empty($filters['year_from']) && $columns['year']) {
                $conditions[] = "a.{$columns['year']} >= ?";
                $params[] = intval($filters['year_from']);
            }
            
            if (!empty($filters['year_to']) && $columns['year']) {
                $conditions[] = "a.{$columns['year']} <= ?";
                $params[] = intval($filters['year_to']);
            }
            
            $whereClause = !empty($conditions) ? " AND " . implode(" AND ", $conditions) : "";
            
            $sql = "SELECT " . implode(",\n                    ", $selectParts) . "
                FROM awards a
                LEFT JOIN faculty f ON a.faculty_id = f.faculty_id
                LEFT JOIN departments d ON f.department_id = d.department_id
                WHERE 1=1{$whereClause}
                ORDER BY " . ($columns['year'] ? "a.{$columns['year']} DESC, " : "") . "f.last_name ASC";
            
            return $this->executeQuery($sql, $params);
            
        } catch (\PDOException $e) {
            error_log('Awards report error: ' . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Export data to CSV
     * @param array $data Data to export
     * @param array $headers Column headers
     * @param string $filename Output filename
     * @return void
     */
    public function exportToCSV($data, $headers, $filename) {
        // Sanitize filename
        $filename = preg_replace('/[^a-zA-Z0-9_\-\.]/', '', $filename);
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        $output = fopen('php://output', 'w');
        
        // Add BOM for Excel UTF-8 compatibility
        fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));
        
        // Write headers
        fputcsv($output, $headers);
        
        // Write data
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
        
        fclose($output);
        exit();
    }
    
    /**
     * Get KPI statistics
     * @return array Statistics data
     */
    public function getKPIStatistics() {
        $currentYear = (int)date('Y');
        $stats = [];
        
        // Total faculty count
        $stmt = $this->db->query("SELECT COUNT(*) FROM faculty");
        $stats['faculty_count'] = $stmt->fetchColumn();
        
        // Faculty by department
        $stats['faculty_by_dept'] = $this->executeQuery("
            SELECT d.department_name, COUNT(f.faculty_id) as count 
            FROM departments d 
            LEFT JOIN faculty f ON d.department_id = f.department_id 
            GROUP BY d.department_id, d.department_name 
            ORDER BY count DESC
        ");
        
        // Research by year (last 5 years)
        $stats['research_by_year'] = $this->executeQuery("
            SELECT year, COUNT(*) as count 
            FROM research 
            WHERE year >= ? 
            GROUP BY year 
            ORDER BY year
        ", [$currentYear - 4]);
        
        // Research by status
        $stats['research_by_status'] = $this->executeQuery("
            SELECT rs.status_name, COUNT(r.research_id) as count 
            FROM research_statuses rs 
            LEFT JOIN research r ON rs.status_id = r.status_id 
            GROUP BY rs.status_id, rs.status_name 
            ORDER BY count DESC
        ");
        
        // Research by type
        $stats['research_by_type'] = $this->executeQuery("
            SELECT rt.type_name, COUNT(r.research_id) as count 
            FROM research_types rt 
            LEFT JOIN research r ON rt.research_type_id = r.research_type_id 
            GROUP BY rt.research_type_id, rt.type_name 
            ORDER BY count DESC
        ");
        
        // Top researchers
        $stats['top_researchers'] = $this->executeQuery("
            SELECT f.first_name, f.last_name, COUNT(r.research_id) as research_count 
            FROM faculty f 
            LEFT JOIN research r ON f.faculty_id = r.faculty_id 
            GROUP BY f.faculty_id, f.first_name, f.last_name 
            HAVING research_count > 0 
            ORDER BY research_count DESC 
            LIMIT 10
        ");
        
        // Average research per faculty
        $stmt = $this->db->query("
            SELECT AVG(research_count) as avg_count 
            FROM (
                SELECT COUNT(r.research_id) as research_count 
                FROM faculty f 
                LEFT JOIN research r ON f.faculty_id = r.faculty_id 
                GROUP BY f.faculty_id
            ) as subquery
        ");
        $stats['avg_research'] = $stmt->fetchColumn();
        
        return $stats;
    }
    
    /**
     * Apply research filters to SQL query
     * @param string $sql Base SQL query
     * @param array $filters Filter parameters
     * @return array [SQL query, parameters array]
     */
    private function applyResearchFilters($sql, $filters) {
        $params = [];
        
        if (!empty($filters['department_id'])) {
            $sql .= " AND f.department_id = ?";
            $params[] = intval($filters['department_id']);
        }
        
        if (!empty($filters['year_from'])) {
            $sql .= " AND r.year >= ?";
            $params[] = intval($filters['year_from']);
        }
        
        if (!empty($filters['year_to'])) {
            $sql .= " AND r.year <= ?";
            $params[] = intval($filters['year_to']);
        }
        
        if (!empty($filters['research_status'])) {
            $sql .= " AND r.status_id = ?";
            $params[] = intval($filters['research_status']);
        }
        
        if (!empty($filters['research_type'])) {
            $sql .= " AND r.research_type_id = ?";
            $params[] = intval($filters['research_type']);
        }
        
        return [$sql, $params];
    }
    
    /**
     * Get education table columns dynamically
     * @return array Mapped column names
     */
    private function getEducationColumns() {
        $columnsStmt = $this->db->query("DESCRIBE education");
        $columns = $columnsStmt->fetchAll(PDO::FETCH_COLUMN);
        
        $columnMap = [
            'degree_title' => ['degree_title', 'degree', 'degree_name', 'qualification'],
            'school' => ['school', 'school_name', 'institution', 'university', 'college'],
            'field_of_study' => ['field_of_study', 'field', 'major', 'specialization', 'program'],
            'year' => ['year', 'year_graduated', 'graduation_year', 'completion_year', 'grad_year']
        ];
        
        return $this->mapColumns($columns, $columnMap);
    }
    
    /**
     * Get awards table columns dynamically
     * @return array Mapped column names
     */
    private function getAwardsColumns() {
        $columnsStmt = $this->db->query("DESCRIBE awards");
        $columns = $columnsStmt->fetchAll(PDO::FETCH_COLUMN);
        
        $columnMap = [
            'title' => ['title', 'award_title', 'award_name', 'name'],
            'description' => ['description', 'award_description', 'details'],
            'year' => ['year', 'year_awarded', 'award_year', 'date_received'],
            'organization' => ['organization', 'awarding_organization', 'issuing_organization', 'institution']
        ];
        
        return $this->mapColumns($columns, $columnMap);
    }
    
    /**
     * Map available columns to standard names
     * @param array $availableColumns Available column names
     * @param array $columnMap Mapping definitions
     * @return array Mapped columns
     */
    private function mapColumns($availableColumns, $columnMap) {
        $mapped = [];
        
        foreach ($columnMap as $standardName => $possibleNames) {
            $mapped[$standardName] = null;
            foreach ($possibleNames as $possibleName) {
                if (in_array($possibleName, $availableColumns)) {
                    $mapped[$standardName] = $possibleName;
                    break;
                }
            }
        }
        
        return $mapped;
    }
    
    /**
     * Build SELECT clause for education report
     * @param array $columns Column mapping
     * @return array SELECT clause parts
     */
    private function buildEducationSelectClause($columns) {
        return [
            $columns['degree_title'] ? "e.{$columns['degree_title']} AS degree_title" : "'N/A' AS degree_title",
            $columns['school'] ? "e.{$columns['school']} AS school" : "'N/A' AS school",
            $columns['field_of_study'] ? "e.{$columns['field_of_study']} AS field_of_study" : "'N/A' AS field_of_study",
            $columns['year'] ? "e.{$columns['year']} AS year" : "'N/A' AS year"
        ];
    }
    
    /**
     * Build SELECT clause for awards report
     * @param array $columns Column mapping
     * @return array SELECT clause parts
     */
    private function buildAwardsSelectClause($columns) {
        return [
            "CONCAT(f.first_name, ' ', f.last_name) AS faculty_name",
            "d.department_name",
            $columns['title'] ? "a.{$columns['title']} AS award_title" : "'N/A' AS award_title",
            $columns['description'] ? "a.{$columns['description']} AS award_description" : "'N/A' AS award_description",
            $columns['year'] ? "a.{$columns['year']} AS award_year" : "'N/A' AS award_year",
            $columns['organization'] ? "a.{$columns['organization']} AS organization" : "'N/A' AS organization"
        ];
    }
    
    /**
     * Execute prepared query
     * @param string $sql SQL query
     * @param array $params Query parameters
     * @return array Query results
     */
    private function executeQuery($sql, $params = []) {
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}