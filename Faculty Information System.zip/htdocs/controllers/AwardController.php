<?php
namespace Controllers;

use Models\AwardModel;
use Models\FacultyModel;
use Modules\Auth;
use Modules\Validator;
use Modules\SessionManager;
use Modules\CSRF;

/**
 * Award Controller
 * Handles award-related business logic and operations
 */
class AwardController {
    private $awardModel;
    private $facultyModel;
    private $auth;
    private $session;
    private $csrf;
    
    public function __construct() {
        $this->awardModel = new AwardModel();
        $this->facultyModel = new FacultyModel();
        $this->auth = new Auth();
        $this->session = SessionManager::getInstance();
        $this->csrf = new CSRF();
    }
    
    /**
     * Add new award
     * @param int $facultyId Faculty member ID
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function add($facultyId, $postData) {
        if (!$this->auth->canEditFaculty($facultyId)) {
            return $this->errorResponse("You don't have permission to add awards for this faculty member.");
        }
        
        $errors = $this->validateAwardData($postData, true);
        
        if (empty($errors)) {
            try {
                $awardId = $this->awardModel->create($this->prepareAwardData($postData, $facultyId));
                
                return [
                    'success' => true,
                    'message' => 'Award added successfully!',
                    'award_id' => $awardId
                ];
            } catch (\Exception $e) {
                error_log('Error adding award: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while adding the award.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Update existing award
     * @param int $awardId Award ID
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function update($awardId, $postData) {
        $award = $this->awardModel->getById($awardId);
        if (!$award) {
            return $this->errorResponse('Award not found.');
        }
        
        if (!$this->auth->canEditFaculty($award['faculty_id'])) {
            return $this->errorResponse("You don't have permission to edit this award.");
        }
        
        $errors = $this->validateAwardData($postData, false);
        
        if (empty($errors)) {
            try {
                $success = $this->awardModel->update($awardId, $this->prepareAwardData($postData));
                
                return [
                    'success' => $success,
                    'message' => 'Award updated successfully!'
                ];
            } catch (\Exception $e) {
                error_log('Error updating award: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while updating the award.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Delete award
     * @param int $awardId Award ID
     * @return array Result with success status and message
     */
    public function delete($awardId) {
        $award = $this->awardModel->getById($awardId);
        if (!$award) {
            return ['success' => false, 'message' => 'Award not found.'];
        }
        
        if (!$this->auth->canEditFaculty($award['faculty_id'])) {
            return ['success' => false, 'message' => "You don't have permission to delete this award."];
        }
        
        try {
            $this->awardModel->delete($awardId);
            return [
                'success' => true,
                'message' => 'Award deleted successfully.',
                'faculty_id' => $award['faculty_id']
            ];
        } catch (\Exception $e) {
            error_log('Error deleting award: ' . $e->getMessage());
            return ['success' => false, 'message' => 'An error occurred while deleting the award.'];
        }
    }
    
    /**
     * Validate award form data
     * @param array $postData Form data
     * @param bool $isNew Whether this is a new award (requires award_type_id)
     * @return array Array of error messages
     */
    private function validateAwardData($postData, $isNew = false) {
        $errors = [];
        
        // Sanitize inputs
        $awardName = trim($postData['award_name'] ?? '');
        $awardingOrg = trim($postData['awarding_organization'] ?? '');
        $yearAwarded = intval($postData['year_awarded'] ?? 0);
        $prizeAmount = !empty($postData['prize_amount']) ? floatval($postData['prize_amount']) : 0;
        
        // Validate required fields
        if ($isNew) {
            $awardTypeId = intval($postData['award_type_id'] ?? 0);
            if ($awardTypeId <= 0) {
                $errors[] = 'Please select a valid award type.';
            }
        }
        
        if (empty($awardName)) {
            $errors[] = 'Award name is required.';
        }
        
        if (empty($awardingOrg)) {
            $errors[] = 'Awarding organization is required.';
        }
        
        // Validate year range
        $currentYear = (int)date('Y');
        if ($yearAwarded < 1900 || $yearAwarded > $currentYear + 1) {
            $errors[] = 'Please enter a valid year.';
        }
        
        // Validate prize amount
        if ($prizeAmount < 0) {
            $errors[] = 'Prize amount cannot be negative.';
        }
        
        return $errors;
    }
    
    /**
     * Prepare award data for database insertion/update
     * @param array $postData Form data
     * @param int|null $facultyId Faculty ID (only for new awards)
     * @return array Sanitized data array
     */
    private function prepareAwardData($postData, $facultyId = null) {
        $data = [
            'award_name' => Validator::sanitize(trim($postData['award_name'] ?? '')),
            'awarding_organization' => Validator::sanitize(trim($postData['awarding_organization'] ?? '')),
            'year_awarded' => intval($postData['year_awarded'] ?? 0),
            'description' => !empty($postData['description']) ? Validator::sanitize(trim($postData['description'])) : null,
            'prize_amount' => !empty($postData['prize_amount']) ? floatval($postData['prize_amount']) : 0,
            'is_national' => isset($postData['is_national']) ? 1 : 0,
            'is_international' => isset($postData['is_international']) ? 1 : 0
        ];
        
        // Add faculty_id and award_type_id only for new awards
        if ($facultyId !== null) {
            $data['faculty_id'] = $facultyId;
            $data['award_type_id'] = intval($postData['award_type_id'] ?? 0);
        }
        
        return $data;
    }
    
    /**
     * Helper method to create error response
     * @param string|array $message Error message(s)
     * @return array Error response array
     */
    private function errorResponse($message) {
        return [
            'success' => false,
            'errors' => is_array($message) ? $message : [$message]
        ];
    }
}