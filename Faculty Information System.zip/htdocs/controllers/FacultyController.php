<?php
namespace Controllers;

use Models\FacultyModel;
use Models\DepartmentModel;
use Models\UserModel;
use Modules\Auth;
use Modules\Validator;
use Modules\FileUpload;
use Modules\SessionManager;
use Modules\CSRF;

/**
 * Faculty Controller
 * Handles faculty-related business logic and operations
 */
class FacultyController {
    private $facultyModel;
    private $departmentModel;
    private $userModel;
    private $auth;
    private $session;
    private $csrf;
    private $fileUpload;
    
    public function __construct() {
        $this->facultyModel = new FacultyModel();
        $this->departmentModel = new DepartmentModel();
        $this->userModel = new UserModel();
        $this->auth = new Auth();
        $this->session = SessionManager::getInstance();
        $this->csrf = new CSRF();
        $this->fileUpload = new FileUpload();
    }
    
    /**
     * Add new faculty member
     * @param array $postData Form submission data
     * @param array $files Uploaded files
     * @return array Result with success status and message/errors
     */
    public function add($postData, $files) {
        $this->auth->requireAdmin();
        
        // Validate CSRF token
        if (!$this->csrf->validateToken($postData['csrf_token'] ?? '')) {
            return $this->errorResponse('Invalid security token. Please try again.');
        }
        
        $errors = $this->validateFacultyData($postData);
        
        // Handle account creation validation
        $createAccount = isset($postData['create_account']) && $postData['create_account'] === '1';
        $userId = null;
        
        if ($createAccount && empty($errors)) {
            $accountErrors = $this->validateAccountData($postData);
            $errors = array_merge($errors, $accountErrors);
        }
        
        // Handle photo upload
        $photoUrl = $this->handlePhotoUpload($files, $errors);
        
        // Insert into database if no errors
        if (empty($errors)) {
            try {
                $this->facultyModel->beginTransaction();
                
                // Create user account if requested
                if ($createAccount) {
                    $userId = $this->createUserAccount($postData);
                }
                
                // Create faculty record
                $facultyId = $this->createFacultyRecord($postData, $userId, $photoUrl);
                
                $this->facultyModel->commit();
                
                return [
                    'success' => true,
                    'message' => $createAccount 
                        ? 'Faculty member added successfully with login credentials!' 
                        : 'Faculty member added successfully!',
                    'faculty_id' => $facultyId
                ];
                
            } catch (\Exception $e) {
                $this->facultyModel->rollBack();
                error_log('Error adding faculty: ' . $e->getMessage());
                
                // Clean up uploaded photo
                if ($photoUrl && file_exists($photoUrl)) {
                    @unlink($photoUrl);
                }
                
                return $this->errorResponse('An error occurred while adding the faculty member.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Update existing faculty member
     * @param int $facultyId Faculty member ID
     * @param array $postData Form submission data
     * @param array $files Uploaded files
     * @return array Result with success status and message/errors
     */
    public function update($facultyId, $postData, $files) {
        if (!$this->auth->canEditFaculty($facultyId)) {
            return $this->errorResponse("You don't have permission to edit this profile.");
        }
        
        // Validate CSRF token
        if (!$this->csrf->validateToken($postData['csrf_token'] ?? '')) {
            return $this->errorResponse('Invalid security token. Please try again.');
        }
        
        // Get existing faculty data
        $faculty = $this->facultyModel->getById($facultyId);
        if (!$faculty) {
            return $this->errorResponse('Faculty member not found.');
        }
        
        $errors = $this->validateFacultyData($postData, $facultyId);
        
        // Handle photo upload
        $photoUrl = $this->handlePhotoUpload($files, $errors, $faculty['photo_url'] ?? null);
        
        if (empty($errors)) {
            try {
                $success = $this->facultyModel->update($facultyId, $this->prepareFacultyUpdateData($postData, $photoUrl));
                
                return [
                    'success' => $success,
                    'message' => 'Faculty information updated successfully!'
                ];
            } catch (\Exception $e) {
                error_log('Error updating faculty: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while updating the faculty member.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Delete faculty member
     * @param int $facultyId Faculty member ID
     * @return array Result with success status and message
     */
    public function delete($facultyId) {
        $this->auth->requireAdmin();
        
        try {
            $faculty = $this->facultyModel->getById($facultyId);
            if (!$faculty) {
                return ['success' => false, 'message' => 'Faculty member not found.'];
            }
            
            // Delete photo if exists
            if (!empty($faculty['photo_url'])) {
                $this->fileUpload->deleteFile($faculty['photo_url']);
            }
            
            $this->facultyModel->delete($facultyId);
            
            return ['success' => true, 'message' => 'Faculty member deleted successfully.'];
        } catch (\Exception $e) {
            error_log('Error deleting faculty: ' . $e->getMessage());
            return ['success' => false, 'message' => 'An error occurred while deleting the faculty member.'];
        }
    }
    
    /**
     * Validate faculty form data
     * @param array $postData Form data
     * @param int|null $facultyId Faculty ID for updates (to check email uniqueness)
     * @return array Array of error messages
     */
    private function validateFacultyData($postData, $facultyId = null) {
        $errors = [];
        
        // Sanitize inputs
        $firstName = trim($postData['first_name'] ?? '');
        $lastName = trim($postData['last_name'] ?? '');
        $email = trim($postData['email'] ?? '');
        $phone = trim($postData['phone'] ?? '');
        
        // Validate required fields
        if ($error = Validator::required($firstName, 'First name')) $errors[] = $error;
        if ($error = Validator::required($lastName, 'Last name')) $errors[] = $error;
        if ($error = Validator::required($email, 'Email')) $errors[] = $error;
        
        // Validate email format
        if (empty($errors) && ($error = Validator::email($email))) {
            $errors[] = $error;
        }
        
        // Validate phone if provided
        if (!empty($phone) && ($error = Validator::phone($phone))) {
            $errors[] = $error;
        }
        
        // Validate length constraints
        if ($error = Validator::length($firstName, 1, 100, 'First name')) $errors[] = $error;
        if ($error = Validator::length($lastName, 1, 100, 'Last name')) $errors[] = $error;
        if ($error = Validator::length($email, 1, 100, 'Email')) $errors[] = $error;
        
        // Check email uniqueness
        if (empty($errors) && $this->facultyModel->emailExists($email, $facultyId)) {
            $errors[] = 'A faculty member with this email already exists.';
        }
        
        return $errors;
    }
    
    /**
     * Validate user account creation data
     * @param array $postData Form data
     * @return array Array of error messages
     */
    private function validateAccountData($postData) {
        $errors = [];
        
        $username = trim($postData['username'] ?? '');
        $password = $postData['password'] ?? '';
        
        if ($error = Validator::required($username, 'Username')) $errors[] = $error;
        if ($error = Validator::required($password, 'Password')) $errors[] = $error;
        if ($error = Validator::length($username, 3, 50, 'Username')) $errors[] = $error;
        if ($error = Validator::password($password)) $errors[] = $error;
        
        if (empty($errors) && $this->userModel->usernameExists($username)) {
            $errors[] = 'Username already exists.';
        }
        
        return $errors;
    }
    
    /**
     * Handle photo file upload
     * @param array $files Uploaded files array
     * @param array &$errors Reference to errors array
     * @param string|null $existingPhoto Existing photo path for updates
     * @return string|null Photo URL or null
     */
    private function handlePhotoUpload($files, &$errors, $existingPhoto = null) {
        $photoUrl = $existingPhoto;
        
        if (isset($files['photo']) && $files['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $uploadResult = $this->fileUpload->uploadImage($files['photo'], $existingPhoto);
            if (!$uploadResult['success']) {
                $errors = array_merge($errors, $uploadResult['errors']);
            } else {
                $photoUrl = $uploadResult['path'];
            }
        }
        
        return $photoUrl;
    }
    
    /**
     * Create user account for faculty
     * @param array $postData Form data
     * @return int User ID
     * @throws \Exception If faculty user type not found
     */
    private function createUserAccount($postData) {
        $userTypes = $this->userModel->getUserTypes();
        $facultyTypeId = null;
        
        foreach ($userTypes as $type) {
            if (strtolower(trim($type['type_name'])) === 'faculty') {
                $facultyTypeId = $type['user_type_id'];
                break;
            }
        }
        
        if (!$facultyTypeId) {
            throw new \Exception('Faculty user type not found.');
        }
        
        return $this->userModel->create([
            'username' => Validator::sanitize(trim($postData['username'])),
            'password' => $postData['password'],
            'email' => trim($postData['email']),
            'user_type_id' => $facultyTypeId,
            'created_by' => $this->session->getUserId()
        ]);
    }
    
    /**
     * Create faculty record
     * @param array $postData Form data
     * @param int|null $userId User ID if account created
     * @param string|null $photoUrl Photo URL
     * @return int Faculty ID
     */
    private function createFacultyRecord($postData, $userId, $photoUrl) {
        $departmentId = !empty($postData['department_id']) ? intval($postData['department_id']) : null;
        
        return $this->facultyModel->create([
            'user_id' => $userId,
            'department_id' => $departmentId,
            'first_name' => Validator::sanitize(trim($postData['first_name'])),
            'last_name' => Validator::sanitize(trim($postData['last_name'])),
            'email' => Validator::sanitize(trim($postData['email'])),
            'phone' => !empty($postData['phone']) ? Validator::sanitize(trim($postData['phone'])) : null,
            'address' => !empty($postData['address']) ? Validator::sanitize(trim($postData['address'])) : null,
            'photo_url' => $photoUrl,
            'created_by' => $this->session->getUserId()
        ]);
    }
    
    /**
     * Prepare faculty data for update
     * @param array $postData Form data
     * @param string|null $photoUrl Photo URL
     * @return array Sanitized data array
     */
    private function prepareFacultyUpdateData($postData, $photoUrl) {
        $departmentId = !empty($postData['department_id']) ? intval($postData['department_id']) : null;
        
        return [
            'department_id' => $departmentId,
            'first_name' => Validator::sanitize(trim($postData['first_name'])),
            'last_name' => Validator::sanitize(trim($postData['last_name'])),
            'email' => Validator::sanitize(trim($postData['email'])),
            'phone' => !empty($postData['phone']) ? Validator::sanitize(trim($postData['phone'])) : null,
            'address' => !empty($postData['address']) ? Validator::sanitize(trim($postData['address'])) : null,
            'photo_url' => $photoUrl,
            'updated_by' => $this->session->getUserId()
        ];
    }
    
    /**
     * Helper method to create error response
     * @param string|array $message Error message(s)
     * @return array Error response array
     */
    private function errorResponse($message) {
        return [
            'success' => false,
            'errors' => is_array($message) ? $message : [$message]
        ];
    }
}