<?php
namespace Controllers;

use Models\ResearchModel;
use Models\FacultyModel;
use Modules\Auth;
use Modules\Validator;
use Modules\SessionManager;
use Modules\CSRF;

/**
 * Research Controller
 * Handles research-related business logic and operations
 */
class ResearchController {
    private $researchModel;
    private $facultyModel;
    private $auth;
    private $session;
    private $csrf;
    
    public function __construct() {
        $this->researchModel = new ResearchModel();
        $this->facultyModel = new FacultyModel();
        $this->auth = new Auth();
        $this->session = SessionManager::getInstance();
        $this->csrf = new CSRF();
    }
    
    /**
     * Add new research record
     * @param int $facultyId Faculty member ID
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function add($facultyId, $postData) {
        if (!$this->auth->canEditFaculty($facultyId)) {
            return $this->errorResponse("You don't have permission to add records for this faculty.");
        }
        
        // Validate CSRF token
        if (!$this->csrf->validateToken($postData['csrf_token'] ?? '')) {
            return $this->errorResponse('Invalid security token. Please try again.');
        }
        
        $errors = $this->validateResearchData($postData);
        
        if (empty($errors)) {
            try {
                $researchId = $this->researchModel->create($this->prepareResearchData($postData, $facultyId));
                
                return [
                    'success' => true,
                    'message' => 'Research record added successfully!',
                    'research_id' => $researchId
                ];
            } catch (\Exception $e) {
                error_log('Error adding research: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while adding the research record.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Update existing research record
     * @param int $researchId Research record ID
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function update($researchId, $postData) {
        $research = $this->researchModel->getById($researchId);
        if (!$research) {
            return $this->errorResponse('Research record not found.');
        }
        
        if (!$this->auth->canEditFaculty($research['faculty_id'])) {
            return $this->errorResponse("You don't have permission to edit this research record.");
        }
        
        $errors = $this->validateResearchData($postData);
        
        if (empty($errors)) {
            try {
                $success = $this->researchModel->update($researchId, $this->prepareResearchData($postData));
                
                return [
                    'success' => $success,
                    'message' => 'Research record updated successfully!'
                ];
            } catch (\Exception $e) {
                error_log('Error updating research: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while updating the research record.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Delete research record
     * @param int $researchId Research record ID
     * @return array Result with success status and message
     */
    public function delete($researchId) {
        $research = $this->researchModel->getById($researchId);
        if (!$research) {
            return ['success' => false, 'message' => 'Research record not found.'];
        }
        
        if (!$this->auth->canEditFaculty($research['faculty_id'])) {
            return ['success' => false, 'message' => "You don't have permission to delete this research record."];
        }
        
        try {
            $this->researchModel->delete($researchId);
            return [
                'success' => true,
                'message' => 'Research record deleted successfully.',
                'faculty_id' => $research['faculty_id']
            ];
        } catch (\Exception $e) {
            error_log('Error deleting research: ' . $e->getMessage());
            return ['success' => false, 'message' => 'An error occurred while deleting the research record.'];
        }
    }
    
    /**
     * Validate research form data
     * @param array $postData Form data
     * @return array Array of error messages
     */
    private function validateResearchData($postData) {
        $errors = [];
        
        // Sanitize inputs
        $researchTitle = trim($postData['research_title'] ?? '');
        $researchTypeId = intval($postData['research_type_id'] ?? 0);
        $statusId = intval($postData['status_id'] ?? 0);
        $year = trim($postData['year'] ?? '');
        
        // Validate required fields
        if ($error = Validator::required($researchTitle, 'Research title')) {
            $errors[] = $error;
        }
        
        if ($researchTypeId <= 0) {
            $errors[] = 'Please select a research type.';
        }
        
        if ($statusId <= 0) {
            $errors[] = 'Please select a status.';
        }
        
        if ($error = Validator::required($year, 'Year')) {
            $errors[] = $error;
        }
        
        // Validate year format
        if (empty($errors) && ($error = Validator::year($year))) {
            $errors[] = $error;
        }
        
        // Validate title length
        if ($error = Validator::length($researchTitle, 1, 255, 'Research title')) {
            $errors[] = $error;
        }
        
        return $errors;
    }
    
    /**
     * Prepare research data for database insertion/update
     * @param array $postData Form data
     * @param int|null $facultyId Faculty ID (only for new records)
     * @return array Sanitized data array
     */
    private function prepareResearchData($postData, $facultyId = null) {
        $description = trim($postData['description'] ?? '');
        
        $data = [
            'research_title' => Validator::sanitize(trim($postData['research_title'] ?? '')),
            'research_type_id' => intval($postData['research_type_id'] ?? 0),
            'status_id' => intval($postData['status_id'] ?? 0),
            'year' => intval($postData['year'] ?? 0),
            'description' => !empty($description) ? Validator::sanitize($description) : null
        ];
        
        // Add faculty_id only for new records
        if ($facultyId !== null) {
            $data['faculty_id'] = $facultyId;
        }
        
        return $data;
    }
    
    /**
     * Helper method to create error response
     * @param string|array $message Error message(s)
     * @return array Error response array
     */
    private function errorResponse($message) {
        return [
            'success' => false,
            'errors' => is_array($message) ? $message : [$message]
        ];
    }
}