<?php
namespace Controllers;

use Models\EducationModel;
use Models\FacultyModel;
use Modules\Auth;
use Modules\Validator;
use Modules\SessionManager;
use Modules\CSRF;

/**
 * Education Controller
 * Handles education-related business logic and operations
 */
class EducationController {
    private $educationModel;
    private $facultyModel;
    private $auth;
    private $session;
    private $csrf;
    
    public function __construct() {
        $this->educationModel = new EducationModel();
        $this->facultyModel = new FacultyModel();
        $this->auth = new Auth();
        $this->session = SessionManager::getInstance();
        $this->csrf = new CSRF();
    }
    
    /**
     * Add new education record
     * @param int $facultyId Faculty member ID
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function add($facultyId, $postData) {
        if (!$this->auth->canEditFaculty($facultyId)) {
            return $this->errorResponse("You don't have permission to add records for this faculty.");
        }
        
        // Validate CSRF token
        if (!$this->csrf->validateToken($postData['csrf_token'] ?? '')) {
            return $this->errorResponse('Invalid security token. Please try again.');
        }
        
        $errors = $this->validateEducationData($postData);
        
        if (empty($errors)) {
            try {
                $educationId = $this->educationModel->create($this->prepareEducationData($postData, $facultyId));
                
                return [
                    'success' => true,
                    'message' => 'Education record added successfully!',
                    'education_id' => $educationId
                ];
            } catch (\Exception $e) {
                error_log('Error adding education: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while adding the education record.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Update existing education record
     * @param int $educationId Education record ID
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function update($educationId, $postData) {
        $education = $this->educationModel->getById($educationId);
        if (!$education) {
            return $this->errorResponse('Education record not found.');
        }
        
        if (!$this->auth->canEditFaculty($education['faculty_id'])) {
            return $this->errorResponse("You don't have permission to edit this education record.");
        }
        
        $errors = $this->validateEducationData($postData);
        
        if (empty($errors)) {
            try {
                $success = $this->educationModel->update($educationId, $this->prepareEducationData($postData));
                
                return [
                    'success' => $success,
                    'message' => 'Education record updated successfully!'
                ];
            } catch (\Exception $e) {
                error_log('Error updating education: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while updating the education record.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Delete education record
     * @param int $educationId Education record ID
     * @return array Result with success status and message
     */
    public function delete($educationId) {
        $education = $this->educationModel->getById($educationId);
        if (!$education) {
            return ['success' => false, 'message' => 'Education record not found.'];
        }
        
        if (!$this->auth->canEditFaculty($education['faculty_id'])) {
            return ['success' => false, 'message' => "You don't have permission to delete this education record."];
        }
        
        try {
            $this->educationModel->delete($educationId);
            return [
                'success' => true,
                'message' => 'Education record deleted successfully.',
                'faculty_id' => $education['faculty_id']
            ];
        } catch (\Exception $e) {
            error_log('Error deleting education: ' . $e->getMessage());
            return ['success' => false, 'message' => 'An error occurred while deleting the education record.'];
        }
    }
    
    /**
     * Validate education form data
     * @param array $postData Form data
     * @return array Array of error messages
     */
    private function validateEducationData($postData) {
        $errors = [];
        
        // Sanitize inputs
        $schoolName = trim($postData['school_name'] ?? '');
        $degreeTitle = trim($postData['degree_title'] ?? '');
        $fieldOfStudy = trim($postData['field_of_study'] ?? '');
        $yearGraduated = trim($postData['year_graduated'] ?? '');
        
        // Validate required fields
        if ($error = Validator::required($schoolName, 'School name')) {
            $errors[] = $error;
        }
        if ($error = Validator::required($degreeTitle, 'Degree title')) {
            $errors[] = $error;
        }
        if ($error = Validator::required($yearGraduated, 'Year graduated')) {
            $errors[] = $error;
        }
        
        // Validate year format
        if (empty($errors) && ($error = Validator::year($yearGraduated))) {
            $errors[] = $error;
        }
        
        // Validate length constraints
        if ($error = Validator::length($schoolName, 1, 200, 'School name')) {
            $errors[] = $error;
        }
        if ($error = Validator::length($degreeTitle, 1, 100, 'Degree title')) {
            $errors[] = $error;
        }
        if (!empty($fieldOfStudy) && ($error = Validator::length($fieldOfStudy, 1, 100, 'Field of study'))) {
            $errors[] = $error;
        }
        
        return $errors;
    }
    
    /**
     * Prepare education data for database insertion/update
     * @param array $postData Form data
     * @param int|null $facultyId Faculty ID (only for new records)
     * @return array Sanitized data array
     */
    private function prepareEducationData($postData, $facultyId = null) {
        $data = [
            'school_name' => Validator::sanitize(trim($postData['school_name'] ?? '')),
            'degree_title' => Validator::sanitize(trim($postData['degree_title'] ?? '')),
            'field_of_study' => !empty($postData['field_of_study']) ? Validator::sanitize(trim($postData['field_of_study'])) : null,
            'year_graduated' => intval($postData['year_graduated'] ?? 0)
        ];
        
        // Add faculty_id only for new records
        if ($facultyId !== null) {
            $data['faculty_id'] = $facultyId;
        }
        
        return $data;
    }
    
    /**
     * Helper method to create error response
     * @param string|array $message Error message(s)
     * @return array Error response array
     */
    private function errorResponse($message) {
        return [
            'success' => false,
            'errors' => is_array($message) ? $message : [$message]
        ];
    }
}