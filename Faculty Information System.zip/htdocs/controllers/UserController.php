<?php
namespace Controllers;

use Models\UserModel;
use Models\FacultyModel;
use Modules\Auth;
use Modules\Validator;
use Modules\SessionManager;
use Modules\CSRF;

/**
 * User Controller
 * Handles user management business logic and operations
 */
class UserController {
    private $userModel;
    private $facultyModel;
    private $auth;
    private $session;
    private $csrf;
    
    public function __construct() {
        $this->userModel = new UserModel();
        $this->facultyModel = new FacultyModel();
        $this->auth = new Auth();
        $this->session = SessionManager::getInstance();
        $this->csrf = new CSRF();
    }
    
    /**
     * Create new user
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function create($postData) {
        $this->auth->requireAdmin();
        
        // Validate CSRF token
        if (!$this->csrf->validateToken($postData['csrf_token'] ?? '')) {
            return $this->errorResponse('Invalid security token. Please try again.');
        }
        
        $errors = $this->validateUserData($postData);
        
        if (empty($errors)) {
            try {
                $db = \Config\Database::getInstance()->getConnection();
                $db->beginTransaction();
                
                // Create user
                $userId = $this->userModel->create($this->prepareUserData($postData));
                
                // Link to faculty if applicable
                $this->linkFacultyIfApplicable($postData, $userId, $db);
                
                $db->commit();
                
                return [
                    'success' => true,
                    'message' => 'User created successfully!',
                    'user_id' => $userId
                ];
            } catch (\Exception $e) {
                if (isset($db) && $db->inTransaction()) {
                    $db->rollBack();
                }
                error_log('Error creating user: ' . $e->getMessage());
                return $this->errorResponse('An error occurred while creating the user.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Update existing user
     * @param int $userId User ID
     * @param array $postData Form submission data
     * @return array Result with success status and message/errors
     */
    public function update($userId, $postData) {
        $this->auth->requireAdmin();
        
        // Prevent editing own account
        if ($userId === intval($this->session->getUserId())) {
            return $this->errorResponse('You cannot edit your own account through this interface.');
        }
        
        // Validate CSRF token
        if (!$this->csrf->validateToken($postData['csrf_token'] ?? '')) {
            return $this->errorResponse('Invalid security token. Please try again.');
        }
        
        $errors = $this->validateUserData($postData, $userId);
        
        if (empty($errors)) {
            try {
                $db = \Config\Database::getInstance()->getConnection();
                $db->beginTransaction();
                
                // Update user
                $updateSuccess = $this->userModel->update($userId, $this->prepareUserUpdateData($postData));
                
                if (!$updateSuccess) {
                    throw new \Exception('Failed to update user record');
                }
                
                // Update faculty linking
                $this->updateFacultyLinking($postData, $userId, $db);
                
                $db->commit();
                
                return [
                    'success' => true,
                    'message' => 'User updated successfully!'
                ];
                
            } catch (\Exception $e) {
                if (isset($db) && $db->inTransaction()) {
                    $db->rollBack();
                }
                error_log("Error updating user {$userId}: " . $e->getMessage());
                return $this->errorResponse('An error occurred while updating the user. Please try again.');
            }
        }
        
        return ['success' => false, 'errors' => $errors];
    }
    
    /**
     * Delete user
     * @param int $userId User ID
     * @return array Result with success status and message
     */
    public function delete($userId) {
        $this->auth->requireAdmin();
        
        if ($userId === intval($this->session->getUserId())) {
            return ['success' => false, 'message' => 'You cannot delete your own account!'];
        }
        
        try {
            $this->userModel->delete($userId);
            return ['success' => true, 'message' => 'User deleted successfully.'];
        } catch (\Exception $e) {
            error_log('Error deleting user: ' . $e->getMessage());
            return ['success' => false, 'message' => 'An error occurred while deleting the user.'];
        }
    }
    
    /**
     * Validate user form data
     * @param array $postData Form data
     * @param int|null $userId User ID for updates (to check username uniqueness)
     * @return array Array of error messages
     */
    private function validateUserData($postData, $userId = null) {
        $errors = [];
        
        // Sanitize inputs
        $username = Validator::sanitize(trim($postData['username'] ?? ''));
        $password = $postData['password'] ?? '';
        $userTypeId = intval($postData['user_type_id'] ?? 0);
        
        // Validate required fields
        if ($error = Validator::required($username, 'Username')) {
            $errors[] = $error;
        }
        
        if ($userTypeId <= 0) {
            $errors[] = 'Please select a user type.';
        }
        
        if ($error = Validator::length($username, 3, 50, 'Username')) {
            $errors[] = $error;
        }
        
        // Password validation (required for new users, optional for updates)
        if ($userId === null) {
            if ($error = Validator::required($password, 'Password')) {
                $errors[] = $error;
            }
            if (empty($errors) && strlen($password) < 6) {
                $errors[] = 'Password must be at least 6 characters.';
            }
        } else {
            if (!empty($password) && strlen($password) < 6) {
                $errors[] = 'Password must be at least 6 characters.';
            }
        }
        
        // Check username uniqueness
        if (empty($errors) && $this->userModel->usernameExists($username, $userId)) {
            $errors[] = 'Username already exists!';
        }
        
        return $errors;
    }
    
    /**
     * Prepare user data for creation
     * @param array $postData Form data
     * @return array Sanitized data array
     */
    private function prepareUserData($postData) {
        return [
            'username' => Validator::sanitize(trim($postData['username'])),
            'password' => $postData['password'],
            'user_type_id' => intval($postData['user_type_id']),
            'created_by' => $this->session->getUserId()
        ];
    }
    
    /**
     * Prepare user data for update
     * @param array $postData Form data
     * @return array Sanitized data array
     */
    private function prepareUserUpdateData($postData) {
        $data = [
            'username' => Validator::sanitize(trim($postData['username'])),
            'user_type_id' => intval($postData['user_type_id'])
        ];
        
        // Only include password if provided
        $password = trim($postData['password'] ?? '');
        if (!empty($password)) {
            $data['password'] = $password;
        }
        
        return $data;
    }
    
    /**
     * Link faculty member to user if applicable
     * @param array $postData Form data
     * @param int $userId User ID
     * @param \PDO $db Database connection
     * @return void
     */
    private function linkFacultyIfApplicable($postData, $userId, $db) {
        $facultyId = intval($postData['faculty_id'] ?? 0);
        $userTypeId = intval($postData['user_type_id']);
        
        if ($facultyId > 0 && $this->isFacultyUserType($userTypeId)) {
            $stmt = $db->prepare('UPDATE faculty SET user_id = ? WHERE faculty_id = ?');
            $stmt->execute([$userId, $facultyId]);
        }
    }
    
    /**
     * Update faculty linking for user
     * @param array $postData Form data
     * @param int $userId User ID
     * @param \PDO $db Database connection
     * @throws \Exception If linking fails
     * @return void
     */
    private function updateFacultyLinking($postData, $userId, $db) {
        $facultyId = intval($postData['faculty_id'] ?? 0);
        $userTypeId = intval($postData['user_type_id']);
        $isFacultyType = $this->isFacultyUserType($userTypeId);
        
        if ($isFacultyType && $facultyId > 0) {
            // Unlink other faculty members from this user
            $stmt = $db->prepare('UPDATE faculty SET user_id = NULL WHERE user_id = ? AND faculty_id != ?');
            $stmt->execute([$userId, $facultyId]);
            
            // Link the selected faculty
            $stmt = $db->prepare('UPDATE faculty SET user_id = ? WHERE faculty_id = ?');
            $linkResult = $stmt->execute([$userId, $facultyId]);
            
            if (!$linkResult) {
                throw new \Exception('Failed to link faculty member');
            }
        } else {
            // Unlink all faculty members from this user
            $stmt = $db->prepare('UPDATE faculty SET user_id = NULL WHERE user_id = ?');
            $stmt->execute([$userId]);
        }
    }
    
    /**
     * Check if user type is faculty
     * @param int $userTypeId User type ID
     * @return bool True if faculty type
     */
    private function isFacultyUserType($userTypeId) {
        $userTypes = $this->userModel->getUserTypes();
        
        foreach ($userTypes as $type) {
            if ($type['user_type_id'] == $userTypeId && 
                strtolower(trim($type['type_name'])) === 'faculty') {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Helper method to create error response
     * @param string|array $message Error message(s)
     * @return array Error response array
     */
    private function errorResponse($message) {
        return [
            'success' => false,
            'errors' => is_array($message) ? $message : [$message]
        ];
    }
}