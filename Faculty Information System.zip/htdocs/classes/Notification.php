<?php
/**
 * Notification Class
 * Handles notification operations for users
 */

require_once __DIR__ . "/../config/Database.php";

use Config\Database;

class Notification {
    private $db;
    
    public function __construct() {
        $database = Database::getInstance();
        $this->db = $database->getConnection();
    }
    
    /**
     * Create a new notification
     * 
     * @param int $userId User ID
     * @param string $title Notification title
     * @param string $message Notification message
     * @param string $type Notification type (info, success, warning, error)
     * @param string|null $link Optional link
     * @return bool Success status
     */
    public function create($userId, $title, $message, $type = 'info', $link = null) {
        try {
            // Sanitize inputs
            $userId = filter_var($userId, FILTER_VALIDATE_INT);
            $title = htmlspecialchars(trim($title), ENT_QUOTES, 'UTF-8');
            $message = htmlspecialchars(trim($message), ENT_QUOTES, 'UTF-8');
            $type = in_array($type, ['info', 'success', 'warning', 'error']) ? $type : 'info';
            $link = $link ? htmlspecialchars(trim($link), ENT_QUOTES, 'UTF-8') : null;
            
            if ($userId === false || empty($title) || empty($message)) {
                return false;
            }
            
            $stmt = $this->db->prepare("
                INSERT INTO notifications (user_id, title, message, type, link, created_at) 
                VALUES (:user_id, :title, :message, :type, :link, NOW())
            ");
            
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':message', $message);
            $stmt->bindParam(':type', $type);
            $stmt->bindParam(':link', $link);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log("Notification Creation Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get notifications for a user
     * 
     * @param int $userId User ID
     * @param int $limit Maximum notifications to retrieve
     * @param bool $unreadOnly Get only unread notifications
     * @return array Notifications array
     */
    public function getByUser($userId, $limit = 20, $unreadOnly = false) {
        try {
            $userId = filter_var($userId, FILTER_VALIDATE_INT);
            $limit = filter_var($limit, FILTER_VALIDATE_INT);
            
            if ($userId === false || $limit === false) {
                return [];
            }
            
            $sql = "SELECT * FROM notifications WHERE user_id = :user_id";
            if ($unreadOnly) {
                $sql .= " AND is_read = 0";
            }
            $sql .= " ORDER BY created_at DESC LIMIT :limit";
            
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        } catch (PDOException $e) {
            error_log("Get Notifications Error: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get unread notification count
     * 
     * @param int $userId User ID
     * @return int Unread count
     */
    public function getUnreadCount($userId) {
        try {
            $userId = filter_var($userId, FILTER_VALIDATE_INT);
            if ($userId === false) {
                return 0;
            }
            
            $stmt = $this->db->prepare("
                SELECT COUNT(*) as count 
                FROM notifications 
                WHERE user_id = :user_id AND is_read = 0
            ");
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            $stmt->execute();
            
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return (int)($result['count'] ?? 0);
            
        } catch (PDOException $e) {
            error_log("Get Unread Count Error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Mark notification as read
     * 
     * @param int $notificationId Notification ID
     * @param int $userId User ID (for security)
     * @return bool Success status
     */
    public function markAsRead($notificationId, $userId) {
        try {
            $notificationId = filter_var($notificationId, FILTER_VALIDATE_INT);
            $userId = filter_var($userId, FILTER_VALIDATE_INT);
            
            if ($notificationId === false || $userId === false) {
                return false;
            }
            
            $stmt = $this->db->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE id = :id AND user_id = :user_id
            ");
            $stmt->bindParam(':id', $notificationId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log("Mark As Read Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Mark all notifications as read for a user
     * 
     * @param int $userId User ID
     * @return bool Success status
     */
    public function markAllAsRead($userId) {
        try {
            $userId = filter_var($userId, FILTER_VALIDATE_INT);
            if ($userId === false) {
                return false;
            }
            
            $stmt = $this->db->prepare("
                UPDATE notifications 
                SET is_read = 1, read_at = NOW() 
                WHERE user_id = :user_id AND is_read = 0
            ");
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log("Mark All As Read Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Delete a notification
     * 
     * @param int $notificationId Notification ID
     * @param int $userId User ID (for security)
     * @return bool Success status
     */
    public function delete($notificationId, $userId) {
        try {
            $notificationId = filter_var($notificationId, FILTER_VALIDATE_INT);
            $userId = filter_var($userId, FILTER_VALIDATE_INT);
            
            if ($notificationId === false || $userId === false) {
                return false;
            }
            
            $stmt = $this->db->prepare("
                DELETE FROM notifications 
                WHERE id = :id AND user_id = :user_id
            ");
            $stmt->bindParam(':id', $notificationId, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $userId, PDO::PARAM_INT);
            
            return $stmt->execute();
            
        } catch (PDOException $e) {
            error_log("Delete Notification Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Notify all faculty members
     * 
     * @param string $title Notification title
     * @param string $message Notification message
     * @param string $type Notification type
     * @param string|null $link Optional link
     * @return int Number of notifications created
     */
    public function notifyAllFaculty($title, $message, $type = 'info', $link = null) {
        try {
            $stmt = $this->db->query("
                SELECT u.user_id 
                FROM users u
                INNER JOIN user_types ut ON u.user_type_id = ut.user_type_id
                WHERE LOWER(ut.type_name) = 'faculty' AND u.is_active = 1
            ");
            $facultyUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $successCount = 0;
            foreach ($facultyUsers as $faculty) {
                if ($this->create($faculty['user_id'], $title, $message, $type, $link)) {
                    $successCount++;
                }
            }
            
            return $successCount;
            
        } catch (PDOException $e) {
            error_log("Notify All Faculty Error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Notify all admins
     * 
     * @param string $title Notification title
     * @param string $message Notification message
     * @param string $type Notification type
     * @param string|null $link Optional link
     * @return int Number of notifications created
     */
    public function notifyAllAdmins($title, $message, $type = 'info', $link = null) {
        try {
            $stmt = $this->db->query("
                SELECT user_id 
                FROM users 
                WHERE is_admin = 1 AND is_active = 1
            ");
            $adminUsers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $successCount = 0;
            foreach ($adminUsers as $admin) {
                if ($this->create($admin['user_id'], $title, $message, $type, $link)) {
                    $successCount++;
                }
            }
            
            return $successCount;
            
        } catch (PDOException $e) {
            error_log("Notify All Admins Error: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Notify about email verification
     * 
     * @param int $userId User ID
     * @param string $userName User name
     * @return bool Success status
     */
    public function notifyEmailVerified($userId, $userName) {
        $title = "Email Verified Successfully";
        $message = "Welcome, {$userName}! Your email has been verified.";
        
        return $this->create($userId, $title, $message, 'success', 'dashboard.php');
    }
    
    /**
     * Send welcome notification
     * 
     * @param int $userId User ID
     * @param string $userName User name
     * @return bool Success status
     */
    public function notifyWelcomeUser($userId, $userName) {
        $title = "Welcome!";
        $message = "Hello {$userName}! Welcome to the Faculty Information System.";
        
        return $this->create($userId, $title, $message, 'info', 'profile.php');
    }
}