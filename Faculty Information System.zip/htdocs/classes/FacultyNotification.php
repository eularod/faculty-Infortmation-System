<?php
/**
 * Faculty Notification Handler
 * Handles all faculty-related notifications
 */

require_once __DIR__ . "/../config/Database.php";

use Config\Database;

class FacultyNotification {
    private $db;
    
    public function __construct() {
        $database = Database::getInstance();
        $this->db = $database->getConnection();
    }
    
    /**
     * Create a notification
     * 
     * @param int $userId User ID
     * @param string $title Notification title
     * @param string $message Notification message
     * @param string $type Notification type
     * @param string|null $link Optional link
     * @param bool $notifyAdmins Also notify all admins
     * @return bool Success status
     */
    public function createNotification($userId, $title, $message, $type = 'info', $link = null, $notifyAdmins = false) {
        try {
            // Sanitize inputs
            $userId = filter_var($userId, FILTER_VALIDATE_INT);
            $title = htmlspecialchars(trim($title), ENT_QUOTES, 'UTF-8');
            $message = htmlspecialchars(trim($message), ENT_QUOTES, 'UTF-8');
            $type = in_array($type, ['info', 'success', 'warning', 'danger']) ? $type : 'info';
            $link = $link ? htmlspecialchars(trim($link), ENT_QUOTES, 'UTF-8') : null;
            
            if ($userId === false || empty($title) || empty($message)) {
                return false;
            }
            
            // Create notification
            $stmt = $this->db->prepare("
                INSERT INTO notifications (user_id, title, message, type, link, created_at) 
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$userId, $title, $message, $type, $link]);
            
            // Notify admins if requested
            if ($notifyAdmins) {
                $this->notifyAdmins($title, $message, $type, $link);
            }
            
            return true;
            
        } catch (PDOException $e) {
            error_log("Notification Error: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Notify all admins
     */
    private function notifyAdmins($title, $message, $type, $link) {
        try {
            $stmt = $this->db->query("
                SELECT user_id 
                FROM users 
                WHERE is_admin = 1 AND is_active = 1
            ");
            $admins = $stmt->fetchAll(PDO::FETCH_COLUMN);
            
            foreach ($admins as $adminId) {
                $this->createNotification($adminId, $title, $message, $type, $link);
            }
            
        } catch (PDOException $e) {
            error_log("Admin Notification Error: " . $e->getMessage());
        }
    }
    
    // Profile Notifications
    
    public function notifyProfileUpdated($facultyUserId, $facultyName, $updatedByName, $fieldsUpdated = []) {
        $fields = !empty($fieldsUpdated) ? implode(', ', $fieldsUpdated) : 'profile information';
        $this->createNotification(
            $facultyUserId,
            'Profile Updated',
            "Your {$fields} has been updated by {$updatedByName}.",
            'info',
            'profile.php'
        );
    }
    
    public function notifyProfilePictureUpdated($facultyUserId, $facultyName) {
        $this->createNotification(
            $facultyUserId,
            'Profile Picture Updated',
            "Your profile picture has been successfully updated.",
            'success',
            'profile.php'
        );
    }
    
    // Education Notifications
    
    public function notifyEducationAdded($facultyUserId, $degree, $institution) {
        $this->createNotification(
            $facultyUserId,
            'Education Added',
            "Your {$degree} from {$institution} has been added to your profile.",
            'success',
            'profile.php#education'
        );
    }
    
    public function notifyEducationUpdated($facultyUserId, $degree, $institution) {
        $this->createNotification(
            $facultyUserId,
            'Education Updated',
            "Your {$degree} from {$institution} has been updated.",
            'info',
            'profile.php#education'
        );
    }
    
    public function notifyEducationDeleted($facultyUserId, $degree) {
        $this->createNotification(
            $facultyUserId,
            'Education Removed',
            "Your {$degree} entry has been removed from your profile.",
            'warning',
            'profile.php#education'
        );
    }
    
    // Experience Notifications
    
    public function notifyExperienceAdded($facultyUserId, $position, $organization) {
        $this->createNotification(
            $facultyUserId,
            'Experience Added',
            "Your position as {$position} at {$organization} has been added.",
            'success',
            'profile.php#experience'
        );
    }
    
    public function notifyExperienceUpdated($facultyUserId, $position, $organization) {
        $this->createNotification(
            $facultyUserId,
            'Experience Updated',
            "Your position as {$position} at {$organization} has been updated.",
            'info',
            'profile.php#experience'
        );
    }
    
    public function notifyExperienceDeleted($facultyUserId, $position) {
        $this->createNotification(
            $facultyUserId,
            'Experience Removed',
            "Your {$position} entry has been removed from your profile.",
            'warning',
            'profile.php#experience'
        );
    }
    
    // Research & Publication Notifications
    
    public function notifyResearchAdded($facultyUserId, $researchTitle) {
        $this->createNotification(
            $facultyUserId,
            'Research Added',
            "Your research '{$researchTitle}' has been added to your profile.",
            'success',
            'profile.php#research'
        );
    }
    
    public function notifyPublicationAdded($facultyUserId, $publicationTitle) {
        $this->createNotification(
            $facultyUserId,
            'Publication Added',
            "Your publication '{$publicationTitle}' has been added to your profile.",
            'success',
            'profile.php#publications'
        );
    }
    
    public function notifyPublicationUpdated($facultyUserId, $publicationTitle) {
        $this->createNotification(
            $facultyUserId,
            'Publication Updated',
            "Your publication '{$publicationTitle}' has been updated.",
            'info',
            'profile.php#publications'
        );
    }
    
    // Award Notifications
    
    public function notifyAwardAdded($facultyUserId, $awardName, $issuedBy = null) {
        $message = "Congratulations! The award '{$awardName}'" . 
                   ($issuedBy ? " from {$issuedBy}" : "") . 
                   " has been added to your profile.";
        
        $this->createNotification(
            $facultyUserId,
            'Award Added',
            $message,
            'success',
            'profile.php#awards'
        );
    }
    
    public function notifyCertificationAdded($facultyUserId, $certificationName, $issuedBy = null) {
        $message = "Your certification '{$certificationName}'" . 
                   ($issuedBy ? " from {$issuedBy}" : "") . 
                   " has been added to your profile.";
        
        $this->createNotification(
            $facultyUserId,
            'Certification Added',
            $message,
            'success',
            'profile.php#certifications'
        );
    }
    
    // Document Notifications
    
    public function notifyDocumentUploaded($facultyUserId, $documentType, $documentName) {
        $this->createNotification(
            $facultyUserId,
            'Document Uploaded',
            "Your {$documentType} '{$documentName}' has been uploaded successfully and is pending review.",
            'info',
            'documents.php'
        );
        
        // Notify admins
        $this->notifyAdmins(
            'New Document for Review',
            "A new {$documentType} has been uploaded and needs review.",
            'warning',
            'admin-documents.php'
        );
    }
    
    public function notifyDocumentApproved($facultyUserId, $documentName, $approvedBy) {
        $this->createNotification(
            $facultyUserId,
            'Document Approved',
            "Your document '{$documentName}' has been approved by {$approvedBy}.",
            'success',
            'documents.php'
        );
    }
    
    public function notifyDocumentRejected($facultyUserId, $documentName, $reason = null) {
        $message = "Your document '{$documentName}' has been rejected.";
        if ($reason) {
            $message .= " Reason: {$reason}";
        }
        
        $this->createNotification(
            $facultyUserId,
            'Document Rejected',
            $message,
            'danger',
            'documents.php'
        );
    }
    
    // Course Notifications
    
    public function notifyCourseAssigned($facultyUserId, $courseName, $semester) {
        $this->createNotification(
            $facultyUserId,
            'Course Assigned',
            "You have been assigned to teach '{$courseName}' for {$semester}.",
            'info',
            'courses.php'
        );
    }
    
    public function notifyCourseScheduleUpdated($facultyUserId, $courseName) {
        $this->createNotification(
            $facultyUserId,
            'Schedule Updated',
            "The schedule for '{$courseName}' has been updated.",
            'warning',
            'courses.php'
        );
    }
    
    // Admin Action Notifications
    
    public function notifyProfileApproved($facultyUserId, $facultyName, $approvedBy) {
        $this->createNotification(
            $facultyUserId,
            'Profile Approved',
            "Congratulations! Your profile has been approved by {$approvedBy}.",
            'success',
            'profile.php'
        );
    }
    
    public function notifyProfileNeedsRevision($facultyUserId, $reason, $requestedBy) {
        $this->createNotification(
            $facultyUserId,
            'Profile Revision Required',
            "Your profile needs revision. Reason: {$reason}. Requested by {$requestedBy}.",
            'warning',
            'profile.php'
        );
    }
    
    // Reminder Notifications
    
    public function remindCompleteProfile($facultyUserId, $missingSections = []) {
        $sections = implode(', ', $missingSections);
        
        $this->createNotification(
            $facultyUserId,
            'Complete Your Profile',
            "Please complete the following sections: {$sections}",
            'warning',
            'profile.php'
        );
    }
    
    public function remindUpdateInformation($facultyUserId, $section) {
        $this->createNotification(
            $facultyUserId,
            'Update Required',
            "Please review and update your {$section}. Some information may be outdated.",
            'warning',
            'profile.php'
        );
    }
    
    // Batch Operations
    
    public function notifyMultipleUsers($userIds, $title, $message, $type = 'info', $link = null) {
        try {
            $this->db->beginTransaction();
            
            foreach ($userIds as $userId) {
                $this->createNotification($userId, $title, $message, $type, $link);
            }
            
            $this->db->commit();
            return true;
            
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Multiple User Notification Error: " . $e->getMessage());
            return false;
        }
    }
}

/**
 * Quick helper function for faculty notifications
 */
function notifyFaculty($facultyUserId, $action, ...$params) {
    $notifier = new FacultyNotification();
    
    $actions = [
        'profile_updated' => 'notifyProfileUpdated',
        'education_added' => 'notifyEducationAdded',
        'experience_added' => 'notifyExperienceAdded',
        'award_added' => 'notifyAwardAdded',
        'document_uploaded' => 'notifyDocumentUploaded',
        'document_approved' => 'notifyDocumentApproved',
    ];
    
    if (isset($actions[$action]) && method_exists($notifier, $actions[$action])) {
        return call_user_func_array([$notifier, $actions[$action]], array_merge([$facultyUserId], $params));
    }
    
    return false;
}