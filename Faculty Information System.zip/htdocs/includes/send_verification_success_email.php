<?php
/**
 * Send Verification Success Email
 * Sends confirmation email after successful email verification
 * 
 * @param string $userEmail Recipient email address
 * @param string|null $userName Recipient name (optional)
 * @return bool True if email sent successfully, false otherwise
 */
function sendVerificationSuccessEmail($userEmail, $userName = null) {
    // Sanitize inputs
    $userEmail = filter_var($userEmail, FILTER_SANITIZE_EMAIL);
    if (!filter_var($userEmail, FILTER_VALIDATE_EMAIL)) {
        error_log('Invalid email address: ' . $userEmail);
        return false;
    }
    
    $displayName = $userName ? htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') : 'Valued User';
    
    // Get base URL
    $baseUrl = getBaseUrl();
    
    // Email configuration
    $subject = '✓ Email Verification Successful - Your Account is Now Active!';
    $htmlMessage = buildVerificationSuccessHtml($displayName, $baseUrl);
    $plainMessage = buildVerificationSuccessPlain($displayName, $baseUrl);
    $headers = buildEmailHeaders();
    
    // Send email
    $sent = mail($userEmail, $subject, $htmlMessage, $headers);
    
    // Log result
    if ($sent) {
        error_log('Verification success email sent to: ' . $userEmail);
    } else {
        error_log('Failed to send verification success email to: ' . $userEmail);
    }
    
    return $sent;
}

/**
 * Get base URL from server configuration
 * @return string Base URL with protocol and host
 */
function getBaseUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $protocol . '://' . $host;
}

/**
 * Build HTML email content
 * @param string $displayName User's display name
 * @param string $baseUrl Base URL for links
 * @return string HTML email content
 */
function buildVerificationSuccessHtml($displayName, $baseUrl) {
    $currentYear = date('Y');
    
    return <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            color: #333333;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .email-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .email-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #ffffff;
            padding: 40px 30px;
            text-align: center;
        }
        .success-icon {
            width: 80px;
            height: 80px;
            background-color: #ffffff;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 20px;
            font-size: 40px;
        }
        .email-header h1 {
            margin: 0;
            font-size: 28px;
            font-weight: 600;
        }
        .email-body {
            padding: 40px 30px;
        }
        .email-body h2 {
            color: #667eea;
            font-size: 24px;
            margin-top: 0;
            margin-bottom: 20px;
        }
        .email-body p {
            margin: 15px 0;
            font-size: 16px;
            color: #555555;
        }
        .success-message {
            background-color: #d4edda;
            border-left: 4px solid #28a745;
            padding: 15px 20px;
            margin: 25px 0;
            border-radius: 4px;
        }
        .success-message p {
            margin: 0;
            color: #155724;
            font-weight: 500;
        }
        .features-box {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin: 25px 0;
        }
        .features-box h3 {
            color: #667eea;
            font-size: 18px;
            margin-top: 0;
            margin-bottom: 15px;
        }
        .feature-item {
            display: flex;
            align-items: start;
            margin-bottom: 12px;
            padding-left: 10px;
        }
        .feature-icon {
            color: #28a745;
            margin-right: 10px;
            font-size: 18px;
            flex-shrink: 0;
        }
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: #ffffff;
            text-decoration: none;
            padding: 14px 32px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 16px;
            margin: 20px 0;
            text-align: center;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .email-footer {
            background-color: #f8f9fa;
            padding: 30px;
            text-align: center;
            border-top: 1px solid #e9ecef;
        }
        .email-footer p {
            margin: 5px 0;
            font-size: 14px;
            color: #6c757d;
        }
        .social-links {
            margin: 20px 0;
        }
        .social-links a {
            display: inline-block;
            margin: 0 8px;
            color: #667eea;
            text-decoration: none;
            font-size: 14px;
        }
        @media only screen and (max-width: 600px) {
            .email-body, .email-header {
                padding: 30px 20px;
            }
            .email-header h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <div class="success-icon">✓</div>
            <h1>Email Verified Successfully!</h1>
        </div>
        
        <div class="email-body">
            <h2>Hello {$displayName},</h2>
            
            <div class="success-message">
                <p>🎉 Your email address has been successfully verified!</p>
            </div>
            
            <p>Thank you for verifying your email address. Your account is now fully activated and you have access to all features.</p>
            
            <div class="features-box">
                <h3>What You Can Do Now:</h3>
                <div class="feature-item">
                    <span class="feature-icon">✓</span>
                    <span>Access all premium features and functionality</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span>
                    <span>Receive important notifications and updates</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span>
                    <span>Enhanced account security and protection</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">✓</span>
                    <span>Full access to your dashboard and settings</span>
                </div>
            </div>
            
            <p>You can now enjoy the complete experience without any restrictions.</p>
            
            <center>
                <a href="{$baseUrl}/user/dashboard.php" class="cta-button">Go to Dashboard</a>
            </center>
            
            <p style="margin-top: 30px; font-size: 14px; color: #6c757d;">
                <strong>Security Tip:</strong> Keep your account secure by using a strong password and enabling two-factor authentication if available.
            </p>
        </div>
        
        <div class="email-footer">
            <p><strong>Thank you for being with us!</strong></p>
            <p>If you have any questions or need assistance, feel free to contact our support team.</p>
            
            <div class="social-links">
                <a href="{$baseUrl}">Visit Website</a> | 
                <a href="{$baseUrl}/support">Support</a> | 
                <a href="{$baseUrl}/contact">Contact Us</a>
            </div>
            
            <p style="font-size: 12px; margin-top: 20px;">
                This is an automated message. Please do not reply to this email.<br>
                © {$currentYear} Your Company. All rights reserved.
            </p>
        </div>
    </div>
</body>
</html>
HTML;
}

/**
 * Build plain text email content
 * @param string $displayName User's display name
 * @param string $baseUrl Base URL for links
 * @return string Plain text email content
 */
function buildVerificationSuccessPlain($displayName, $baseUrl) {
    $currentYear = date('Y');
    
    return <<<PLAIN
Hello {$displayName},

Your email address has been successfully verified!

Thank you for verifying your email address. Your account is now fully activated and you have access to all features.

What You Can Do Now:
✓ Access all premium features and functionality
✓ Receive important notifications and updates
✓ Enhanced account security and protection
✓ Full access to your dashboard and settings

Visit your dashboard: {$baseUrl}/user/dashboard.php

Security Tip: Keep your account secure by using a strong password and enabling two-factor authentication if available.

Thank you for being with us!

This is an automated message. Please do not reply to this email.
© {$currentYear} Your Company. All rights reserved.
PLAIN;
}

/**
 * Build email headers
 * @return string Email headers
 */
function buildEmailHeaders() {
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $phpVersion = phpversion();
    
    return implode("\r\n", [
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        "From: Your Company <noreply@{$host}>",
        "Reply-To: support@{$host}",
        "X-Mailer: PHP/{$phpVersion}",
        'X-Priority: 1'
    ]);
}