<?php
namespace Config;

use PDO;
use PDOException;
use Exception;

/**
 * Database Singleton Class
 * Manages PDO connection with environment-aware configuration
 */
class Database {
    private static $instance = null;
    private $connection;
    private $config;
    private $options;
    
    /**
     * Private constructor - loads configuration
     */
    private function __construct() {
        $this->loadConfiguration();
        $this->initializeOptions();
        $this->connect();
    }
    
    /**
     * Load database configuration from constants
     * @throws Exception if configuration is incomplete
     */
    private function loadConfiguration() {
      $host = defined('DB_HOST') ? DB_HOST : 'localhost';
		$dbname = defined('DB_NAME') ? DB_NAME : 'faculty_info_system';
		$username = defined('DB_USER') ? DB_USER : 'root';
		$password = defined('DB_PASS') ? DB_PASS : '';
        
        $this->config = [
            'host'     => $host,
            'dbname'   => $dbname,
            'username' => $username,
            'password' => $password,
            'charset'  => 'utf8mb4'
        ];
        
        // Validate required configuration
        if (empty($this->config['host']) || empty($this->config['dbname'])) {
            throw new Exception('Database configuration incomplete. Check config/config.php');
        }
    }
    
    /**
     * Initialize PDO options for optimal performance and security
     */
    private function initializeOptions() {
        $this->options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4',
            PDO::ATTR_TIMEOUT            => defined('DB_TIMEOUT') ? DB_TIMEOUT : 30
        ];
    }
    
    /**
     * Establish database connection
     * @throws Exception if connection fails
     */
    private function connect() {
        try {
            $dsn = sprintf(
                'mysql:host=%s;dbname=%s;charset=%s',
                $this->config['host'],
                $this->config['dbname'],
                $this->config['charset']
            );
            
            $this->connection = new PDO(
                $dsn,
                $this->config['username'],
                $this->config['password'],
                $this->options
            );
        } catch (PDOException $e) {
            $errorMsg = 'Database Connection Error: ' . $e->getMessage();
            error_log($errorMsg);
            
            // Check if in development mode
            $isDev = defined('DEBUG_MODE') && DEBUG_MODE;
            if ($isDev) {
                throw new Exception($errorMsg);
            } else {
                // Production: don't expose details
                throw new Exception('Database connection failed. Please check the configuration.');
            }
        }
    }
    
    /**
     * Get singleton instance
     * @return Database
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Get PDO connection object
     * @return PDO
     */
    public function getConnection() {
        return $this->connection;
    }
    
    /**
     * Prevent cloning of singleton
     */
    private function __clone() {}
    
    /**
     * Prevent unserialization of singleton
     * @throws Exception
     */
    public function __wakeup() {
        throw new Exception('Cannot unserialize singleton');
    }
}