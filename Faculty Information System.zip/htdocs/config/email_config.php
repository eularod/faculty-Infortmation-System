<?php
/**
 * Email Configuration
 * Centralized email settings using environment-aware constants
 * DO NOT commit credentials to version control - use environment variables
 */

return [
    'smtp' => [
        'host'     => defined('EMAIL_HOST') ? EMAIL_HOST : 'smtp.gmail.com',
        'port'     => defined('EMAIL_PORT') ? EMAIL_PORT : 587,
        'secure'   => defined('EMAIL_ENCRYPTION') ? EMAIL_ENCRYPTION : 'tls',
        'username' => defined('EMAIL_USERNAME') ? EMAIL_USERNAME : '',
        'password' => defined('EMAIL_PASSWORD') ? EMAIL_PASSWORD : '',
        'from'     => [
            'email' => defined('EMAIL_USERNAME') ? EMAIL_USERNAME : 'noreply@facultysystem.com',
            'name'  => defined('EMAIL_FROM_NAME') ? EMAIL_FROM_NAME : 'Faculty Information System'
        ]
    ],
    'otp' => [
        'length'     => 6,        // OTP code length
        'expiry'     => 15,       // minutes
        'rate_limit' => 60        // seconds between requests
    ]
];