<?php
/**
 * Mail Configuration
 * PLACE THIS FILE IN: /config/mail_config.php
 * 
 * IMPORTANT: This example shows how to fix the localhost redirect issue
 * Replace the SMTP credentials with your actual credentials
 */

namespace Config;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// ADDED: Import BaseUrl class to fix localhost redirect
require_once __DIR__ . '/base_url.php';
use Config\BaseUrl;

class MailConfig {
    // SMTP Configuration - REPLACE WITH YOUR ACTUAL CREDENTIALS
    private static $smtp_host = 'smtp.gmail.com';
    private static $smtp_username = 'muchachasxd1@gmail.com';  // CHANGE THIS
    private static $smtp_password = 'obcclrkeyfmlllrj';      // CHANGE THIS
    private static $smtp_port = 587;
    private static $from_name = 'Faculty Information System';
    
    /**
     * Send verification email to user
     * FIXED: Now uses BaseUrl instead of hardcoded localhost
     */
    public static function sendVerificationEmail($email, $username, $token) {
        $mail = new PHPMailer(true);
        
        try {
            // SMTP Configuration
            $mail->isSMTP();
            $mail->Host       = self::$smtp_host;
            $mail->SMTPAuth   = true;
            $mail->Username   = self::$smtp_username;
            $mail->Password   = self::$smtp_password;
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = self::$smtp_port;
            
            // Email settings
            $mail->setFrom(self::$smtp_username, self::$from_name);
            $mail->addAddress($email, $username);
            $mail->isHTML(true);
            $mail->Subject = 'Verify Your Email Address';
            
            // FIXED: Use BaseUrl instead of hardcoded localhost
            // OLD CODE (DON'T USE):
            // $verificationLink = "http://localhost/your-project/public/verify_email.php?token=" . $token;
            
            // NEW CODE (USE THIS):
            $verificationLink = BaseUrl::getVerificationUrl($token);
            
            // Log for debugging
            error_log("Generated verification link: " . $verificationLink);
            
            // Email body
            $mail->Body = "
                <html>
                <head>
                    <style>
                        body { 
                            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
                            line-height: 1.6; 
                            color: #333; 
                            margin: 0;
                            padding: 0;
                        }
                        .container { 
                            max-width: 600px; 
                            margin: 0 auto; 
                            background: #ffffff;
                        }
                        .header { 
                            background: linear-gradient(135deg, #990000 0%, #7a0000 100%);
                            color: white; 
                            padding: 40px 20px; 
                            text-align: center;
                        }
                        .header h1 {
                            margin: 0;
                            font-size: 28px;
                        }
                        .content { 
                            background: #f9f9f9; 
                            padding: 40px 30px;
                        }
                        .content p {
                            margin: 15px 0;
                            font-size: 16px;
                        }
                        .button-container {
                            text-align: center;
                            margin: 30px 0;
                        }
                        .button { 
                            display: inline-block; 
                            padding: 15px 40px; 
                            background: #990000; 
                            color: white !important; 
                            text-decoration: none; 
                            border-radius: 8px; 
                            font-size: 16px;
                            font-weight: 600;
                            box-shadow: 0 4px 15px rgba(153, 0, 0, 0.3);
                        }
                        .button:hover {
                            background: #7a0000;
                        }
                        .link-text {
                            margin-top: 20px;
                            padding: 15px;
                            background: white;
                            border-radius: 5px;
                            word-break: break-all;
                            color: #666;
                            font-size: 14px;
                        }
                        .footer { 
                            text-align: center; 
                            color: #999; 
                            font-size: 12px; 
                            padding: 20px;
                            background: #f9f9f9;
                        }
                        .expiry-warning {
                            background: #fff3cd;
                            border-left: 4px solid #ffc107;
                            padding: 15px;
                            margin: 20px 0;
                            border-radius: 4px;
                        }
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>✉️ Email Verification</h1>
                        </div>
                        <div class='content'>
                            <p>Hello <strong>{$username}</strong>,</p>
                            <p>Congratulations! Your faculty account has been approved by the administrator.</p>
                            <p>To complete your registration, please verify your email address by clicking the button below:</p>
                            
                            <div class='button-container'>
                                <a href='{$verificationLink}' class='button'>Verify Email Address</a>
                            </div>
                            
                            <p>Or copy and paste this link into your browser:</p>
                            <div class='link-text'>{$verificationLink}</div>
                            
                            <div class='expiry-warning'>
                                <strong>⏰ Important:</strong> This verification link will expire in 24 hours.
                            </div>
                        </div>
                        <div class='footer'>
                            <p>If you did not request this account, please ignore this email.</p>
                            <p>&copy; " . date('Y') . " Faculty Information System. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";
            
            // Plain text alternative
            $mail->AltBody = "Hello {$username},\n\n"
                . "Your faculty account has been approved!\n\n"
                . "Please verify your email by visiting this link:\n"
                . "{$verificationLink}\n\n"
                . "This link will expire in 24 hours.\n\n"
                . "If you did not request this, please ignore this email.";
            
            $mail->send();
            error_log("✓ Verification email sent successfully to: " . $email);
            return true;
            
        } catch (Exception $e) {
            error_log("✗ Mail Error: " . $mail->ErrorInfo);
            error_log("✗ Exception: " . $e->getMessage());
            return false;
        }
    }
}
    