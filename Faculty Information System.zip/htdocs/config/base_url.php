<?php
/**
 * Base URL Configuration
 * This file automatically detects the correct base URL for the application
 * PLACE THIS FILE IN: /config/base_url.php
 */

namespace Config;

class BaseUrl {
    /**
     * Get the base URL of the application
     * Automatically detects the protocol (http/https) and domain
     * 
     * @return string The base URL (e.g., "http://localhost/your-project" or "https://yourdomain.com")
     */
    public static function get() {
        // Detect protocol
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' 
                    || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        
        // Get host
        $host = $_SERVER['HTTP_HOST'];
        
        // Get the directory path (removes filename if present)
        $script_name = dirname($_SERVER['SCRIPT_NAME']);
        
        // Clean up the path
        $path = str_replace('\\', '/', $script_name);
        $path = rtrim($path, '/');
        
        // For public folder structure, go up one level
        if (strpos($path, '/public') !== false) {
            $path = dirname($path);
        }
        
        return $protocol . $host . $path;
    }
    
    /**
     * Get the verification URL
     * 
     * @param string $token The verification token
     * @return string The complete verification URL
     */
    public static function getVerificationUrl($token) {
        return self::get() . '/public/verify_email.php?token=' . $token;
    }
}
