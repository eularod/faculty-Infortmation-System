<?php
/**
 * Faculty Information System - Home Page
 */

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include initialization if needed
if (!defined('BASE_PATH')) {
    require_once __DIR__ . '/init.php';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Information System</title>
    <link rel="stylesheet" href="<?php echo asset('css/style.css'); ?>">
</head>
<body>
    <div class="home-container">
        <main>
            <div class="welcome-section">
                <h2>Get Started</h2>
                <p>Please log in to access the system.</p>
                <a href="public/login.php" class="login-button">Login</a>
            </div>
        </main>

        <footer>
            <p>&copy; 2024 Faculty Information System. All rights reserved.</p>
        </footer>
    </div>
</body>
</html>



